"""Localisation des ressources embarquées, en développement comme en paquet
PyInstaller (où elles sont extraites sous ``sys._MEIPASS``)."""

from __future__ import annotations

import sys
from pathlib import Path


def is_frozen() -> bool:
    return bool(getattr(sys, "frozen", False)) and hasattr(sys, "_MEIPASS")


def backend_root() -> Path:
    """Dossier ``backend/`` en développement, racine du paquet une fois figé."""
    if is_frozen():
        return Path(sys._MEIPASS)  # type: ignore[attr-defined]
    return Path(__file__).resolve().parents[2]


def migrations_dir() -> Path:
    return backend_root() / "migrations"


def fonts_dir() -> Path:
    return backend_root() / "app" / "resources" / "fonts"


def default_frontend_dist() -> Path:
    if is_frozen():
        return backend_root() / "frontend_dist"
    return backend_root().parent / "frontend" / "dist"
