"""Vérification d'un paquet RouteX construit (Windows ou Linux).

Démarre l'exécutable produit par PyInstaller sur une base neuve, dans un dossier
temporaire, et contrôle le parcours minimal d'une « version exécutable » (§17) :
démarrage, interface servie, compte administrateur, projet, exports PDF/XLSX/CSV,
sauvegarde, arrêt, redémarrage et persistance des données.

N'utilise que la bibliothèque standard Python.

    python scripts/verify_release.py dist/RouteX/RouteX.exe      (Windows)
    python3 scripts/verify_release.py dist/RouteX/RouteX         (Linux)

Ne vérifie PAS l'absence de réseau (TX-013) : à faire manuellement, carte réseau
désactivée, en relançant ce script.
"""

from __future__ import annotations

import io
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from typing import Any

RESULTS: list[tuple[bool, str]] = []


def check(condition: bool, label: str) -> None:
    RESULTS.append((condition, label))
    print(f"  [{'OK' if condition else 'ÉCHEC'}] {label}", flush=True)
    if not condition:
        raise AssertionError(label)


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


class Client:
    def __init__(self, base: str) -> None:
        self.base = base
        self.token: str | None = None

    def call(self, method: str, path: str, body: Any = None) -> tuple[int, dict[str, str], bytes]:
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(self.base + path, data=data, method=method)
        if data is not None:
            req.add_header("Content-Type", "application/json")
        if self.token:
            req.add_header("Authorization", f"Bearer {self.token}")
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return resp.status, dict(resp.headers), resp.read()
        except urllib.error.HTTPError as err:
            return err.code, dict(err.headers), err.read()

    def json(self, method: str, path: str, body: Any = None) -> tuple[int, Any]:
        status, _headers, content = self.call(method, path, body)
        return status, json.loads(content) if content else None


def start(exe: Path, env: dict[str, str], port: int, cwd: Path) -> subprocess.Popen[bytes]:
    proc = subprocess.Popen(
        [str(exe), "--no-browser", "--port", str(port)], env=env, cwd=cwd,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
    )
    for _ in range(120):
        if proc.poll() is not None:
            out = proc.stdout.read().decode(errors="replace") if proc.stdout else ""
            raise AssertionError(f"L'exécutable s'est arrêté au démarrage :\n{out}")
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/api/v1/system/health", timeout=1)
            return proc
        except OSError:
            time.sleep(0.5)
    proc.kill()
    raise AssertionError("Le serveur n'a pas répondu en 60 s.")


def stop(proc: subprocess.Popen[bytes]) -> None:
    proc.terminate()
    try:
        proc.wait(timeout=15)
    except subprocess.TimeoutExpired:
        proc.kill()


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__)
        return 2
    exe = Path(sys.argv[1]).resolve()
    if not exe.exists():
        print(f"Exécutable introuvable : {exe}")
        return 2

    with tempfile.TemporaryDirectory(prefix="routex-verif-") as tmp:
        tmp_path = Path(tmp)
        env = {**os.environ, "ROUTEX_DATA_DIR": str(tmp_path / "donnees")}
        env.pop("ROUTEX_FRONTEND_DIST", None)
        port = free_port()
        base = f"http://127.0.0.1:{port}"
        print(f"Vérification de {exe}\nDonnées temporaires : {tmp_path}\n")

        try:
            info = subprocess.run([str(exe), "info"], env=env, cwd=tmp_path, capture_output=True, timeout=60)
            check(info.returncode == 0 and b"routex.sqlite3" in info.stdout, "Commande « info »")

            proc = start(exe, env, port, tmp_path)
            try:
                c = Client(base)
                status, health = c.json("GET", "/api/v1/system/health")
                check(status == 200 and health["mode"] == "production", f"Démarrage, version {health['version']}")
                status, _h, page = c.call("GET", "/")
                check(status == 200 and b'id="root"' in page, "Interface servie depuis le paquet")
                status, _h, page = c.call("GET", "/docs")
                check(status == 404, "Documentation interactive désactivée en production (pas de CDN)")

                status, body = c.json("POST", "/api/v1/auth/setup",
                                      {"username": "admin", "full_name": "Vérification Release", "password": "verification-2026"})
                check(status == 201, "Création du premier administrateur")
                c.token = body["token"]
                status, prj = c.json("POST", "/api/v1/projects", {
                    "code": "VERIF-001", "name": "Réhabilitation — tronçon Pétion-Ville", "currency": "HTG",
                    "country": "Haïti", "start_date": "2026-11-02", "end_date": "2027-06-30"})
                check(status == 201, "Création d'un projet")

                status, headers, pdf = c.call("GET", "/api/v1/reports/projects.pdf")
                check(status == 200 and pdf.startswith(b"%PDF-") and b"DejaVuSans" in pdf, "Export PDF (police embarquée)")
                status, headers, xlsx = c.call("GET", f"/api/v1/projects/{prj['id']}/report.xlsx")
                with zipfile.ZipFile(io.BytesIO(xlsx)) as zf:
                    check(status == 200 and "xl/workbook.xml" in zf.namelist(), "Export XLSX lisible")
                status, _h, csv_bytes = c.call("GET", "/api/v1/reports/projects.csv")
                check(status == 200 and "Pétion-Ville".encode() in csv_bytes, "Export CSV (accents conservés)")

                status, backup = c.json("POST", "/api/v1/admin/backup")
                check(status == 201 and backup["integrity"] == "ok", "Sauvegarde avec contrôle d'intégrité")
            finally:
                stop(proc)

            proc = start(exe, env, port, tmp_path)
            try:
                c = Client(base)
                status, body = c.json("POST", "/api/v1/auth/login", {"username": "admin", "password": "verification-2026"})
                c.token = body["token"] if status == 200 else None
                status, listing = c.json("GET", "/api/v1/projects")
                check(status == 200 and [p["code"] for p in listing["items"]] == ["VERIF-001"],
                      "Données conservées après arrêt et redémarrage")
            finally:
                stop(proc)

            out = subprocess.run([str(exe), "backup"], env=env, cwd=tmp_path, capture_output=True, timeout=60)
            check(out.returncode == 0 and "intégrité : ok".encode() in out.stdout, "Commande « backup »")
        except AssertionError as exc:
            print(f"\nÉCHEC : {exc}")
            return 1

    print(f"\n{len(RESULTS)} contrôle(s) réussi(s). Reste à faire manuellement : TX-013 (réseau désactivé).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
