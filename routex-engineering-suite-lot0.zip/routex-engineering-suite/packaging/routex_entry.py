"""Point d'entrée PyInstaller : délègue au lanceur de l'application."""

import multiprocessing
import sys

from app.launcher import main

if __name__ == "__main__":
    multiprocessing.freeze_support()
    sys.exit(main())
