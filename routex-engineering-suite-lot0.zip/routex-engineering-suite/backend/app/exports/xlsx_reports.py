"""Classeurs XLSX (openpyxl)."""

from __future__ import annotations

import io

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from app.core.timeutil import format_local_datetime
from app.exports.common import (
    PROJECT_LIST_COLUMNS,
    STATUS_LABELS,
    RenderedReport,
    ReportMeta,
    project_fields,
    safe_file_part,
    timestamp_for_file,
)
from app.schemas.project import ProjectOut

XLSX_MEDIA_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
HEADER_FILL = PatternFill("solid", fgColor="1F4E79")
HEADER_FONT = Font(bold=True, color="FFFFFF")
LABEL_FONT = Font(bold=True, color="5B6B7A")
THIN = Side(style="thin", color="C9D3DC")
DATE_FORMAT = "DD/MM/YYYY"
COLUMN_WIDTHS = {"code": 14, "name": 40, "client": 30, "location": 24, "country": 14,
                 "currency": 9, "start_date": 12, "end_date": 12, "status": 11}


def _new_workbook(meta: ReportMeta) -> Workbook:
    wb = Workbook()
    wb.properties.creator = meta.author
    wb.properties.title = meta.title
    wb.properties.description = f"{meta.app_name} {meta.app_version}"
    return wb


def _info_sheet(wb: Workbook, meta: ReportMeta, extra: list[tuple[str, str]]) -> None:
    ws = wb.create_sheet("Informations")
    rows: list[tuple[str, str]] = [
        ("Rapport", meta.title),
        ("Généré le", format_local_datetime(meta.generated_at)),
        ("Par", meta.author),
        *[(f"Filtre — {k}", v) for k, v in meta.filters.items()],
        *extra,
        ("Application", f"{meta.app_name} {meta.app_version}"),
        ("Note", "Export de la base locale RouteX. La base reste la source de référence ; "
                 "ce fichier n'en est qu'une copie à la date indiquée."),
    ]
    for r, (label, value) in enumerate(rows, start=1):
        ws.cell(row=r, column=1, value=label).font = LABEL_FONT
        cell = ws.cell(row=r, column=2, value=value)
        cell.alignment = Alignment(wrap_text=True, vertical="top")
    ws.column_dimensions["A"].width = 26
    ws.column_dimensions["B"].width = 80


def _to_bytes(wb: Workbook) -> bytes:
    buffer = io.BytesIO()
    wb.save(buffer)
    return buffer.getvalue()


def _style_header(ws: Worksheet, ncols: int) -> None:
    for col in range(1, ncols + 1):
        cell = ws.cell(row=1, column=col)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(vertical="center")
    ws.freeze_panes = "A2"


def render_projects_list(projects: list[ProjectOut], meta: ReportMeta) -> RenderedReport:
    wb = _new_workbook(meta)
    ws = wb.active
    assert ws is not None
    ws.title = "Projets"
    ws.append([label for _key, label in PROJECT_LIST_COLUMNS])
    for prj in projects:
        ws.append([
            prj.code, prj.name, prj.client, prj.location, prj.country, prj.currency,
            prj.start_date, prj.end_date, STATUS_LABELS.get(prj.status, prj.status),
        ])
    _style_header(ws, len(PROJECT_LIST_COLUMNS))
    for idx, (key, _label) in enumerate(PROJECT_LIST_COLUMNS, start=1):
        letter = get_column_letter(idx)
        ws.column_dimensions[letter].width = COLUMN_WIDTHS[key]
        if key in ("start_date", "end_date"):
            for row in range(2, len(projects) + 2):
                ws[f"{letter}{row}"].number_format = DATE_FORMAT
    if projects:
        ws.auto_filter.ref = f"A1:{get_column_letter(len(PROJECT_LIST_COLUMNS))}{len(projects) + 1}"
    _info_sheet(wb, meta, [("Nombre de projets", str(len(projects)))])

    name = f"RouteX_projets_{timestamp_for_file(meta.generated_at)}.xlsx"
    return RenderedReport(_to_bytes(wb), XLSX_MEDIA_TYPE, name)


def render_project_sheet(project: ProjectOut, meta: ReportMeta) -> RenderedReport:
    wb = _new_workbook(meta)
    ws = wb.active
    assert ws is not None
    ws.title = "Fiche projet"
    ws.append(["Champ", "Valeur"])
    _style_header(ws, 2)
    # Les dates sont écrites comme vraies dates Excel (utilisables en calcul).
    real_dates = {"Date de début": project.start_date, "Date de fin": project.end_date}
    for label, value in project_fields(project):
        if label in real_dates and real_dates[label] is not None:
            ws.append([label, real_dates[label]])
            ws.cell(row=ws.max_row, column=2).number_format = DATE_FORMAT
        else:
            ws.append([label, value])
    ws.append(["Description", project.description])
    for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
        row[0].font = LABEL_FONT
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical="top")
            cell.border = Border(bottom=THIN)
    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 90
    _info_sheet(wb, meta, [("Projet", f"{project.code} (révision {project.revision})")])

    name = f"RouteX_fiche_{safe_file_part(project.code)}_r{project.revision}.xlsx"
    return RenderedReport(_to_bytes(wb), XLSX_MEDIA_TYPE, name)
