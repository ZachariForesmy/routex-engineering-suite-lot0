# Registre des décisions — RouteX Engineering Suite

Chaque décision porte un identifiant stable (`D-xxx`), un statut, la date et
la justification. Une décision « provisoire » est une valeur de départ
documentée et modifiable ; elle ne doit pas être considérée comme validée par
le maître d'ouvrage ou l'ingénieur responsable.

Statuts : **Retenue** (appliquée dans le code) · **Provisoire** (valeur de
départ, à confirmer) · **Reportée** (sera tranchée dans le lot indiqué).

---

## D-001 — Architecture d'exécution : serveur local + navigateur
- **Statut :** Retenue — 20/10/2026
- **Décision :** l'application est un serveur FastAPI lié uniquement à
  `127.0.0.1`, qui sert à la fois l'API (`/api/v1`) et l'interface React
  compilée. Un lanceur (`app/launcher.py`) prépare la base, démarre le serveur
  et ouvre le navigateur par défaut. L'utilisateur ne manipule aucun serveur.
- **Justification :** une seule origine HTTP (pas de CORS), même code en
  développement et en production, packaging simple. Une fenêtre native
  (pywebview/WebView2) reste possible plus tard sans changer l'architecture.
- **Conséquence :** la fenêtre console du lanceur doit rester ouverte pendant
  l'utilisation ; la fermer arrête l'application. Un bouton « Quitter » et une
  icône de zone de notification sont prévus au Lot 1.

## D-002 — Packaging Windows : PyInstaller, mode dossier (onedir)
- **Statut :** Provisoire — 20/10/2026
- **Décision :** PyInstaller 6.x en mode `onedir`, distribué en archive ZIP
  « portable ». Pas d'installateur en Lot 0.
- **Justification :** PyInstaller ne compile pas en croisé : le paquet Windows
  doit être construit **sur Windows** (`scripts/build-windows.ps1`). Le mode
  `onedir` démarre plus vite et déclenche moins de faux positifs antivirus que
  `onefile`. Licence : GPL-2.0 avec exception pour le bootloader, qui autorise
  la distribution d'applications non GPL.
- **État de vérification :** la recette a été exécutée sous Linux (même spec
  PyInstaller, `scripts/build-linux.sh` depuis un environnement vierge) ; le
  binaire obtenu passe les 12 contrôles de `scripts/verify_release.py`, y
  compris lancé dans un espace réseau isolé (boucle locale seule). Les scripts
  PowerShell ont été validés par l'analyseur syntaxique de PowerShell 7.5.4.
  **Le build Windows n'a pas encore été exécuté ni testé.**
- **À faire (Lot 1) :** exécuter `build-windows.ps1` sur Windows 10/11 propre,
  puis décider d'un installateur (Inno Setup envisagé) et d'une signature de
  code.

## D-003 — Emplacement des données
- **Statut :** Retenue — 20/10/2026
- **Décision :**
  - Windows : `%LOCALAPPDATA%\RouteX\`
  - Linux (développement) : `$XDG_DATA_HOME/RouteX` ou `~/.local/share/RouteX`
  - Remplaçable par la variable `ROUTEX_DATA_DIR`.
  - Sous-dossiers : `data/routex.sqlite3`, `backups/`, `logs/`, `documents/`
    (réservé au Lot 1), `exports/` (réservé).
- **Justification :** répertoire utilisateur persistant, non temporaire, non
  synchronisé par défaut (une base SQLite ne doit pas être placée dans un
  dossier synchronisé OneDrive/Dropbox ou sur un lecteur réseau).

## D-004 — Base de données : SQLite + SQLAlchemy 2 + Alembic
- **Statut :** Retenue — 20/10/2026
- **Décision :** SQLite en mode WAL, `synchronous=FULL`, `foreign_keys=ON`,
  `busy_timeout=5000`. SQLAlchemy 2 (ORM typé) et Alembic en mode *batch*
  (indispensable pour les `ALTER TABLE` sous SQLite).
- **Migrations :** appliquées automatiquement au démarrage. Si la base existe
  et n'est pas à jour, **une sauvegarde est faite avant la migration**
  (`backups/avant-migration_*.sqlite3`). Si la base porte une révision
  inconnue (base créée par une version plus récente), l'application refuse de
  démarrer plutôt que de risquer une corruption.
- **Déviation par rapport au §6 :** les migrations sont dans
  `backend/migrations/` (et non `migrations/` à la racine) car elles font
  partie du paquet Python embarqué par PyInstaller.
- **Tables créées en Lot 0 :** `users`, `user_sessions`, `projects`,
  `audit_log`. Les autres tables du §7 seront créées par migration dans le lot
  qui les utilise, pour éviter un schéma mort non testé.

## D-005 — Identifiants
- **Statut :** Retenue — 20/10/2026
- **Décision :** identifiants UUID v4 (texte, 36 caractères) pour les
  enregistrements métier ; entier auto-incrémenté pour `audit_log` (ordre
  strict). Le code projet (`code`) est un identifiant métier unique,
  insensible à la casse.

## D-006 — Dates et heures
- **Statut :** Retenue — 20/10/2026
- **Décision :** horodatages stockés en **UTC**, format ISO 8601, avec
  fuseau explicite dans l'API. Les dates de projet (début/fin) sont des dates
  calendaires sans heure. L'interface affiche l'heure locale du poste ; les
  rapports indiquent l'heure locale et le fuseau.

## D-007 — Mots de passe, sessions et comptes
- **Statut :** Retenue — 20/10/2026
- **Décision :**
  - Hachage **Argon2id** (`argon2-cffi`, paramètres par défaut de la
    bibliothèque, re-hachage automatique si les paramètres évoluent).
  - Longueur minimale : 10 caractères.
  - Sessions : jeton aléatoire de 256 bits remis au client ; seule son
    empreinte SHA-256 est stockée. Durée : 12 h (`ROUTEX_SESSION_HOURS`).
    Déconnexion = révocation immédiate. Pas de cookie → pas de CSRF.
  - Premier lancement : tant qu'aucun utilisateur n'existe, l'écran
    « Créer le compte administrateur » est proposé ; l'API refuse cette
    opération dès qu'un compte existe.
  - Récupération : un administrateur réinitialise le mot de passe d'un autre
    compte depuis l'écran Utilisateurs. Si l'unique administrateur a perdu son
    mot de passe : commande locale
    `RouteX.exe reset-password <identifiant>` (accès physique au poste requis).
  - Aucun secret n'est codé en dur ; aucune clé de chiffrement n'est
    nécessaire en Lot 0.
- **Limite connue :** pas de limitation du nombre d'essais de connexion en
  Lot 0 (les échecs sont journalisés). À ajouter au Lot 1.

## D-008 — Rôles et droits
- **Statut :** Retenue — 20/10/2026
- **Décision :** quatre rôles contrôlés côté backend (matrice unique dans
  `app/core/permissions.py`) :

| Permission                    | Admin | Ingénieur | Technicien | Lecture |
|-------------------------------|:-----:|:---------:|:----------:|:-------:|
| Consulter / exporter projets  |   ✔   |     ✔     |     ✔      |    ✔    |
| Créer / modifier projets      |   ✔   |     ✔     |            |         |
| Archiver / désarchiver        |   ✔   |     ✔     |            |         |
| Gérer les utilisateurs        |   ✔   |           |            |         |
| Sauvegarder la base           |   ✔   |           |            |         |
| Consulter le journal d'audit  |   ✔   |           |            |         |

- **Provisoire :** en Lot 0, tout utilisateur voit tous les projets
  (pas encore de `project_memberships`). Les droits du technicien sur les
  métrés seront définis au Lot 2.

## D-009 — Sécurité du serveur local
- **Statut :** Retenue — 20/10/2026
- **Décision :** écoute sur `127.0.0.1` uniquement ; contrôle de l'en-tête
  `Host` (protection contre le *DNS rebinding*) ; en-têtes
  `Content-Security-Policy: default-src 'self'`, `X-Frame-Options: DENY`,
  `X-Content-Type-Options: nosniff`, `Referrer-Policy: no-referrer`.
- **Documentation API :** Swagger UI (`/docs`) charge ses fichiers depuis un
  CDN ; il n'est donc activé qu'en mode développement (`ROUTEX_DEV=1`). La
  spécification OpenAPI est exportée hors ligne dans `docs/openapi.json`.

## D-010 — Devise
- **Statut :** Provisoire — 20/10/2026
- **Décision :** chaque projet porte **une** devise (code ISO 4217 à 3
  lettres, obligatoire). Le formulaire propose HTG par défaut et une liste
  courte (HTG, USD, EUR, XOF, XAF, CAD, DOP) ; tout code ISO valide est
  accepté. La valeur par défaut est modifiable par `ROUTEX_DEFAULT_CURRENCY`.
- **Reporté au Lot 3 :** projets multi-devises, taux de change datés.

## D-011 — Nombres, arrondis et unités
- **Statut :** Provisoire — décision d'implémentation au Lot 2/3
- **Décision de principe :**
  - montants et quantités manipulés en `Decimal` côté Python, jamais en
    `float` ; stockés en texte décimal exact dans SQLite (SQLite convertit
    `NUMERIC` en flottant) ;
  - mode d'arrondi et nombre de décimales configurables **par projet**
    (montants par défaut : 2 décimales, demi-supérieur) ;
  - l'arrondi s'applique au montant de chaque ligne, puis les totaux sont la
    somme des lignes arrondies — règle à confirmer par le métreur/ingénieur ;
  - système d'unités : SI (métrique) uniquement en Lot 0 ; le champ
    `unit_system` est enregistré pour permettre l'évolution.

## D-012 — Rapports PDF / XLSX / CSV
- **Statut :** Retenue pour le Lot 0 — 20/10/2026
- **Décision :**
  - PDF : ReportLab (licence BSD) avec la police **DejaVu Sans** embarquée
    (accents et caractères spéciaux garantis, licence Bitstream Vera).
    A4, en-tête, pied de page « Page X / Y », date de génération, auteur.
  - XLSX : openpyxl ; vraies dates Excel, en-têtes figés, filtre automatique,
    feuille « Informations » (date, auteur, filtres, version).
  - CSV : UTF-8 avec BOM, séparateur `;` (ouverture directe dans Excel en
    configuration française).
  - Chaque export est tracé dans `audit_log` (format, filtres, révision du
    projet, empreinte SHA-256 et taille du fichier).
- **Reporté au Lot 1 :** page de garde et pied de page configurables
  (logo, nom du bureau d'études), modèles dans `templates/`.

## D-013 — Concurrence d'édition
- **Statut :** Retenue — 20/10/2026
- **Décision :** chaque projet porte un numéro de révision. Une modification
  doit fournir la révision lue ; si elle a changé entre-temps, l'API répond
  `409 Conflit` au lieu d'écraser silencieusement.

## D-014 — Conservation et archivage
- **Statut :** Provisoire — 20/10/2026
- **Décision :** aucune suppression définitive de projet en Lot 0 ; seul
  l'archivage (réversible) est proposé. Les comptes utilisateurs sont
  désactivés, jamais supprimés (le journal d'audit les référence).

## D-015 — Sauvegarde et restauration
- **Statut :** Partiellement retenue — 20/10/2026
- **Décision :** sauvegarde à chaud par l'API de sauvegarde SQLite (cohérente
  même en mode WAL), suivie d'un `PRAGMA integrity_check` sur la copie. Fichier
  `backups/routex_AAAAMMJJ-HHMMSS.sqlite3`. Sauvegarde automatique avant chaque
  migration.
- **Reporté au Lot 1 :** restauration depuis l'interface (vérification,
  confirmation, sauvegarde de la base courante avant remplacement),
  sauvegarde automatique planifiée, inclusion du dossier `documents/`.

## D-016 — Frontend
- **Statut :** Retenue — 20/10/2026
- **Décision :** React 19 + TypeScript + Vite, **sans bibliothèque de
  composants** ni routeur (moins de dépendances, fonctionnement hors ligne
  garanti, rendu maîtrisé). Tests unitaires avec Vitest ; parcours de bout en
  bout avec Playwright (optionnel, nécessite un navigateur installé).

## D-017 — Reportées (à trancher dans le lot indiqué)
| Sujet                                              | Lot |
|----------------------------------------------------|-----|
| Versions DXF et entités prises en charge           | 6   |
| Conventions d'import des points topographiques     | 6   |
| Références normatives et méthodes par discipline   | 2, 7, 8 |
| Modèles PDF/XLSX configurables                     | 1, 3 |
| Politique de sauvegarde automatique                | 1   |
| Installateur Windows et signature de code          | 1   |
