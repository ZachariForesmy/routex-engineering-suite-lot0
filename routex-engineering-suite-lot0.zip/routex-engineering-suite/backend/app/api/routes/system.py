from __future__ import annotations

from fastapi import APIRouter
from sqlalchemy import text

from app import APP_ID, APP_NAME, __version__
from app.api.deps import AppSettings, DbSession

router = APIRouter(prefix="/system", tags=["Système"])


@router.get("/health", summary="État de l'application (sans authentification)")
def health(db: DbSession, settings: AppSettings) -> dict[str, str]:
    db.execute(text("SELECT 1"))
    return {"status": "ok", "app": APP_ID, "name": APP_NAME, "version": __version__,
            "mode": "developpement" if settings.dev_mode else "production"}
