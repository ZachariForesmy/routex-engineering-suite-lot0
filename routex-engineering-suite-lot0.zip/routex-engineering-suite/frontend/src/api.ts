/**
 * Client de l'API locale. Le jeton de session est conservé dans
 * sessionStorage : il disparaît à la fermeture du navigateur.
 */

const TOKEN_KEY = "routex.session";
export const API_BASE = "/api/v1";

export interface FieldError {
  field: string;
  message: string;
}

export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly fieldErrors: FieldError[];

  constructor(message: string, status: number, code = "erreur", fieldErrors: FieldError[] = []) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
    this.fieldErrors = fieldErrors;
  }
}

let memoryToken: string | null = null;
let onUnauthorized: (() => void) | null = null;

function storage(): Storage | null {
  try {
    return typeof window !== "undefined" ? window.sessionStorage : null;
  } catch {
    return null;
  }
}

export function getToken(): string | null {
  if (memoryToken) return memoryToken;
  try {
    memoryToken = storage()?.getItem(TOKEN_KEY) ?? null;
  } catch {
    memoryToken = null;
  }
  return memoryToken;
}

export function setToken(token: string | null): void {
  memoryToken = token;
  try {
    const s = storage();
    if (!s) return;
    if (token) s.setItem(TOKEN_KEY, token);
    else s.removeItem(TOKEN_KEY);
  } catch {
    /* stockage indisponible : le jeton reste en mémoire */
  }
}

/** Appelé lorsqu'une requête authentifiée reçoit 401 (session expirée ou révoquée). */
export function setUnauthorizedHandler(handler: (() => void) | null): void {
  onUnauthorized = handler;
}

export async function toApiError(response: Response): Promise<ApiError> {
  let detail = `Erreur ${response.status}`;
  let code = `http_${response.status}`;
  let fieldErrors: FieldError[] = [];
  try {
    const body = (await response.json()) as { detail?: unknown; code?: unknown; errors?: unknown };
    if (typeof body.detail === "string") detail = body.detail;
    if (typeof body.code === "string") code = body.code;
    if (Array.isArray(body.errors)) fieldErrors = body.errors as FieldError[];
  } catch {
    if (response.status >= 500) detail = "Le serveur local ne répond pas correctement. Consultez le journal technique.";
  }
  return new ApiError(detail, response.status, code, fieldErrors);
}

type Query = Record<string, string | number | boolean | undefined>;

export function buildUrl(path: string, query?: Query): string {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(query ?? {})) {
    if (value !== undefined && value !== "") params.set(key, String(value));
  }
  const qs = params.toString();
  return `${API_BASE}${path}${qs ? `?${qs}` : ""}`;
}

async function send(method: string, path: string, body?: unknown, query?: Query): Promise<Response> {
  const headers: Record<string, string> = { Accept: "application/json" };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  if (body !== undefined) headers["Content-Type"] = "application/json";

  let response: Response;
  try {
    response = await fetch(buildUrl(path, query), {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    throw new ApiError(
      "Impossible de joindre RouteX. Vérifiez que la fenêtre de l'application est toujours ouverte.",
      0,
      "hors_ligne",
    );
  }
  if (!response.ok) {
    const error = await toApiError(response);
    if (response.status === 401 && token) {
      setToken(null);
      onUnauthorized?.();
    }
    throw error;
  }
  return response;
}

export async function request<T>(method: string, path: string, body?: unknown, query?: Query): Promise<T> {
  const response = await send(method, path, body, query);
  if (response.status === 204) return undefined as T;
  return (await response.json()) as T;
}

/** Extrait le nom de fichier d'un en-tête Content-Disposition (RFC 6266 / 5987). */
export function filenameFromDisposition(header: string | null, fallback: string): string {
  if (!header) return fallback;
  const star = /filename\*\s*=\s*UTF-8''([^;]+)/i.exec(header);
  if (star?.[1]) {
    try {
      return decodeURIComponent(star[1].trim());
    } catch {
      /* repli sur filename= */
    }
  }
  const plain = /filename\s*=\s*"([^"]+)"/i.exec(header) ?? /filename\s*=\s*([^;]+)/i.exec(header);
  return plain?.[1]?.trim() || fallback;
}

/** Télécharge un export (PDF/XLSX/CSV) et déclenche l'enregistrement par le navigateur. */
export async function download(path: string, query?: Query): Promise<string> {
  const response = await send("GET", path, undefined, query);
  const blob = await response.blob();
  const name = filenameFromDisposition(response.headers.get("Content-Disposition"), "export-routex");
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = name;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
  return name;
}
