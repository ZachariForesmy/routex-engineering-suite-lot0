import { useState, type FormEvent } from "react";
import { ApiError } from "../api";
import { CURRENCIES, validateDraft } from "../format";
import type { ProjectDraft } from "../types";

interface Props {
  title: string;
  initial: ProjectDraft;
  submitLabel: string;
  onSubmit: (draft: ProjectDraft) => Promise<void>;
  onCancel: () => void;
}

type Errors = Record<string, string>;

export function ProjectForm({ title, initial, submitLabel, onSubmit, onCancel }: Props) {
  const [draft, setDraft] = useState<ProjectDraft>(initial);
  const [errors, setErrors] = useState<Errors>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const set = (key: keyof ProjectDraft) => (value: string) => setDraft((d) => ({ ...d, [key]: value }));

  async function submit(event: FormEvent) {
    event.preventDefault();
    const local = validateDraft(draft);
    setErrors(local);
    setFormError(null);
    if (Object.keys(local).length > 0) return;
    setBusy(true);
    try {
      await onSubmit(draft);
    } catch (e) {
      if (e instanceof ApiError) {
        const fieldErrors: Errors = {};
        for (const fe of e.fieldErrors) if (fe.field) fieldErrors[fe.field] = fe.message;
        if (e.code === "code_existant") fieldErrors.code = e.message;
        setErrors(fieldErrors);
        setFormError(e.message);
      } else {
        setFormError("Enregistrement impossible.");
      }
    } finally {
      setBusy(false);
    }
  }

  const field = (key: keyof ProjectDraft, label: string, opts: { required?: boolean; hint?: string; type?: string; span?: boolean } = {}) => (
    <div className={`field${opts.span ? " span-2" : ""}`}>
      <label htmlFor={`prj-${key}`}>
        {label}
        {opts.required && <span className="req" aria-hidden="true">*</span>}
      </label>
      <input
        id={`prj-${key}`}
        type={opts.type ?? "text"}
        value={draft[key]}
        onChange={(e) => set(key)(e.target.value)}
        required={opts.required}
        aria-invalid={errors[key] ? true : undefined}
        aria-describedby={errors[key] ? `prj-${key}-err` : undefined}
      />
      {opts.hint && <span className="hint">{opts.hint}</span>}
      {errors[key] && (
        <span className="error" id={`prj-${key}-err`}>
          {errors[key]}
        </span>
      )}
    </div>
  );

  return (
    <form className="panel" onSubmit={submit} noValidate aria-labelledby="prj-form-title">
      <div className="panel__head">
        <h2 id="prj-form-title">{title}</h2>
        <p className="small muted">Les champs marqués * sont obligatoires.</p>
      </div>
      <div className="panel__body">
        <div className="form-grid">
          {field("code", "Code projet", { required: true, hint: "Ex. RTX-2026-001. Unique." })}
          <div className="field">
            <label htmlFor="prj-currency">
              Devise<span className="req" aria-hidden="true">*</span>
            </label>
            <input
              id="prj-currency"
              type="text"
              list="prj-currencies"
              maxLength={3}
              value={draft.currency}
              onChange={(e) => set("currency")(e.target.value.toUpperCase())}
              aria-invalid={errors.currency ? true : undefined}
            />
            <datalist id="prj-currencies">
              {CURRENCIES.map((c) => (
                <option key={c} value={c} />
              ))}
            </datalist>
            <span className="hint">Code ISO 4217 (HTG, USD, EUR…).</span>
            {errors.currency && <span className="error">{errors.currency}</span>}
          </div>
          {field("name", "Intitulé", { required: true, span: true })}
          {field("client", "Maître d'ouvrage", { span: true })}
          {field("location", "Localisation")}
          {field("country", "Pays")}
          {field("start_date", "Date de début", { type: "date" })}
          {field("end_date", "Date de fin", { type: "date" })}
          <div className="field span-2">
            <label htmlFor="prj-description">Description</label>
            <textarea id="prj-description" value={draft.description} onChange={(e) => set("description")(e.target.value)} />
          </div>
          <div className="field span-2">
            <span className="label">Système d'unités</span>
            <span className="muted">Système international (métrique), seul système disponible dans cette version.</span>
          </div>
        </div>
        {formError && (
          <p className="field error form-error" role="alert">
            {formError}
          </p>
        )}
        <div className="form-actions">
          <button className="btn btn--primary" type="submit" disabled={busy}>
            {busy ? "Enregistrement…" : submitLabel}
          </button>
          <button className="btn" type="button" onClick={onCancel} disabled={busy}>
            Annuler
          </button>
        </div>
      </div>
    </form>
  );
}
