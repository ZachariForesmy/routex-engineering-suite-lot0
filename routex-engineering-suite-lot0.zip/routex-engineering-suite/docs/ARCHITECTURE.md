# Architecture — RouteX (Lot 0)

## Vue d'ensemble

```text
 Navigateur du poste (interface React compilée)
        │  HTTP, même origine, jeton Bearer
        ▼
 Serveur local uvicorn — 127.0.0.1:8765 (port libre si occupé)
   ├─ /            fichiers statiques de l'interface (frontend/dist)
   └─ /api/v1      API FastAPI
        │
        ├─ api/        routes, contrôle des permissions, format des erreurs
        ├─ services/   règles métier, transactions, journal d'audit
        ├─ exports/    PDF (ReportLab), XLSX (openpyxl), CSV
        └─ db/         SQLAlchemy + Alembic
               │
               ▼
 %LOCALAPPDATA%\RouteX\
   data\routex.sqlite3   base (WAL)
   backups\              sauvegardes vérifiées
   logs\routex.log       journal technique (rotation 5 × 1 Mo)
   documents\            réservé aux pièces jointes (Lot 1)
```

Le **lanceur** (`app/launcher.py`, `RouteX.exe` une fois empaqueté) vérifie si
une instance tourne déjà (elle est alors simplement rouverte dans le
navigateur), prépare la base (sauvegarde puis migration si besoin), démarre le
serveur et ouvre le navigateur par défaut.

## Séparation des responsabilités

| Couche | Rôle | Interdit |
|---|---|---|
| Interface (`frontend/src`) | Saisie, affichage, contrôles de confort | Règles métier, calculs, décisions de droits |
| Routes (`app/api`) | Validation des entrées (Pydantic), permission requise, sérialisation | Accès direct aux tables |
| Services (`app/services`) | Règles métier, transaction, audit dans la même transaction | Connaissance du HTTP |
| Exports (`app/exports`) | Mise en forme des rapports à partir de schémas | Requêtes en base |
| Données (`app/db`, `app/models`) | Schéma, contraintes, migrations | Règles métier |

Les futures formules d'ingénierie iront dans `app/calculations/` (Lot 2+),
pures, déterministes, testées isolément, jamais dans l'interface.

## Transactions

- Une session SQLAlchemy par requête ; chaque service valide explicitement
  (`commit`) en fin d'opération, l'entrée d'audit faisant partie de la même
  transaction. Toute exception provoque un `rollback`.
- Le pilote SQLite est configuré pour que `BEGIN` soit émis par SQLAlchemy :
  les migrations (DDL) sont donc réellement transactionnelles.
- Concurrence d'édition : numéro de révision par projet, conflit `409` en cas
  de révision périmée.

## Sécurité

Voir D-007 à D-009. Résumé : écoute locale uniquement, contrôle de l'en-tête
`Host`, Argon2id, jetons de 256 bits dont seule l'empreinte est stockée,
pas de cookie (pas de CSRF), CSP `default-src 'self'` (aucune ressource
externe : polices et scripts sont embarqués), droits vérifiés côté serveur sur
chaque route.

## Erreurs

Toutes les erreurs de l'API ont la forme :

```json
{ "detail": "Message en français pour l'utilisateur", "code": "code_stable", "errors": [{"field": "code", "message": "obligatoire"}] }
```

Les erreurs inattendues renvoient un message neutre ; la trace technique est
écrite dans `logs/routex.log`.
