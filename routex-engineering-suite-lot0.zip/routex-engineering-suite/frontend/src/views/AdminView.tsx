import { useCallback, useEffect, useState } from "react";
import { ApiError, request } from "../api";
import type { NoticeState } from "../components/Notice";
import { actionLabel, formatBytes, formatDateTime } from "../format";
import type { AuditEntry, AuditPage, Backup } from "../types";

const PAGE = 50;

function summarize(details: Record<string, unknown>): string {
  const parts: string[] = [];
  for (const [key, value] of Object.entries(details)) {
    if (key === "sha256") continue;
    if (value && typeof value === "object") parts.push(`${key} : ${JSON.stringify(value)}`);
    else parts.push(`${key} : ${String(value)}`);
  }
  return parts.join(" ; ");
}

export function AdminView({ notify }: { notify: (notice: NoticeState) => void }) {
  const [backups, setBackups] = useState<Backup[]>([]);
  const [entries, setEntries] = useState<AuditEntry[]>([]);
  const [total, setTotal] = useState(0);
  const [busy, setBusy] = useState(false);

  const loadBackups = useCallback(async () => {
    setBackups(await request<Backup[]>("GET", "/admin/backups"));
  }, []);

  const loadAudit = useCallback(async (offset: number) => {
    const page = await request<AuditPage>("GET", "/admin/audit-log", undefined, { limit: PAGE, offset });
    setTotal(page.total);
    setEntries((prev) => (offset === 0 ? page.items : [...prev, ...page.items]));
  }, []);

  useEffect(() => {
    Promise.all([loadBackups(), loadAudit(0)]).catch((e) =>
      notify({ kind: "error", text: e instanceof ApiError ? e.message : "Chargement impossible." }),
    );
  }, [loadBackups, loadAudit, notify]);

  async function backupNow() {
    setBusy(true);
    try {
      const b = await request<Backup>("POST", "/admin/backup");
      notify({ kind: "ok", text: `Sauvegarde ${b.file_name} créée (${formatBytes(b.size_bytes)}, intégrité vérifiée).` });
      await Promise.all([loadBackups(), loadAudit(0)]);
    } catch (e) {
      notify({ kind: "error", text: e instanceof ApiError ? e.message : "Sauvegarde impossible." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="page">
      <div className="page__head">
        <h1>Administration</h1>
      </div>

      <section className="panel" aria-labelledby="backup-title">
        <div className="panel__head">
          <h2 id="backup-title">Sauvegardes de la base</h2>
          <p className="small muted">
            Copie cohérente de la base, contrôlée avant d'être conservée dans le dossier « backups » des données RouteX.
            Une sauvegarde est aussi faite automatiquement avant chaque mise à jour du schéma. La restauration depuis
            l'interface arrivera au Lot 1 ; la procédure manuelle est décrite dans la documentation.
          </p>
        </div>
        <div className="panel__body stack">
          <button className="btn btn--primary" type="button" onClick={backupNow} disabled={busy}>
            {busy ? "Sauvegarde en cours…" : "Sauvegarder maintenant"}
          </button>
          {backups.length === 0 ? (
            <p className="muted">Aucune sauvegarde pour l'instant.</p>
          ) : (
            <div className="table-wrap">
              <table className="register register--static">
                <thead>
                  <tr>
                    <th scope="col">Fichier</th>
                    <th scope="col">Date</th>
                    <th scope="col">Taille</th>
                  </tr>
                </thead>
                <tbody>
                  {backups.map((b) => (
                    <tr key={b.file_name}>
                      <td>{b.file_name}</td>
                      <td className="nowrap">{formatDateTime(b.created_at)}</td>
                      <td className="nowrap">{formatBytes(b.size_bytes)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>

      <section className="panel" aria-labelledby="audit-title">
        <div className="panel__head">
          <h2 id="audit-title">Journal d'audit</h2>
          <p className="small muted">
            {total} opération(s) enregistrée(s), de la plus récente à la plus ancienne. Le journal n'est ni modifiable ni
            effaçable depuis l'application.
          </p>
        </div>
        <div className="table-wrap">
          <table className="register register--static">
            <thead>
              <tr>
                <th scope="col">Date</th>
                <th scope="col">Utilisateur</th>
                <th scope="col">Opération</th>
                <th scope="col">Détails</th>
              </tr>
            </thead>
            <tbody>
              {entries.map((e) => (
                <tr key={e.id}>
                  <td className="nowrap">{formatDateTime(e.at)}</td>
                  <td>{e.username || "—"}</td>
                  <td>{actionLabel(e.action)}</td>
                  <td className="small">{summarize(e.details)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {entries.length < total && (
          <div className="panel__body">
            <button className="btn" type="button" onClick={() => loadAudit(entries.length)}>
              Afficher les {Math.min(PAGE, total - entries.length)} suivantes
            </button>
          </div>
        )}
      </section>
    </main>
  );
}
