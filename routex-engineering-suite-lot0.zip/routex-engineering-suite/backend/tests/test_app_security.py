from __future__ import annotations

from pathlib import Path

from fastapi.testclient import TestClient

from app.core.config import Settings
from app.main import create_app


def test_health_is_public(client: TestClient) -> None:
    body = client.get("/api/v1/system/health").json()
    assert body["status"] == "ok" and body["app"] == "routex"


def test_security_headers(client: TestClient) -> None:
    r = client.get("/api/v1/system/health")
    assert "default-src 'self'" in r.headers["content-security-policy"]
    assert r.headers["x-frame-options"] == "DENY"
    assert r.headers["x-content-type-options"] == "nosniff"
    assert r.headers["cache-control"] == "no-store"


def test_foreign_host_header_is_refused(client: TestClient) -> None:
    """Protection contre le DNS rebinding (D-009)."""
    assert client.get("/api/v1/system/health", headers={"Host": "attaquant.example"}).status_code == 400
    assert client.get("/api/v1/system/health", headers={"Host": "localhost:5173"}).status_code == 200


def test_docs_disabled_in_production_enabled_in_dev(tmp_path: Path) -> None:
    prod = create_app(Settings(data_dir=tmp_path / "p", frontend_dist=None))
    dev = create_app(Settings(data_dir=tmp_path / "d", frontend_dist=None, dev_mode=True))
    with TestClient(prod, base_url="http://127.0.0.1") as c:
        assert c.get("/docs").status_code == 404
        assert c.get("/openapi.json").status_code == 404
    with TestClient(dev, base_url="http://127.0.0.1") as c:
        assert c.get("/docs").status_code == 200
        assert "content-security-policy" not in c.get("/docs").headers
        assert c.get("/openapi.json").json()["info"]["version"]
    prod.state.engine.dispose()
    dev.state.engine.dispose()


def test_unknown_api_route_returns_json(client: TestClient) -> None:
    r = client.get("/api/v1/inexistant")
    assert r.status_code == 404 and r.json()["code"] == "http_404"


def test_frontend_served_when_built(tmp_path: Path) -> None:
    dist = tmp_path / "dist"
    (dist / "assets").mkdir(parents=True)
    (dist / "index.html").write_text("<!doctype html><title>RouteX</title><div id=root></div>", encoding="utf-8")
    (dist / "assets" / "app.js").write_text("console.log('ok')", encoding="utf-8")
    app = create_app(Settings(data_dir=tmp_path / "data", frontend_dist=dist))
    with TestClient(app, base_url="http://127.0.0.1") as c:
        assert "<title>RouteX</title>" in c.get("/").text
        assert c.get("/assets/app.js").status_code == 200
        assert c.get("/api/v1/system/health").json()["status"] == "ok"  # l'API n'est pas masquée
    app.state.engine.dispose()


def test_notice_page_when_frontend_missing(client: TestClient) -> None:
    r = client.get("/")
    assert r.status_code == 200 and "npm run build" in r.text
