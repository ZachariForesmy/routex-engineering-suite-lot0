# Feuille de route — RouteX Engineering Suite

Chaque lot se termine par une version exécutable, des tests, une
documentation à jour et une démonstration reproductible. Un lot n'est marqué
« terminé » que si ses critères de sortie sont vérifiés.

Légende : ✅ terminé et vérifié · 🟡 en cours / partiel · ⬜ à faire

---

## Lot 0 — Cadrage et preuve technique · 🟡 (version de développement)

| Élément                                                     | État |
|-------------------------------------------------------------|------|
| Inspection de l'environnement, choix de la stack, licences  | ✅ |
| Dépôt Git, structure, conventions                           | ✅ |
| `DECISIONS.md`, `ROADMAP.md`, `TEST_PLAN.md`                 | ✅ |
| Base SQLite + migration initiale Alembic                    | ✅ |
| Premier compte administrateur, connexion, rôles (backend)   | ✅ |
| Projets : création, liste, recherche, modification, archivage | ✅ |
| Journal d'audit                                             | ✅ |
| Export PDF / XLSX / CSV (liste et fiche projet)             | ✅ |
| Sauvegarde manuelle + sauvegarde avant migration            | ✅ |
| Interface React servie localement                           | ✅ |
| Tests automatisés backend + frontend + parcours navigateur  | ✅ |
| Recette PyInstaller vérifiée sous Linux (12 contrôles)      | ✅ |
| Paquet Linux vérifié sans accès réseau                      | ✅ |
| **Build et test sur Windows propre**                        | ⬜ |
| **Test de démarrage réseau désactivé sur Windows (TX-013)** | ⬜ |

**Sortie attendue :** application squelette qui démarre localement — atteinte
en développement et en paquet Linux ; la validation sur Windows reste à faire
(`scripts/build-windows.ps1` puis `docs/RELEASE_CHECKLIST.md`).

## Lot 1 — Socle · ⬜
- Build Windows vérifié, installateur (Inno Setup envisagé), raccourci menu
  Démarrer, icône, bouton « Quitter ».
- Restauration de sauvegarde depuis l'interface (vérification, confirmation,
  sauvegarde préalable de la base courante) ; sauvegarde automatique.
- Paramètres par projet étendus (`project_settings`), disciplines,
  références techniques (`reference_standards`, `project_standards`).
- Documents et pièces jointes avec révisions (`documents`,
  `document_revisions`) ; fichiers sources jamais écrasés.
- Membres de projet (`project_memberships`) et droits par projet.
- Limitation des tentatives de connexion ; changement de mot de passe forcé.
- Page de garde et pied de page configurables des rapports.
- Manuel utilisateur (`USER_GUIDE.md`), `BACKUP_RESTORE.md` complet.

## Lot 2 — Métrés · ⬜
- Bibliothèque d'ouvrages, unités et conversions testées (TX-003).
- Formules documentées (`ENGINEERING_FORMULAS.md`), stockage `Decimal`.
- Saisie et calcul des quantités, traçabilité des calculs (entrées, formule,
  unités, version du moteur, date) ; alerte de calcul obsolète (TX-018).
- Fiches de calcul PDF/XLSX.

## Lot 3 — Estimations · ⬜
- BPU, DQE, sous-détails de prix ; taxes et arrondis paramétrables.
- Historique des prix et des versions (TX-004, TX-005).
- Dossier quantitatif et estimatif exportable.

## Lot 4 — Attachements et décomptes · ⬜
- Mesures périodiques, quantités présentées/vérifiées/acceptées/cumulées
  (TX-006) ; circuit de validation ; décompte provisoire.

## Lot 5 — Planning · ⬜
- WBS, tâches, calendriers, dépendances, Gantt, chemin critique, détection
  de cycles (TX-007), avancement, ressources, baseline.

## Lot 6 — CAO et topographie · ⬜
- Import de points CSV/TXT avec prévisualisation et rejet documenté (TX-008,
  TX-017) ; import/export DXF via `ezdxf` (TX-009). Pas de DWG natif.

## Lot 7 — Géométrie routière et cubatures · ⬜
- Axes, profils, sections, volumes ; cas de référence **validés par un
  ingénieur** avant activation (TX-015).

## Lot 8 — Drainage, assainissement et AEP · ⬜
- Hydrologie et hydraulique (rationnelle, Manning…), réseaux ramifiés puis
  maillés ; activation après validation (TX-016).
