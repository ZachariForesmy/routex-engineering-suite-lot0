from __future__ import annotations

import socket
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app import launcher
from app.core.config import Settings
from app.main import create_app
from tests.conftest import ADMIN


@pytest.fixture
def data_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Settings:
    monkeypatch.setenv("ROUTEX_DATA_DIR", str(tmp_path / "data"))
    return Settings.from_env()


def test_probe_detects_free_and_busy_ports() -> None:
    port = launcher._free_port()
    assert launcher._probe(port) == "libre"
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        sock.listen()
        assert launcher._probe(sock.getsockname()[1]) == "occupe"


def test_info_command(data_env: Settings, capsys: pytest.CaptureFixture[str]) -> None:
    assert launcher.main(["info"]) == 0
    assert str(data_env.db_path) in capsys.readouterr().out


def test_backup_command_creates_verified_copy(data_env: Settings, capsys: pytest.CaptureFixture[str]) -> None:
    assert launcher.main(["backup"]) == 0
    out = capsys.readouterr().out
    assert "intégrité : ok" in out
    assert len(list(data_env.backups_dir.glob("routex_*_console.sqlite3"))) == 1


def test_reset_password_command(data_env: Settings, monkeypatch: pytest.MonkeyPatch) -> None:
    app = create_app(data_env)
    with TestClient(app, base_url="http://127.0.0.1") as c:
        c.post("/api/v1/auth/setup", json=ADMIN)
    app.state.engine.dispose()

    answers = iter(["court", "nouveau-secret-2026", "nouveau-secret-2026"])
    monkeypatch.setattr(launcher.getpass, "getpass", lambda _prompt="": next(answers))
    assert launcher.main(["reset-password", "admin"]) == 0

    app = create_app(data_env)
    with TestClient(app, base_url="http://127.0.0.1") as c:
        assert c.post("/api/v1/auth/login", json={"username": "admin", "password": ADMIN["password"]}).status_code == 401
        assert c.post("/api/v1/auth/login", json={"username": "admin", "password": "nouveau-secret-2026"}).status_code == 200
    app.state.engine.dispose()


def test_reset_password_unknown_user_reports_error(data_env: Settings, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]) -> None:
    monkeypatch.setattr(launcher.getpass, "getpass", lambda _prompt="": "mot-de-passe-valide")
    assert launcher.main(["reset-password", "fantome"]) == 2
    assert "Aucun compte « fantome »" in capsys.readouterr().out


def test_invalid_configuration_is_reported_in_french(monkeypatch: pytest.MonkeyPatch, tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    monkeypatch.setenv("ROUTEX_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("ROUTEX_PORT", "pas-un-nombre")
    assert launcher.main(["info"]) == 2
    assert "ne peut pas démarrer" in capsys.readouterr().out
