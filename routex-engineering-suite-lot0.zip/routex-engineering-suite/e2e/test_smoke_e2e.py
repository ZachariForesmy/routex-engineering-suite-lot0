"""Parcours de bout en bout dans un vrai navigateur (Playwright).

Démarre l'application comme un utilisateur final (lanceur, base neuve dans un
dossier temporaire, interface compilée), puis : premier compte administrateur,
création / recherche / modification / archivage d'un projet, exports PDF et
Excel, compte technicien en lecture, sauvegarde.

Prérequis : interface compilée (frontend/dist), `pip install playwright` puis
`python -m playwright install chromium`.

    cd backend && .venv/bin/python -m pytest ../e2e -q
Captures d'écran : définir ROUTEX_E2E_SCREENSHOTS=<dossier>.
"""

from __future__ import annotations

import os
import socket
import subprocess
import sys
import time
import urllib.request
from collections.abc import Iterator
from pathlib import Path

import pytest

playwright = pytest.importorskip("playwright.sync_api")
from playwright.sync_api import Page, expect, sync_playwright  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
DIST = ROOT / "frontend" / "dist"
SHOTS = os.environ.get("ROUTEX_E2E_SCREENSHOTS")


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


@pytest.fixture(scope="module")
def server(tmp_path_factory: pytest.TempPathFactory) -> Iterator[str]:
    if not (DIST / "index.html").exists():
        pytest.skip("Interface non compilée : lancez `npm run build` dans frontend/.")
    port = _free_port()
    env = {**os.environ, "ROUTEX_DATA_DIR": str(tmp_path_factory.mktemp("e2e-data")), "ROUTEX_FRONTEND_DIST": str(DIST)}
    proc = subprocess.Popen(
        [sys.executable, "-m", "app.launcher", "--no-browser", "--port", str(port)],
        cwd=BACKEND, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
    )
    base = f"http://127.0.0.1:{port}"
    for _ in range(80):
        try:
            urllib.request.urlopen(f"{base}/api/v1/system/health", timeout=1)
            break
        except OSError:
            time.sleep(0.25)
    else:
        proc.kill()
        raise RuntimeError(proc.stdout.read().decode() if proc.stdout else "serveur non démarré")
    yield base
    proc.terminate()
    proc.wait(timeout=10)


def _shot(page: Page, name: str) -> None:
    if SHOTS:
        Path(SHOTS).mkdir(parents=True, exist_ok=True)
        page.screenshot(path=str(Path(SHOTS) / f"{name}.png"), full_page=True)


def test_parcours_complet(server: str, tmp_path: Path) -> None:
    console_errors: list[str] = []
    with sync_playwright() as p:
        browser = p.chromium.launch()
        context = browser.new_context(accept_downloads=True, viewport={"width": 1440, "height": 900}, locale="fr-FR")
        page = context.new_page()
        page.on("console", lambda m: console_errors.append(m.text) if m.type == "error" else None)

        # 1. Premier démarrage
        page.goto(server)
        expect(page.get_by_role("heading", name="Premier démarrage")).to_be_visible()
        _shot(page, "01-premier-demarrage")
        page.get_by_label("Nom complet").fill("Zachari Foresmy")
        page.get_by_label("Mot de passe", exact=True).fill("motdepasse-solide-2026")
        page.get_by_label("Confirmer le mot de passe").fill("motdepasse-solide-2026")
        page.get_by_role("button", name="Créer le compte administrateur").click()

        # 2. Registre vide puis création
        expect(page.get_by_text("Aucun projet pour l'instant.")).to_be_visible()
        _shot(page, "02-registre-vide")
        page.get_by_role("button", name="Créer le premier projet").click()
        expect(page.get_by_label("Devise")).to_have_value("HTG")
        page.get_by_role("button", name="Créer le projet").click()
        expect(page.get_by_text("Le code est obligatoire.")).to_be_visible()  # validation immédiate
        page.get_by_label("Code projet").fill("RTX-2026-001")
        page.get_by_role("textbox", name="Intitulé", exact=True).fill("Réhabilitation de la route Delmas 33")
        page.get_by_label("Maître d'ouvrage", exact=True).fill("Ministère des Travaux publics (MTPTC)")
        page.get_by_label("Localisation", exact=True).fill("Delmas")
        page.get_by_label("Date de début").fill("2026-11-02")
        page.get_by_label("Date de fin").fill("2027-06-30")
        page.get_by_label("Description").fill("Chaussée en béton bitumineux, caniveaux latéraux et dalots.")
        page.get_by_role("button", name="Créer le projet").click()
        expect(page.get_by_role("status")).to_contain_text("Projet RTX-2026-001 créé.")

        for code, name, client, loc in [
            ("AEP-2026-004", "Adduction d'eau potable de Jacmel, réseau ramifié", "DINEPA", "Jacmel"),
            ("VRD-2026-007", "Voirie et réseaux divers, lotissement Tabarre", "Mairie de Tabarre", "Tabarre"),
        ]:
            page.get_by_role("button", name="Nouveau projet").click()
            page.get_by_label("Code projet").fill(code)
            page.get_by_role("textbox", name="Intitulé", exact=True).fill(name)
            page.get_by_label("Maître d'ouvrage", exact=True).fill(client)
            page.get_by_label("Localisation", exact=True).fill(loc)
            page.get_by_role("button", name="Créer le projet").click()
            expect(page.get_by_role("status")).to_contain_text(f"Projet {code} créé.")

        # 3. Recherche
        page.get_by_label("Rechercher").fill("dinepa")
        expect(page.locator("table.register tbody tr")).to_have_count(1)
        page.get_by_label("Rechercher").fill("")
        expect(page.locator("table.register tbody tr")).to_have_count(3)

        # 4. Fiche et modification
        page.get_by_role("button", name="RTX-2026-001").click()
        expect(page.get_by_role("heading", name="Réhabilitation de la route Delmas 33")).to_be_visible()
        _shot(page, "03-registre-et-fiche")
        page.get_by_role("button", name="Modifier").click()
        page.get_by_role("textbox", name="Intitulé", exact=True).fill("Réhabilitation de la route Delmas 33, tronçon 1")
        _shot(page, "04-modification")
        page.get_by_role("button", name="Enregistrer les modifications").click()
        expect(page.get_by_role("status")).to_contain_text("révision 2")

        # 5. Exports
        with page.expect_download() as dl:
            page.get_by_role("button", name="Fiche PDF").click()
        pdf = tmp_path / dl.value.suggested_filename
        dl.value.save_as(pdf)
        assert pdf.name == "RouteX_fiche_RTX-2026-001_r2.pdf" and pdf.read_bytes().startswith(b"%PDF-")
        with page.expect_download() as dl:
            page.get_by_role("group", name="Exporter la liste affichée").get_by_role("button", name="Excel").click()
        xlsx = tmp_path / dl.value.suggested_filename
        dl.value.save_as(xlsx)
        assert xlsx.suffix == ".xlsx" and xlsx.read_bytes()[:2] == b"PK"

        # 6. Archivage
        page.get_by_role("button", name="AEP-2026-004").click()
        page.once("dialog", lambda d: d.accept())
        page.get_by_role("button", name="Archiver").click()
        expect(page.get_by_role("status")).to_contain_text("archivé")
        expect(page.locator("table.register tbody tr")).to_have_count(2)
        page.get_by_label("Inclure les archivés").check()
        expect(page.locator("table.register tbody tr")).to_have_count(3)

        # 7. Utilisateurs : compte technicien
        page.get_by_role("navigation").get_by_role("button", name="Utilisateurs").click()
        page.get_by_role("button", name="Nouveau compte").click()
        page.get_by_label("Identifiant").fill("tech.pierre")
        page.get_by_label("Nom complet").fill("Pierre Joseph")
        page.get_by_label("Mot de passe initial").fill("technicien-2026")
        page.get_by_role("button", name="Créer le compte").click()
        expect(page.get_by_role("status")).to_contain_text("tech.pierre")
        _shot(page, "05-utilisateurs")

        # 8. Sauvegarde et journal
        page.get_by_role("navigation").get_by_role("button", name="Administration").click()
        page.get_by_role("button", name="Sauvegarder maintenant").click()
        expect(page.get_by_role("status")).to_contain_text("intégrité vérifiée")
        expect(page.get_by_text("Export PDF").first).to_be_visible()
        _shot(page, "06-administration")

        # 9. Le technicien voit les projets mais ne peut pas les modifier
        page.get_by_role("button", name="Se déconnecter").click()
        page.get_by_label("Identifiant").fill("tech.pierre")
        page.get_by_label("Mot de passe", exact=True).fill("technicien-2026")
        page.get_by_role("button", name="Se connecter").click()
        expect(page.locator("table.register tbody tr")).to_have_count(2)
        expect(page.get_by_role("button", name="Nouveau projet")).to_have_count(0)
        page.get_by_role("button", name="RTX-2026-001").click()
        expect(page.get_by_role("button", name="Modifier")).to_have_count(0)
        expect(page.get_by_role("button", name="Fiche PDF")).to_be_visible()
        expect(page.get_by_role("navigation").get_by_role("button", name="Utilisateurs")).to_have_count(0)
        _shot(page, "07-technicien")

        # 10. Affichage étroit (tablette / petit écran)
        page.set_viewport_size({"width": 390, "height": 844})
        _shot(page, "08-mobile")
        browser.close()

    assert console_errors == [], console_errors
