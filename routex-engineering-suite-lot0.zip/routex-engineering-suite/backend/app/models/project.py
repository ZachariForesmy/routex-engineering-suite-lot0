from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import CheckConstraint, Date, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.timeutil import utcnow
from app.db.base import Base, UTCDateTime, new_uuid

PROJECT_STATUSES = ("actif", "archive")
UNIT_SYSTEMS = ("SI",)


class Project(Base):
    __tablename__ = "projects"
    __table_args__ = (
        CheckConstraint("status IN ('actif', 'archive')", name="statut_valide"),
        CheckConstraint("unit_system IN ('SI')", name="systeme_unites_valide"),
        CheckConstraint("length(currency) = 3", name="devise_iso"),
        CheckConstraint(
            "start_date IS NULL OR end_date IS NULL OR end_date >= start_date", name="dates_coherentes"
        ),
        CheckConstraint("revision >= 1", name="revision_positive"),
        Index("ix_projects_status", "status"),
        Index("ix_projects_name", "name"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    code: Mapped[str] = mapped_column(String(40, collation="NOCASE"), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    client: Mapped[str] = mapped_column(String(200), default="")
    location: Mapped[str] = mapped_column(String(200), default="")
    country: Mapped[str] = mapped_column(String(100), default="")
    currency: Mapped[str] = mapped_column(String(3))
    unit_system: Mapped[str] = mapped_column(String(10), default="SI")
    description: Mapped[str] = mapped_column(Text, default="")
    start_date: Mapped[date | None] = mapped_column(Date, default=None)
    end_date: Mapped[date | None] = mapped_column(Date, default=None)
    status: Mapped[str] = mapped_column(String(20), default="actif")
    archived_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), default=None)
    revision: Mapped[int] = mapped_column(Integer, default=1)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    updated_by: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
