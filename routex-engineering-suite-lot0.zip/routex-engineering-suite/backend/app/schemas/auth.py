from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel

from app.schemas.common import StrictModel, text
from app.schemas.user import FullName, MeOut, Password, Username


Required64 = text(64, min_length=1)
Required256 = text(256, min_length=1)


class AuthStatusOut(BaseModel):
    app_name: str
    version: str
    setup_required: bool
    default_currency: str
    default_country: str


class SetupIn(StrictModel):
    username: Username
    full_name: FullName
    password: Password


class LoginIn(StrictModel):
    username: Required64
    password: Required256


class SessionOut(BaseModel):
    token: str
    expires_at: datetime
    user: MeOut


class ChangePasswordIn(StrictModel):
    current_password: Required256
    new_password: Password
