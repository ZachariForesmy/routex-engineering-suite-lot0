"""Éléments communs aux rapports (D-012)."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from datetime import datetime

from app import APP_NAME, __version__
from app.schemas.project import ProjectOut

STATUS_LABELS = {"actif": "Actif", "archive": "Archivé"}
UNIT_SYSTEM_LABELS = {"SI": "Système international (métrique)"}

# Colonnes des exports « liste des projets » : (clé, libellé)
PROJECT_LIST_COLUMNS: tuple[tuple[str, str], ...] = (
    ("code", "Code"),
    ("name", "Intitulé"),
    ("client", "Maître d'ouvrage"),
    ("location", "Localisation"),
    ("country", "Pays"),
    ("currency", "Devise"),
    ("start_date", "Début"),
    ("end_date", "Fin"),
    ("status", "Statut"),
)


@dataclass(frozen=True)
class ReportMeta:
    title: str
    generated_at: datetime
    author: str
    filters: dict[str, str] = field(default_factory=dict)
    app_name: str = APP_NAME
    app_version: str = __version__


@dataclass(frozen=True)
class RenderedReport:
    content: bytes
    media_type: str
    file_name: str

    @property
    def sha256(self) -> str:
        return hashlib.sha256(self.content).hexdigest()

    @property
    def size_bytes(self) -> int:
        return len(self.content)


def describe_list_filters(q: str, include_archived: bool) -> dict[str, str]:
    return {
        "Recherche": f"« {q.strip()} »" if q.strip() else "(aucune)",
        "Projets archivés": "inclus" if include_archived else "exclus",
    }


def safe_file_part(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "-", value).strip("-.")
    return cleaned[:60] or "projet"


def timestamp_for_file(dt: datetime) -> str:
    return dt.astimezone().strftime("%Y%m%d-%H%M")


def project_fields(project: ProjectOut) -> list[tuple[str, str]]:
    """Champs de la fiche projet, dans l'ordre d'affichage."""
    from app.core.timeutil import format_date, format_local_datetime

    return [
        ("Code", project.code),
        ("Intitulé", project.name),
        ("Maître d'ouvrage", project.client or "—"),
        ("Localisation", project.location or "—"),
        ("Pays", project.country or "—"),
        ("Devise", project.currency),
        ("Système d'unités", UNIT_SYSTEM_LABELS.get(project.unit_system, project.unit_system)),
        ("Date de début", format_date(project.start_date) or "—"),
        ("Date de fin", format_date(project.end_date) or "—"),
        ("Statut", STATUS_LABELS.get(project.status, project.status)),
        ("Révision", str(project.revision)),
        ("Créé le", f"{format_local_datetime(project.created_at)} par {project.created_by_name}"),
        ("Dernière modification", f"{format_local_datetime(project.updated_at)} par {project.updated_by_name}"),
    ]
