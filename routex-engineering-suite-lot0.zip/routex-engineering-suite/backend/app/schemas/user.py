from __future__ import annotations

from datetime import datetime
from typing import Annotated

from pydantic import StringConstraints, computed_field

from app.core.permissions import ROLE_LABELS, Role, permissions_for
from app.core.security import MIN_PASSWORD_LENGTH
from app.schemas.common import OutModel, StrictModel, text

Username = Annotated[
    str,
    StringConstraints(strip_whitespace=True, min_length=3, max_length=64, pattern=r"^[A-Za-z0-9._-]+$"),
]
Password = Annotated[str, StringConstraints(min_length=MIN_PASSWORD_LENGTH, max_length=256)]
FullName = text(120, min_length=1)


class UserOut(OutModel):
    id: str
    username: str
    full_name: str
    role: Role
    is_active: bool
    created_at: datetime
    last_login_at: datetime | None

    @computed_field  # type: ignore[prop-decorator]
    @property
    def role_label(self) -> str:
        return ROLE_LABELS[self.role]


class MeOut(UserOut):
    @computed_field  # type: ignore[prop-decorator]
    @property
    def permissions(self) -> list[str]:
        return permissions_for(self.role)


class UserCreateIn(StrictModel):
    username: Username
    full_name: FullName
    role: Role
    password: Password


class UserUpdateIn(StrictModel):
    full_name: FullName | None = None
    role: Role | None = None
    is_active: bool | None = None
    new_password: Password | None = None
