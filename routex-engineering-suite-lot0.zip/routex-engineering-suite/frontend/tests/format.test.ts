import { describe, expect, it } from "vitest";
import {
  changedFields,
  draftFromProject,
  draftToPayload,
  emptyDraft,
  formatBytes,
  formatDate,
  statusLabel,
  validateDraft,
} from "../src/format";
import type { Project } from "../src/types";

const project: Project = {
  id: "p1",
  code: "RTX-2026-001",
  name: "Route Delmas 33",
  client: "MTPTC",
  location: "Delmas",
  country: "Haïti",
  currency: "HTG",
  unit_system: "SI",
  description: "",
  start_date: "2026-11-01",
  end_date: null,
  status: "actif",
  archived_at: null,
  revision: 3,
  created_at: "2026-10-20T23:58:36Z",
  updated_at: "2026-10-20T23:58:36Z",
  created_by_name: "Admin",
  updated_by_name: "Admin",
};

describe("formatage", () => {
  it("affiche les dates calendaires au format français sans décalage de fuseau", () => {
    expect(formatDate("2026-11-01")).toBe("01/11/2026");
    expect(formatDate(null)).toBe("");
  });

  it("libellés de statut", () => {
    expect(statusLabel("actif")).toBe("Actif");
    expect(statusLabel("archive")).toBe("Archivé");
  });

  it("tailles de fichier en unités françaises", () => {
    expect(formatBytes(512)).toBe("512 o");
    expect(formatBytes(73728)).toBe("72,0 Ko");
  });
});

describe("formulaire projet", () => {
  it("valide les champs obligatoires et la cohérence des dates", () => {
    const errors = validateDraft({ ...emptyDraft(), code: "avec espace", name: " ", currency: "EURO", start_date: "2027-01-01", end_date: "2026-01-01" });
    expect(Object.keys(errors).sort()).toEqual(["code", "currency", "end_date", "name"]);
    expect(validateDraft({ ...emptyDraft(), code: "RTX-1", name: "Route" })).toEqual({});
  });

  it("convertit les dates vides en null et la devise en majuscules", () => {
    const payload = draftToPayload({ ...emptyDraft("usd"), code: " A-1 ", name: "Route" });
    expect(payload).toMatchObject({ code: "A-1", currency: "USD", start_date: null, end_date: null });
  });

  it("n'envoie que les champs réellement modifiés", () => {
    const draft = draftFromProject(project);
    expect(changedFields(project, draft)).toEqual({});
    expect(changedFields(project, { ...draft, name: "Route Delmas 33 — tronçon 1", start_date: "" })).toEqual({
      name: "Route Delmas 33 — tronçon 1",
      start_date: null,
    });
  });
});
