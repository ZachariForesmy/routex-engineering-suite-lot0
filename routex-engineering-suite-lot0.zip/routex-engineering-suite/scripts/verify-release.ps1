#Requires -Version 5.1
<#
.SYNOPSIS
    Verifie un paquet RouteX deja construit (demarrage, exports, sauvegarde,
    persistance apres redemarrage) sur une base neuve temporaire.

        powershell -ExecutionPolicy Bypass -File scripts\verify-release.ps1
        powershell -ExecutionPolicy Bypass -File scripts\verify-release.ps1 -Exe D:\RouteX\RouteX.exe

    Necessite Python 3.12+ (bibliotheque standard uniquement). Sur un poste
    sans Python, suivre la recette manuelle de docs\RELEASE_CHECKLIST.md.
#>
[CmdletBinding()]
param(
    [string]$Exe = "",
    [string]$Python = "python"
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
if (-not $Exe) { $Exe = Join-Path $Root "dist\RouteX\RouteX.exe" }
if (-not (Test-Path $Exe)) { throw "Executable introuvable : $Exe (lancez d'abord scripts\build-windows.ps1)." }

& $Python -I (Join-Path $Root "scripts\verify_release.py") $Exe
exit $LASTEXITCODE
