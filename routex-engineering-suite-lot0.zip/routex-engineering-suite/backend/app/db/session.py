"""Moteur SQLite et fabrique de sessions (D-004).

Le pilote ``sqlite3`` n'émet pas ``BEGIN`` avant les instructions DDL, ce qui
rend les migrations non transactionnelles. On applique la recette documentée
par SQLAlchemy : le pilote passe en mode autocommit et SQLAlchemy émet
lui-même ``BEGIN`` au début de chaque transaction. Les PRAGMA de connexion
s'exécutent ainsi hors transaction (où ils sont effectifs).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from sqlalchemy import Connection, Engine, create_engine, event
from sqlalchemy.orm import Session, sessionmaker


def sqlite_url(db_path: Path) -> str:
    return f"sqlite:///{db_path.as_posix()}"


def _on_connect(dbapi_connection: Any, _record: Any) -> None:
    dbapi_connection.isolation_level = None  # SQLAlchemy gère BEGIN (voir _on_begin)
    for pragma in (
        "PRAGMA foreign_keys=ON",
        "PRAGMA journal_mode=WAL",
        "PRAGMA synchronous=FULL",
        "PRAGMA busy_timeout=5000",
    ):
        dbapi_connection.execute(pragma)


def _on_begin(conn: Connection) -> None:
    conn.exec_driver_sql("BEGIN")


def make_engine(db_path: Path) -> Engine:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    engine = create_engine(sqlite_url(db_path), connect_args={"check_same_thread": False})
    event.listen(engine, "connect", _on_connect)
    event.listen(engine, "begin", _on_begin)
    return engine


def make_sessionmaker(engine: Engine) -> sessionmaker[Session]:
    return sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
