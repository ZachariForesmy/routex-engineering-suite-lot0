from __future__ import annotations

from typing import Annotated

from pydantic import BaseModel, ConfigDict, StringConstraints

# Chaînes nettoyées des espaces de bord.
NonEmpty = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1)]


def text(max_length: int, min_length: int = 0) -> type[str]:
    return Annotated[  # type: ignore[return-value]
        str, StringConstraints(strip_whitespace=True, min_length=min_length, max_length=max_length)
    ]


class StrictModel(BaseModel):
    """Refuse les champs inconnus : une faute de frappe côté client doit être
    signalée plutôt qu'ignorée silencieusement."""

    model_config = ConfigDict(extra="forbid")


class OutModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class FieldError(BaseModel):
    field: str
    message: str


class ErrorOut(BaseModel):
    detail: str
    code: str
    errors: list[FieldError] = []
