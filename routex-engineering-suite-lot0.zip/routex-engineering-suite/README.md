# RouteX Engineering Suite

Application de bureau locale pour préparer et gérer les études et dossiers
d'exécution de routes, VRD, drainage/assainissement, AEP et réseaux divers.
Elle fonctionne **sans connexion Internet** et conserve ses données dans une
base SQLite sur le poste.

> **Statut : version de développement 0.1.0.dev0 — Lot 0.**
> Socle technique uniquement : comptes et rôles, gestion de projets, journal
> d'audit, exports PDF/XLSX/CSV, sauvegarde. **Aucun calcul d'ingénierie n'est
> encore implémenté.** Le paquet Windows n'a pas encore été construit ni testé
> sur Windows (voir « Limites connues »).

Spécification de référence : [`ROUTEX_HANDOFF_SPEC.md`](ROUTEX_HANDOFF_SPEC.md).
Décisions et écarts : [`docs/DECISIONS.md`](docs/DECISIONS.md).

---

## Ce qui fonctionne (Lot 0)

| Domaine | Fonctions |
|---|---|
| Premier lancement | Création du compte administrateur, puis connexion obligatoire |
| Comptes | 4 rôles contrôlés par l'API (administrateur, ingénieur, technicien, lecture) ; création, changement de rôle, désactivation, réinitialisation de mot de passe |
| Projets | Création, recherche, modification avec contrôle de révision (pas d'écrasement silencieux), archivage réversible |
| Exports | Liste des projets en PDF / Excel / CSV ; fiche projet en PDF / Excel ; chaque export est tracé (empreinte SHA-256) |
| Traçabilité | Journal d'audit de toutes les opérations (connexions, modifications avec valeurs avant/après, exports, sauvegardes) |
| Sauvegarde | Sauvegarde à chaud avec contrôle d'intégrité (interface et ligne de commande) ; sauvegarde automatique avant toute migration de schéma |
| Sécurité locale | Écoute sur 127.0.0.1 uniquement, Argon2id, jetons de session hachés, en-têtes de sécurité, contrôle de l'en-tête Host |

## Démarrage rapide — développement

Prérequis : Python 3.12+ et Node.js 22+.

**Windows (PowerShell)**

```powershell
powershell -ExecutionPolicy Bypass -File scripts\dev-start.ps1
```

**Linux / macOS**

```bash
bash scripts/dev-start.sh
```

Puis ouvrir <http://127.0.0.1:5173>. Le backend tourne sur
<http://127.0.0.1:8765> (documentation interactive de l'API sur `/docs` en mode
développement). Les données de développement sont dans `.dev-data/`.

Installation manuelle équivalente :

```bash
cd backend
python -m venv .venv
.venv/bin/pip install -c requirements-lock.txt -e ".[dev]"      # Windows : .venv\Scripts\pip
ROUTEX_DEV=1 ROUTEX_DATA_DIR=../.dev-data .venv/bin/uvicorn app.main:create_app --factory --port 8765

cd ../frontend
npm ci
npm run dev
```

## Tests

```bash
cd backend  && .venv/bin/python -m pytest -q          # 71 tests (API, migrations, droits, exports, sauvegarde, lanceur)
cd frontend && npm test                               # 13 tests (client API, formatage, validation)
cd frontend && npm run build                          # vérification TypeScript + compilation
cd backend  && .venv/bin/python -m pytest ../e2e -q   # parcours complet dans Chromium (Playwright)
```

Le parcours navigateur nécessite `pip install -e ".[e2e]"` puis
`python -m playwright install chromium` ; il est ignoré si l'interface n'est
pas compilée.

Détail des tests et de la matrice d'acceptation : [`docs/TEST_PLAN.md`](docs/TEST_PLAN.md).

## Construire le paquet Windows

Sur un poste **Windows** avec Python 3.12+ (64 bits) et Node.js 22+ :

```powershell
powershell -ExecutionPolicy Bypass -File scripts\build-windows.ps1
```

Le script installe les dépendances épinglées, compile l'interface, exécute les
tests, construit `dist\RouteX\RouteX.exe` avec PyInstaller, vérifie le paquet
(démarrage, exports, sauvegarde, persistance) et produit
`dist\RouteX-<version>-windows-x64.zip` avec son empreinte SHA-256.

Sous Linux, `scripts/build-linux.sh` applique la même recette ; c'est elle qui
a servi à valider le packaging (voir Limites connues).

Installation et utilisation sur le poste final : [`docs/INSTALL_WINDOWS.md`](docs/INSTALL_WINDOWS.md).

## Structure du dépôt

```text
backend/           API FastAPI, services métier, base SQLite, exports
  app/api/         routes HTTP, dépendances (authentification, permissions), erreurs
  app/core/        configuration, sécurité, rôles, journalisation
  app/db/          moteur SQLite, préparation et migration de la base
  app/models/      modèles SQLAlchemy
  app/schemas/     schémas Pydantic (entrées/sorties de l'API)
  app/services/    règles métier (projets, comptes, audit, sauvegarde)
  app/exports/     rapports PDF (ReportLab), XLSX (openpyxl), CSV
  app/launcher.py  point d'entrée de l'application empaquetée
  migrations/      migrations Alembic versionnées
  tests/           tests pytest
frontend/          interface React + TypeScript (Vite)
e2e/               parcours navigateur (Playwright)
packaging/         recette PyInstaller
scripts/           lancement, build et vérification (Windows et Linux)
docs/              décisions, feuille de route, plan de test, architecture…
```

Les dossiers `calculations/` et `cad/` du §6 de la spécification seront créés
avec les lots qui les utilisent (Lot 2 et Lot 6), afin de ne pas livrer de
modules vides.

## Documentation

| Document | Contenu |
|---|---|
| [DECISIONS.md](docs/DECISIONS.md) | Choix techniques, valeurs provisoires, points reportés |
| [ROADMAP.md](docs/ROADMAP.md) | Lots, état d'avancement |
| [TEST_PLAN.md](docs/TEST_PLAN.md) | Stratégie de test, matrice TX-001…TX-018, résultats |
| [ARCHITECTURE.md](docs/ARCHITECTURE.md) | Couches, flux, sécurité |
| [DATABASE.md](docs/DATABASE.md) | Schéma, conventions, procédure de migration |
| [API.md](docs/API.md) | Routes, permissions, format des erreurs ; `openapi.json` |
| [INSTALL_WINDOWS.md](docs/INSTALL_WINDOWS.md) | Installation, premier lancement, mot de passe perdu |
| [BACKUP_RESTORE.md](docs/BACKUP_RESTORE.md) | Sauvegarde et restauration |
| [RELEASE_CHECKLIST.md](docs/RELEASE_CHECKLIST.md) | Recette avant livraison |

## Limites connues

1. **Le paquet Windows n'a pas été construit ni exécuté sur Windows.** La
   recette PyInstaller a été validée sous Linux (paquet construit, démarré,
   12 contrôles de `verify_release.py` réussis, y compris sans aucun accès
   réseau). Les scripts PowerShell ont seulement été vérifiés syntaxiquement.
   Prochaine étape : `build-windows.ps1` puis `RELEASE_CHECKLIST.md` sur un
   Windows 10/11 propre.
2. Pas d'installateur (archive ZIP portable), pas d'icône, exécutable non signé
   (SmartScreen peut afficher un avertissement).
3. Restauration de sauvegarde : procédure manuelle documentée, pas encore
   d'écran dédié (Lot 1).
4. Pas de limitation du nombre d'essais de connexion (échecs journalisés).
5. La recherche est insensible à la casse pour les lettres non accentuées
   seulement (« é » ≠ « É »), limite de SQLite.
6. Tous les utilisateurs voient tous les projets (droits par projet au Lot 1).
7. Interface en thème clair uniquement.
8. Aucun module de calcul (métrés, cubatures, hydraulique) : ils arrivent à
   partir du Lot 2, avec cas de référence validés par un ingénieur.

## Licences

Code de l'application : propriétaire. Dépendances et polices :
[`LICENSE-THIRD-PARTY.md`](LICENSE-THIRD-PARTY.md).
