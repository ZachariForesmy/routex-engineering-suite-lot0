#Requires -Version 5.1
<#
.SYNOPSIS
    Construit le paquet Windows portable de RouteX (dossier + archive ZIP).

.DESCRIPTION
    A executer SUR WINDOWS, depuis n'importe quel dossier :
        powershell -ExecutionPolicy Bypass -File scripts\build-windows.ps1

    Etapes : controle des outils, environnement Python isole, dependances
    epinglees, compilation de l'interface, tests, PyInstaller, verification du
    paquet produit (scripts\verify_release.py), archive ZIP + empreinte SHA-256.

    Prerequis : Python 3.12 ou 3.13 (64 bits) et Node.js 22+ installes.
    Connexion Internet necessaire pour telecharger les dependances (une seule
    fois) ; le paquet produit fonctionne ensuite hors ligne.

.PARAMETER Python
    Commande Python a utiliser (defaut : py -3 si disponible, sinon python).

.PARAMETER SkipTests
    Ne pas executer les tests automatises (deconseille).
#>
[CmdletBinding()]
param(
    [string]$Python = "",
    [switch]$SkipTests
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$Root = Split-Path -Parent $PSScriptRoot
$Backend = Join-Path $Root "backend"
$Frontend = Join-Path $Root "frontend"
$Venv = Join-Path $Backend ".venv-build"
$Py = Join-Path $Venv "Scripts\python.exe"

function Invoke-Step {
    param([string]$Label, [scriptblock]$Block)
    Write-Host ""
    Write-Host "==> $Label" -ForegroundColor Cyan
    $global:LASTEXITCODE = 0
    & $Block
    if ($global:LASTEXITCODE -ne 0) {
        throw "Echec de l'etape '$Label' (code $global:LASTEXITCODE)."
    }
}

function Resolve-Python {
    if ($Python) { return ,@($Python -split " ") }
    if (Get-Command py -ErrorAction SilentlyContinue) { return ,@("py", "-3") }
    if (Get-Command python -ErrorAction SilentlyContinue) { return ,@("python") }
    throw "Python introuvable. Installez Python 3.12+ (64 bits) depuis python.org."
}

$PyCmd = Resolve-Python
$PyExe = $PyCmd[0]
$PyArgs = @()
if ($PyCmd.Count -gt 1) { $PyArgs = $PyCmd[1..($PyCmd.Count - 1)] }

Invoke-Step "Controle des outils" {
    & $PyExe @PyArgs -c "import sys, struct; v=sys.version_info; print('Python', sys.version.split()[0], struct.calcsize('P')*8, 'bits'); sys.exit(0 if v >= (3,12) and struct.calcsize('P')==8 else 1)"
    if ($global:LASTEXITCODE -ne 0) { throw "Python 3.12+ 64 bits requis." }
    if (-not (Get-Command npm.cmd -ErrorAction SilentlyContinue)) { throw "Node.js / npm introuvable. Installez Node.js 22+." }
    & node --version
}

Invoke-Step "Environnement Python isole ($Venv)" {
    if (-not (Test-Path $Py)) { & $PyExe @PyArgs -m venv $Venv }
    & $Py -m pip install --quiet --upgrade pip
}

Invoke-Step "Dependances Python (versions epinglees)" {
    & $Py -m pip install --quiet -c (Join-Path $Backend "requirements-lock.txt") -e "$Backend[dev,build]"
}

Invoke-Step "Dependances et compilation de l'interface" {
    Push-Location $Frontend
    try {
        & npm.cmd ci --no-audit --no-fund
        if ($global:LASTEXITCODE -eq 0) { & npm.cmd run build }
    } finally { Pop-Location }
}

if (-not $SkipTests) {
    Invoke-Step "Tests backend (pytest)" {
        Push-Location $Backend
        try { & $Py -m pytest -q -p no:cacheprovider } finally { Pop-Location }
    }
    Invoke-Step "Tests interface (vitest)" {
        Push-Location $Frontend
        try { & npm.cmd test } finally { Pop-Location }
    }
}

Invoke-Step "Paquet PyInstaller" {
    Push-Location $Root
    try {
        & $Py -m PyInstaller (Join-Path $Root "packaging\routex.spec") --noconfirm --clean `
            --distpath (Join-Path $Root "dist") --workpath (Join-Path $Root "build\pyinstaller")
    } finally { Pop-Location }
}

$Exe = Join-Path $Root "dist\RouteX\RouteX.exe"
Invoke-Step "Verification du paquet produit" {
    & $Py -I (Join-Path $Root "scripts\verify_release.py") $Exe
}

$Version = (& $Py -c "import app; print(app.__version__)").Trim()
$Zip = Join-Path $Root "dist\RouteX-$Version-windows-x64.zip"
Invoke-Step "Archive ZIP" {
    if (Test-Path $Zip) { Remove-Item $Zip -Force }
    Compress-Archive -Path (Join-Path $Root "dist\RouteX") -DestinationPath $Zip
}

$Hash = (Get-FileHash -Algorithm SHA256 $Zip).Hash.ToLowerInvariant()
Set-Content -Path "$Zip.sha256" -Value "$Hash  $(Split-Path -Leaf $Zip)" -Encoding ascii

Write-Host ""
Write-Host "Paquet pret : $Zip" -ForegroundColor Green
Write-Host "SHA-256     : $Hash"
Write-Host "Etape suivante : tester sur un Windows propre selon docs\RELEASE_CHECKLIST.md (dont TX-013 hors ligne)."
