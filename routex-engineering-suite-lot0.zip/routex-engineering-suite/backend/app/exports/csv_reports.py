"""Export CSV : UTF-8 avec BOM, séparateur « ; », dates ISO 8601 (D-012)."""

from __future__ import annotations

import csv
import io

from app.exports.common import PROJECT_LIST_COLUMNS, RenderedReport, ReportMeta, timestamp_for_file
from app.schemas.project import ProjectOut


def render_projects_list(projects: list[ProjectOut], meta: ReportMeta) -> RenderedReport:
    buffer = io.StringIO()
    writer = csv.writer(buffer, delimiter=";", lineterminator="\r\n", quoting=csv.QUOTE_MINIMAL)
    writer.writerow([label for _key, label in PROJECT_LIST_COLUMNS])
    for prj in projects:
        writer.writerow([
            prj.code, prj.name, prj.client, prj.location, prj.country, prj.currency,
            prj.start_date.isoformat() if prj.start_date else "",
            prj.end_date.isoformat() if prj.end_date else "",
            prj.status,
        ])
    content = buffer.getvalue().encode("utf-8-sig")
    name = f"RouteX_projets_{timestamp_for_file(meta.generated_at)}.csv"
    return RenderedReport(content, "text/csv; charset=utf-8", name)
