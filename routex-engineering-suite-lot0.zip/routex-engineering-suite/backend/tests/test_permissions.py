"""TX-012 : les droits sont contrôlés côté backend, rôle par rôle."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from app.core.permissions import ROLE_PERMISSIONS, Permission, Role, has_permission
from tests.conftest import project_payload

# (rôle, peut écrire un projet, peut administrer)
MATRIX = [
    ("admin", True, True),
    ("ingenieur", True, False),
    ("technicien", False, False),
    ("lecture", False, False),
]


def test_matrix_is_complete() -> None:
    assert set(ROLE_PERMISSIONS) == set(Role)
    assert ROLE_PERMISSIONS[Role.ADMIN] == frozenset(Permission)
    assert not has_permission("role-inexistant", Permission.PROJECT_READ)


@pytest.mark.parametrize(("role", "can_write", "is_admin"), MATRIX)
def test_role_enforcement_on_api(
    role: str, can_write: bool, is_admin: bool,
    client: TestClient, admin_headers: dict[str, str], make_user, create_project,  # type: ignore[no-untyped-def]
) -> None:
    headers = admin_headers if role == "admin" else make_user(role)
    existing = create_project(code="EXISTANT")

    # Lecture et export : tous les rôles
    assert client.get("/api/v1/projects", headers=headers).status_code == 200
    assert client.get(f"/api/v1/projects/{existing['id']}", headers=headers).status_code == 200
    assert client.get("/api/v1/reports/projects.csv", headers=headers).status_code == 200

    # Écriture
    created = client.post("/api/v1/projects", headers=headers, json=project_payload(code=f"NEW-{role}"))
    assert created.status_code == (201 if can_write else 403)
    patched = client.patch(f"/api/v1/projects/{existing['id']}", headers=headers,
                           json={"revision": existing["revision"], "name": f"Modifié par {role}"})
    assert patched.status_code == (200 if can_write else 403)
    if not can_write:
        assert "ne permet pas" in patched.json()["detail"]

    # Administration
    expected_admin = 200 if is_admin else 403
    assert client.get("/api/v1/users", headers=headers).status_code == expected_admin
    assert client.get("/api/v1/admin/audit-log", headers=headers).status_code == expected_admin
    assert client.get("/api/v1/admin/backups", headers=headers).status_code == expected_admin
    assert client.post("/api/v1/admin/backup", headers=headers).status_code == (201 if is_admin else 403)


def test_forbidden_write_leaves_no_trace(client: TestClient, make_user) -> None:  # type: ignore[no-untyped-def]
    reader = make_user("lecture")
    r = client.post("/api/v1/projects", headers=reader, json=project_payload(code="INTERDIT"))
    assert r.status_code == 403
    assert client.get("/api/v1/projects", headers=reader).json()["total"] == 0
