# Installation sous Windows — RouteX (version de développement)

> Procédure rédigée pour le paquet portable produit par
> `scripts\build-windows.ps1`. **Elle n'a pas encore été déroulée sur un
> Windows réel** (voir README, Limites connues).

## Configuration requise

- Windows 10 ou 11, 64 bits.
- Un navigateur récent (Edge, Chrome ou Firefox).
- Environ 150 Mo d'espace disque pour l'application, plus les données.
- Aucune connexion Internet nécessaire.

## Installation

1. Copier `RouteX-<version>-windows-x64.zip` sur le poste.
2. Vérifier l'empreinte (facultatif) :
   `Get-FileHash RouteX-<version>-windows-x64.zip` doit afficher la valeur du
   fichier `.sha256` livré avec l'archive.
3. Clic droit → **Extraire tout…** vers un dossier stable, par exemple
   `C:\Programmes\RouteX` ou `%LOCALAPPDATA%\Programs\RouteX`.
   Ne pas lancer l'application depuis l'archive ZIP.
4. Lancer `RouteX\RouteX.exe`. L'exécutable n'est pas encore signé : Windows
   SmartScreen peut afficher « Windows a protégé votre ordinateur » ; cliquer
   **Informations complémentaires → Exécuter quand même** si l'archive provient
   d'une source sûre.

## Premier lancement

Une fenêtre console s'ouvre et affiche l'adresse (par défaut
`http://127.0.0.1:8765/`) et le dossier des données ; le navigateur s'ouvre
sur l'écran **Premier démarrage**.

1. Créer le compte administrateur (identifiant, nom complet, mot de passe de
   10 caractères minimum).
2. Dans **Utilisateurs**, créer les comptes des autres personnes du poste avec
   le rôle adapté.

**Laisser la fenêtre console ouverte pendant l'utilisation.** La fermer (ou
Ctrl+C) arrête RouteX. Relancer `RouteX.exe` alors qu'il tourne déjà rouvre
simplement l'interface.

## Emplacement des données

`%LOCALAPPDATA%\RouteX\` (affiché par `RouteX.exe info`) :

| Dossier | Contenu |
|---|---|
| `data\routex.sqlite3` | base de données (avec `-wal` et `-shm` pendant l'utilisation) |
| `backups\` | sauvegardes |
| `logs\routex.log` | journal technique |

Ne pas placer ce dossier dans OneDrive, Dropbox ou sur un lecteur réseau.
Pour utiliser un autre emplacement : variable d'environnement
`ROUTEX_DATA_DIR`.

## Mot de passe perdu

- Un administrateur peut définir un nouveau mot de passe pour un autre compte
  depuis **Utilisateurs**.
- Si le seul administrateur a perdu le sien : ouvrir une invite de commandes
  dans le dossier de RouteX et exécuter
  `RouteX.exe reset-password <identifiant>`. Cette opération exige l'accès
  physique au poste ; elle est inscrite au journal d'audit.

## Commandes utiles

| Commande | Effet |
|---|---|
| `RouteX.exe` | Démarre et ouvre le navigateur |
| `RouteX.exe --no-browser` | Démarre sans ouvrir le navigateur |
| `RouteX.exe --port 9000` | Utilise un autre port |
| `RouteX.exe info` | Affiche les emplacements des données |
| `RouteX.exe backup` | Sauvegarde la base sans ouvrir l'interface |
| `RouteX.exe reset-password <id>` | Réinitialise un mot de passe |

## Mise à jour

1. Faire une sauvegarde (interface **Administration** ou `RouteX.exe backup`).
2. Fermer RouteX.
3. Extraire la nouvelle version à la place de l'ancienne.
4. Lancer. Si le schéma de la base change, une sauvegarde
   `avant-migration` est créée automatiquement avant la mise à jour.

## Désinstallation

Supprimer le dossier de l'application. Les données restent dans
`%LOCALAPPDATA%\RouteX\` ; les supprimer seulement après avoir conservé une
sauvegarde.
