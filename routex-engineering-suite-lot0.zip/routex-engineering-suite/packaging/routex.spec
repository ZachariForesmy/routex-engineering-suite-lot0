# -*- mode: python ; coding: utf-8 -*-
# Recette PyInstaller de RouteX (D-002) — mode dossier (onedir), console visible.
#
# À lancer depuis la racine du dépôt, APRÈS `npm run build` dans frontend/ :
#     pyinstaller packaging/routex.spec --noconfirm --clean
# Résultat : dist/RouteX/RouteX(.exe) + ses bibliothèques.
#
# PyInstaller ne compile pas en croisé : un paquet Windows se construit sur
# Windows (scripts/build-windows.ps1).

from pathlib import Path

from PyInstaller.utils.hooks import collect_data_files, collect_submodules

ROOT = Path(SPECPATH).resolve().parent
BACKEND = ROOT / "backend"
DIST_FRONTEND = ROOT / "frontend" / "dist"

if not (DIST_FRONTEND / "index.html").exists():
    raise SystemExit("Interface non compilée : lancez `npm run build` dans frontend/ avant PyInstaller.")

datas = [
    (str(BACKEND / "migrations"), "migrations"),
    (str(BACKEND / "app" / "resources" / "fonts"), "app/resources/fonts"),
    (str(DIST_FRONTEND), "frontend_dist"),
]
datas += collect_data_files("reportlab")

hiddenimports = (
    collect_submodules("app")
    + collect_submodules("uvicorn")
    + collect_submodules("alembic", filter=lambda name: not name.startswith("alembic.testing"))
    + ["sqlalchemy.dialects.sqlite", "argon2", "_cffi_backend"]
)

a = Analysis(
    [str(ROOT / "packaging" / "routex_entry.py")],
    pathex=[str(BACKEND)],
    datas=datas,
    hiddenimports=hiddenimports,
    excludes=["tkinter", "pytest", "playwright", "IPython", "matplotlib", "numpy"],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="RouteX",
    console=True,  # la fenêtre console affiche l'adresse et permet d'arrêter l'application
    upx=False,     # UPX augmente les faux positifs antivirus
)

coll = COLLECT(exe, a.binaries, a.datas, name="RouteX", upx=False)
