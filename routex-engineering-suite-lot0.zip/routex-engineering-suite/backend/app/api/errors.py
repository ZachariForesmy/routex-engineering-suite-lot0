"""Gestion homogène des erreurs : réponse JSON ``{detail, code, errors}`` avec
des messages en français, sans fuite de détails techniques."""

from __future__ import annotations

from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.core.errors import AppError
from app.core.logging import get_logger

log = get_logger("api")

FIELD_LABELS = {
    "code": "Code", "name": "Intitulé", "client": "Maître d'ouvrage", "location": "Localisation",
    "country": "Pays", "currency": "Devise", "unit_system": "Système d'unités",
    "description": "Description", "start_date": "Date de début", "end_date": "Date de fin",
    "revision": "Révision", "username": "Identifiant", "full_name": "Nom complet", "role": "Rôle",
    "password": "Mot de passe", "new_password": "Nouveau mot de passe",
    "current_password": "Mot de passe actuel", "is_active": "Actif",
}


def _message(err: dict[str, Any]) -> str:
    kind = err.get("type", "")
    ctx = err.get("ctx") or {}
    if kind == "missing":
        return "obligatoire"
    if kind == "string_too_short":
        n = ctx.get("min_length", 1)
        return "ne doit pas être vide" if n == 1 else f"trop court (minimum {n} caractères)"
    if kind == "string_too_long":
        return f"trop long (maximum {ctx.get('max_length')} caractères)"
    if kind == "string_pattern_mismatch":
        return "format invalide"
    if kind in {"date_parsing", "date_from_datetime_parsing", "date_type"}:
        return "date invalide (format attendu AAAA-MM-JJ)"
    if kind in {"int_parsing", "int_type"}:
        return "doit être un nombre entier"
    if kind in {"literal_error", "enum"}:
        return "valeur non autorisée"
    if kind == "extra_forbidden":
        return "champ non reconnu"
    if kind == "value_error":
        return str(ctx.get("error", err.get("msg", "valeur invalide")))
    return str(err.get("msg", "valeur invalide"))


def _field(loc: tuple[Any, ...]) -> str:
    parts = [str(p) for p in loc if p not in ("body", "query", "path")]
    return ".".join(parts)


def install_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(AppError)
    async def _app_error(_request: Request, exc: AppError) -> JSONResponse:
        return JSONResponse(status_code=exc.status_code, content={"detail": exc.message, "code": exc.code, "errors": []})

    @app.exception_handler(RequestValidationError)
    async def _validation(_request: Request, exc: RequestValidationError) -> JSONResponse:
        errors = []
        for err in exc.errors():
            field = _field(tuple(err.get("loc", ())))
            errors.append({"field": field, "message": _message(err)})
        summary = " ; ".join(
            f"{FIELD_LABELS.get(e['field'], e['field']) or 'Requête'} : {e['message']}" for e in errors
        )
        return JSONResponse(
            status_code=422,
            content={"detail": f"Données invalides — {summary}", "code": "donnees_invalides", "errors": errors},
        )

    @app.exception_handler(StarletteHTTPException)
    async def _http(_request: Request, exc: StarletteHTTPException) -> JSONResponse:
        messages = {404: "Ressource introuvable.", 405: "Méthode non autorisée."}
        return JSONResponse(
            status_code=exc.status_code,
            content={"detail": messages.get(exc.status_code, str(exc.detail)), "code": f"http_{exc.status_code}", "errors": []},
            headers=getattr(exc, "headers", None),
        )

    @app.exception_handler(Exception)
    async def _unexpected(request: Request, exc: Exception) -> JSONResponse:
        log.exception("Erreur inattendue sur %s %s", request.method, request.url.path)
        return JSONResponse(
            status_code=500,
            content={
                "detail": "Erreur interne inattendue. L'opération n'a pas été enregistrée. "
                          "Le détail technique figure dans le journal (logs/routex.log).",
                "code": "erreur_interne", "errors": [],
            },
        )
