"""Rapports PDF (ReportLab, police DejaVu Sans embarquée)."""

from __future__ import annotations

import io
from functools import partial
from typing import Any
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from app.core.resources import fonts_dir
from app.core.timeutil import format_date, format_local_datetime
from app.exports.common import (
    PROJECT_LIST_COLUMNS,
    STATUS_LABELS,
    RenderedReport,
    ReportMeta,
    project_fields,
    safe_file_part,
    timestamp_for_file,
)
from app.schemas.project import ProjectOut

FONT = "DejaVuSans"
FONT_BOLD = "DejaVuSans-Bold"
INK = colors.HexColor("#1B2733")
MUTED = colors.HexColor("#5B6B7A")
ACCENT = colors.HexColor("#1F4E79")
RULE = colors.HexColor("#C9D3DC")
ZEBRA = colors.HexColor("#F3F6F9")
MARGIN = 15 * mm

_fonts_registered = False


def _register_fonts() -> None:
    global _fonts_registered
    if _fonts_registered:
        return
    pdfmetrics.registerFont(TTFont(FONT, str(fonts_dir() / "DejaVuSans.ttf")))
    pdfmetrics.registerFont(TTFont(FONT_BOLD, str(fonts_dir() / "DejaVuSans-Bold.ttf")))
    pdfmetrics.registerFontFamily(FONT, normal=FONT, bold=FONT_BOLD, italic=FONT, boldItalic=FONT_BOLD)
    _fonts_registered = True


def _styles() -> dict[str, ParagraphStyle]:
    base = ParagraphStyle("base", fontName=FONT, fontSize=9, leading=11.5, textColor=INK, alignment=TA_LEFT)
    return {
        "base": base,
        "cell": ParagraphStyle("cell", parent=base, fontSize=8, leading=10),
        "head": ParagraphStyle("head", parent=base, fontName=FONT_BOLD, fontSize=8, leading=10, textColor=colors.white),
        "title": ParagraphStyle("title", parent=base, fontName=FONT_BOLD, fontSize=16, leading=20, spaceAfter=2 * mm),
        "subtitle": ParagraphStyle("subtitle", parent=base, fontSize=10, leading=13, textColor=MUTED),
        "label": ParagraphStyle("label", parent=base, fontName=FONT_BOLD, textColor=MUTED),
        "section": ParagraphStyle("section", parent=base, fontName=FONT_BOLD, fontSize=11, leading=14, spaceBefore=5 * mm, spaceAfter=2 * mm, textColor=ACCENT),
    }


class _NumberedCanvas(rl_canvas.Canvas):
    """Canevas en deux passes pour afficher « Page X / Y »."""

    def __init__(self, *args: Any, meta: ReportMeta, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._meta = meta
        self._pages: list[dict[str, Any]] = []

    def showPage(self) -> None:  # noqa: N802 (API ReportLab)
        self._pages.append(dict(self.__dict__))
        self._startPage()

    def save(self) -> None:
        total = len(self._pages)
        for state in self._pages:
            self.__dict__.update(state)
            self._decorate(total)
            super().showPage()
        super().save()

    def _decorate(self, total: int) -> None:
        width, height = self._pagesize
        top = height - MARGIN + 4 * mm
        self.setStrokeColor(RULE)
        self.setLineWidth(0.6)
        self.setFont(FONT_BOLD, 8)
        self.setFillColor(ACCENT)
        self.drawString(MARGIN, top, self._meta.app_name)
        self.setFont(FONT, 8)
        self.setFillColor(MUTED)
        self.drawRightString(width - MARGIN, top, self._meta.title)
        self.line(MARGIN, top - 2 * mm, width - MARGIN, top - 2 * mm)

        bottom = MARGIN - 7 * mm
        self.line(MARGIN, bottom + 4 * mm, width - MARGIN, bottom + 4 * mm)
        self.drawString(
            MARGIN, bottom,
            f"Généré le {format_local_datetime(self._meta.generated_at)} par {self._meta.author} — "
            f"RouteX {self._meta.app_version}",
        )
        self.drawRightString(width - MARGIN, bottom, f"Page {self._page_number_label()} / {total}")

    def _page_number_label(self) -> str:
        return str(self.getPageNumber())


def _build(story: list[Any], meta: ReportMeta, pagesize: tuple[float, float]) -> bytes:
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=pagesize,
        leftMargin=MARGIN, rightMargin=MARGIN, topMargin=MARGIN + 4 * mm, bottomMargin=MARGIN,
        title=meta.title, author=meta.author, subject=meta.title,
        creator=f"{meta.app_name} {meta.app_version}", lang="fr-FR",
        initialFontName=FONT, initialFontSize=9,
    )
    doc.build(story, canvasmaker=partial(_NumberedCanvas, meta=meta))
    return buffer.getvalue()


def _p(text: str, style: ParagraphStyle) -> Paragraph:
    return Paragraph(escape(text).replace("\n", "<br/>"), style)


def _filters_line(meta: ReportMeta, style: ParagraphStyle) -> Paragraph:
    parts = [f"<b>{escape(k)} :</b> {escape(v)}" for k, v in meta.filters.items()]
    return Paragraph(" · ".join(parts), style)


def render_projects_list(projects: list[ProjectOut], meta: ReportMeta) -> RenderedReport:
    _register_fonts()
    st = _styles()
    pagesize = landscape(A4)
    usable = pagesize[0] - 2 * MARGIN
    # Largeurs relatives des colonnes (somme = 1)
    ratios = (0.10, 0.21, 0.16, 0.14, 0.08, 0.06, 0.085, 0.085, 0.08)
    widths = [usable * r for r in ratios]

    story: list[Any] = [
        _p(meta.title, st["title"]),
        _filters_line(meta, st["subtitle"]),
        _p(f"{len(projects)} projet(s)", st["subtitle"]),
        Spacer(1, 4 * mm),
    ]
    if not projects:
        story.append(_p("Aucun projet ne correspond aux critères.", st["base"]))
    else:
        header = [_p(label, st["head"]) for _key, label in PROJECT_LIST_COLUMNS]
        rows = [header]
        for prj in projects:
            values = {
                "code": prj.code, "name": prj.name, "client": prj.client, "location": prj.location,
                "country": prj.country, "currency": prj.currency,
                "start_date": format_date(prj.start_date), "end_date": format_date(prj.end_date),
                "status": STATUS_LABELS.get(prj.status, prj.status),
            }
            rows.append([_p(values[key], st["cell"]) for key, _label in PROJECT_LIST_COLUMNS])
        table = Table(rows, colWidths=widths, repeatRows=1)
        style = [
            ("FONTNAME", (0, 0), (-1, -1), FONT),  # sinon ReportLab référence Helvetica
            ("BACKGROUND", (0, 0), (-1, 0), ACCENT),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LINEBELOW", (0, 0), (-1, -1), 0.4, RULE),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]
        style += [("BACKGROUND", (0, i), (-1, i), ZEBRA) for i in range(2, len(rows), 2)]
        table.setStyle(TableStyle(style))
        story.append(table)

    name = f"RouteX_projets_{timestamp_for_file(meta.generated_at)}.pdf"
    return RenderedReport(_build(story, meta, pagesize), "application/pdf", name)


def render_project_sheet(project: ProjectOut, meta: ReportMeta) -> RenderedReport:
    _register_fonts()
    st = _styles()
    pagesize = A4
    usable = pagesize[0] - 2 * MARGIN

    story: list[Any] = [
        _p(meta.title, st["subtitle"]),
        _p(f"{project.code} — {project.name}", st["title"]),
        Spacer(1, 2 * mm),
    ]
    rows = [[_p(label, st["label"]), _p(value, st["base"])] for label, value in project_fields(project)]
    table = Table(rows, colWidths=[usable * 0.3, usable * 0.7])
    table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), FONT),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LINEBELOW", (0, 0), (-1, -1), 0.4, RULE),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    story += [table, _p("Description", st["section"]), _p(project.description or "—", st["base"])]

    name = f"RouteX_fiche_{safe_file_part(project.code)}_r{project.revision}.pdf"
    return RenderedReport(_build(story, meta, pagesize), "application/pdf", name)
