"""Configuration de l'application.

Toutes les valeurs ont un défaut documenté (docs/DECISIONS.md) et peuvent être
remplacées par une variable d'environnement ``ROUTEX_*``. Aucun secret n'est
nécessaire.
"""

from __future__ import annotations

import os
import re
import sys
from dataclasses import dataclass, field, replace
from pathlib import Path

from app.core.resources import default_frontend_dist

_CURRENCY_RE = re.compile(r"^[A-Z]{3}$")


class ConfigError(ValueError):
    """Valeur de configuration invalide."""


def default_data_dir() -> Path:
    """Répertoire de données utilisateur (D-003)."""
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(base) / "RouteX"
    xdg = os.environ.get("XDG_DATA_HOME")
    return (Path(xdg) if xdg else Path.home() / ".local" / "share") / "RouteX"


def _env_int(name: str, default: int, minimum: int, maximum: int) -> int:
    raw = os.environ.get(name)
    if raw is None or raw.strip() == "":
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        raise ConfigError(f"{name} doit être un nombre entier (reçu : {raw!r}).") from exc
    if not minimum <= value <= maximum:
        raise ConfigError(f"{name} doit être compris entre {minimum} et {maximum} (reçu : {value}).")
    return value


def _env_bool(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in {"1", "true", "oui", "yes"}


@dataclass(frozen=True)
class Settings:
    data_dir: Path
    host: str = "127.0.0.1"
    port: int = 8765
    session_hours: int = 12
    default_currency: str = "HTG"
    default_country: str = "Haïti"
    dev_mode: bool = False
    frontend_dist: Path | None = None
    allowed_hosts: tuple[str, ...] = field(default=("127.0.0.1", "localhost"))

    def __post_init__(self) -> None:
        if not _CURRENCY_RE.match(self.default_currency):
            raise ConfigError("La devise par défaut doit être un code ISO 4217 de 3 lettres majuscules.")
        if self.host not in {"127.0.0.1", "localhost", "::1"}:
            # D-009 : le serveur ne doit jamais être exposé sur le réseau.
            raise ConfigError("RouteX n'écoute que sur l'interface locale (127.0.0.1).")

    # --- Chemins dérivés -------------------------------------------------
    @property
    def db_path(self) -> Path:
        return self.data_dir / "data" / "routex.sqlite3"

    @property
    def backups_dir(self) -> Path:
        return self.data_dir / "backups"

    @property
    def logs_dir(self) -> Path:
        return self.data_dir / "logs"

    @property
    def documents_dir(self) -> Path:
        return self.data_dir / "documents"

    def ensure_dirs(self) -> None:
        for path in (self.db_path.parent, self.backups_dir, self.logs_dir, self.documents_dir):
            path.mkdir(parents=True, exist_ok=True)

    def with_overrides(self, **changes: object) -> "Settings":
        return replace(self, **changes)

    @classmethod
    def from_env(cls) -> "Settings":
        data_dir_raw = os.environ.get("ROUTEX_DATA_DIR")
        data_dir = Path(data_dir_raw).expanduser().resolve() if data_dir_raw else default_data_dir()
        dist_raw = os.environ.get("ROUTEX_FRONTEND_DIST")
        return cls(
            data_dir=data_dir,
            port=_env_int("ROUTEX_PORT", 8765, 1024, 65535),
            session_hours=_env_int("ROUTEX_SESSION_HOURS", 12, 1, 24 * 14),
            default_currency=os.environ.get("ROUTEX_DEFAULT_CURRENCY", "HTG").strip().upper(),
            dev_mode=_env_bool("ROUTEX_DEV"),
            frontend_dist=Path(dist_raw).resolve() if dist_raw else default_frontend_dist(),
        )
