import { afterEach, describe, expect, it, vi } from "vitest";
import { ApiError, buildUrl, filenameFromDisposition, request, setToken, setUnauthorizedHandler } from "../src/api";

function jsonResponse(status: number, body: unknown): Response {
  return new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });
}

afterEach(() => {
  vi.unstubAllGlobals();
  setToken(null);
  setUnauthorizedHandler(null);
});

describe("buildUrl", () => {
  it("ignore les paramètres vides et encode les autres", () => {
    expect(buildUrl("/projects", { q: "", include_archived: false })).toBe("/api/v1/projects?include_archived=false");
    expect(buildUrl("/projects", { q: "route à 100 %" })).toBe("/api/v1/projects?q=route+%C3%A0+100+%25");
  });
});

describe("filenameFromDisposition", () => {
  it("préfère le nom encodé UTF-8 (RFC 5987)", () => {
    const header = "attachment; filename=\"RouteX_fiche_P_r1.pdf\"; filename*=UTF-8''RouteX_fiche_Pr%C3%A9_r1.pdf";
    expect(filenameFromDisposition(header, "x")).toBe("RouteX_fiche_Pré_r1.pdf");
  });
  it("se replie sur filename= puis sur la valeur par défaut", () => {
    expect(filenameFromDisposition('attachment; filename="a.xlsx"', "x")).toBe("a.xlsx");
    expect(filenameFromDisposition(null, "export")).toBe("export");
  });
});

describe("request", () => {
  it("joint le jeton et décode la réponse", async () => {
    const fetchMock = vi.fn().mockResolvedValue(jsonResponse(200, { total: 0, items: [] }));
    vi.stubGlobal("fetch", fetchMock);
    setToken("jeton-test");
    await expect(request("GET", "/projects")).resolves.toEqual({ total: 0, items: [] });
    const [, init] = fetchMock.mock.calls[0] as [string, RequestInit];
    expect((init.headers as Record<string, string>).Authorization).toBe("Bearer jeton-test");
  });

  it("transforme les erreurs de l'API en ApiError avec le message français", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(
        jsonResponse(422, { detail: "Données invalides — Code : obligatoire", code: "donnees_invalides", errors: [{ field: "code", message: "obligatoire" }] }),
      ),
    );
    const error = await request("POST", "/projects", {}).catch((e: unknown) => e);
    expect(error).toBeInstanceOf(ApiError);
    expect((error as ApiError).message).toBe("Données invalides — Code : obligatoire");
    expect((error as ApiError).fieldErrors).toEqual([{ field: "code", message: "obligatoire" }]);
  });

  it("sur 401, efface le jeton et prévient l'application", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(jsonResponse(401, { detail: "Session expirée", code: "session_invalide" })));
    const handler = vi.fn();
    setUnauthorizedHandler(handler);
    setToken("jeton-expire");
    await expect(request("GET", "/auth/me")).rejects.toBeInstanceOf(ApiError);
    expect(handler).toHaveBeenCalledOnce();
  });

  it("signale clairement un serveur injoignable", async () => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new TypeError("Failed to fetch")));
    const error = (await request("GET", "/projects").catch((e: unknown) => e)) as ApiError;
    expect(error.code).toBe("hors_ligne");
    expect(error.message).toContain("fenêtre de l'application");
  });
});
