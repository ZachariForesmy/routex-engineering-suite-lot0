from __future__ import annotations

import json

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.core.config import Settings
from app.main import create_app
from app.models import AuditEntry
from tests.conftest import ADMIN, bearer, project_payload


def test_tx001_project_survives_close_and_reopen(settings: Settings) -> None:
    """TX-001 : création, fermeture complète de l'application, réouverture."""
    app1 = create_app(settings)
    with TestClient(app1, base_url="http://127.0.0.1") as c1:
        headers = bearer(c1.post("/api/v1/auth/setup", json=ADMIN).json()["token"])
        created = c1.post("/api/v1/projects", headers=headers, json=project_payload()).json()
    app1.state.engine.dispose()

    app2 = create_app(settings)
    with TestClient(app2, base_url="http://127.0.0.1") as c2:
        token = c2.post("/api/v1/auth/login", json={"username": ADMIN["username"], "password": ADMIN["password"]}).json()["token"]
        reopened = c2.get(f"/api/v1/projects/{created['id']}", headers=bearer(token)).json()
    app2.state.engine.dispose()

    for key in ("code", "name", "client", "location", "country", "currency", "description", "start_date", "end_date", "revision"):
        assert reopened[key] == created[key], key
    assert reopened["name"] == "Réhabilitation de la route Delmas 33"  # accents conservés


def test_create_normalises_and_sets_traceability(client: TestClient, admin_headers: dict[str, str]) -> None:
    r = client.post("/api/v1/projects", headers=admin_headers,
                    json=project_payload(code="  RTX-01 ", name="  Route  ", currency="usd"))
    assert r.status_code == 201
    body = r.json()
    assert (body["code"], body["name"], body["currency"]) == ("RTX-01", "Route", "USD")
    assert body["status"] == "actif" and body["revision"] == 1 and body["unit_system"] == "SI"
    assert body["created_by_name"] == ADMIN["full_name"]
    assert body["created_at"].endswith("Z")  # horodatage UTC explicite (D-006)


def test_validation_errors_are_in_french(client: TestClient, admin_headers: dict[str, str]) -> None:
    r = client.post("/api/v1/projects", headers=admin_headers,
                    json=project_payload(code="", currency="EURO", start_date="2027-01-01", end_date="2026-01-01"))
    assert r.status_code == 422
    detail = r.json()["detail"]
    assert "Code : ne doit pas être vide" in detail
    assert "Devise : format invalide" in detail


def test_incoherent_dates_rejected(client: TestClient, admin_headers: dict[str, str]) -> None:
    r = client.post("/api/v1/projects", headers=admin_headers,
                    json=project_payload(start_date="2027-01-01", end_date="2026-01-01"))
    assert r.status_code == 422
    assert "date de fin" in r.json()["detail"]


def test_unknown_field_is_rejected(client: TestClient, admin_headers: dict[str, str]) -> None:
    r = client.post("/api/v1/projects", headers=admin_headers, json=project_payload(budjet=1000))
    assert r.status_code == 422
    assert "champ non reconnu" in r.json()["detail"]


def test_code_is_unique_case_insensitive(client: TestClient, admin_headers: dict[str, str], create_project) -> None:  # type: ignore[no-untyped-def]
    create_project(code="RTX-A")
    r = client.post("/api/v1/projects", headers=admin_headers, json=project_payload(code="rtx-a"))
    assert r.status_code == 409 and r.json()["code"] == "code_existant"


def test_search_and_archive_filter(client: TestClient, admin_headers: dict[str, str], create_project) -> None:  # type: ignore[no-untyped-def]
    a = create_project(code="AEP-01", name="Adduction d'eau Jacmel", client="DINEPA", location="Jacmel")
    create_project(code="VRD-02", name="Voirie lotissement", client="Mairie de Delmas", location="Delmas")
    create_project(code="RTE-100", name="Route revêtue à 100 %", location="Hinche")

    def codes(**params: object) -> list[str]:
        r = client.get("/api/v1/projects", headers=admin_headers, params=params)
        assert r.status_code == 200
        return [p["code"] for p in r.json()["items"]]

    assert codes() == ["AEP-01", "RTE-100", "VRD-02"]
    assert codes(q="dinepa") == ["AEP-01"]          # maître d'ouvrage, insensible à la casse
    assert codes(q="delmas") == ["VRD-02"]          # localisation
    assert codes(q="%") == ["RTE-100"]              # le joker SQL est échappé
    assert codes(q="_") == []
    assert codes(q="introuvable") == []

    r = client.post(f"/api/v1/projects/{a['id']}/archive", headers=admin_headers, json={"revision": a["revision"]})
    assert r.status_code == 200 and r.json()["status"] == "archive"
    assert codes() == ["RTE-100", "VRD-02"]
    assert codes(include_archived=True) == ["RTE-100", "VRD-02", "AEP-01"]  # archivés en dernier


def test_update_with_revision_control(client: TestClient, admin_headers: dict[str, str], create_project) -> None:  # type: ignore[no-untyped-def]
    p = create_project()
    url = f"/api/v1/projects/{p['id']}"
    r = client.patch(url, headers=admin_headers, json={"revision": 1, "name": "Nouvel intitulé", "start_date": None})
    assert r.status_code == 200
    assert r.json()["revision"] == 2 and r.json()["start_date"] is None

    stale = client.patch(url, headers=admin_headers, json={"revision": 1, "name": "Écrasement"})
    assert stale.status_code == 409 and stale.json()["code"] == "revision_perimee"
    assert client.get(url, headers=admin_headers).json()["name"] == "Nouvel intitulé"

    # Une modification sans changement réel ne crée pas de révision
    same = client.patch(url, headers=admin_headers, json={"revision": 2, "name": "Nouvel intitulé"})
    assert same.json()["revision"] == 2

    # Incohérence de dates détectée en combinant valeur stockée et valeur reçue
    bad = client.patch(url, headers=admin_headers, json={"revision": 2, "start_date": "2028-01-01"})
    assert bad.status_code == 422 and bad.json()["code"] == "dates_incoherentes"


def test_null_is_refused_for_required_fields(client: TestClient, admin_headers: dict[str, str], create_project) -> None:  # type: ignore[no-untyped-def]
    p = create_project()
    r = client.patch(f"/api/v1/projects/{p['id']}", headers=admin_headers, json={"revision": 1, "name": None})
    assert r.status_code == 422


def test_code_change_checks_uniqueness(client: TestClient, admin_headers: dict[str, str], create_project) -> None:  # type: ignore[no-untyped-def]
    create_project(code="X-1")
    p2 = create_project(code="X-2")
    r = client.patch(f"/api/v1/projects/{p2['id']}", headers=admin_headers, json={"revision": 1, "code": "x-1"})
    assert r.status_code == 409


def test_archived_project_is_read_only_until_unarchived(client: TestClient, admin_headers: dict[str, str], create_project) -> None:  # type: ignore[no-untyped-def]
    p = create_project()
    url = f"/api/v1/projects/{p['id']}"
    archived = client.post(f"{url}/archive", headers=admin_headers, json={"revision": 1}).json()
    assert archived["archived_at"] is not None

    r = client.patch(url, headers=admin_headers, json={"revision": archived["revision"], "name": "Interdit"})
    assert r.status_code == 422 and r.json()["code"] == "projet_archive"
    again = client.post(f"{url}/archive", headers=admin_headers, json={"revision": archived["revision"]})
    assert again.status_code == 422

    restored = client.post(f"{url}/unarchive", headers=admin_headers, json={"revision": archived["revision"]}).json()
    assert restored["status"] == "actif" and restored["archived_at"] is None
    assert client.patch(url, headers=admin_headers, json={"revision": restored["revision"], "name": "Autorisé"}).status_code == 200


def test_unknown_project_returns_french_404(client: TestClient, admin_headers: dict[str, str]) -> None:
    r = client.get("/api/v1/projects/00000000-0000-0000-0000-000000000000", headers=admin_headers)
    assert r.status_code == 404 and r.json()["detail"] == "Projet introuvable."


def test_changes_are_audited_with_old_and_new_values(client: TestClient, admin_headers: dict[str, str], create_project) -> None:  # type: ignore[no-untyped-def]
    p = create_project()
    client.patch(f"/api/v1/projects/{p['id']}", headers=admin_headers, json={"revision": 1, "currency": "USD"})
    with client.app.state.sessionmaker() as db:  # type: ignore[attr-defined]
        entries = db.scalars(select(AuditEntry).where(AuditEntry.entity_id == p["id"]).order_by(AuditEntry.id)).all()
    assert [e.action for e in entries] == ["project.create", "project.update"]
    details = json.loads(entries[1].details)
    assert details["modifications"] == {"currency": ["HTG", "USD"]}
    assert entries[1].username == "admin"
