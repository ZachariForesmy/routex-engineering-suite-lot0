import { useCallback, useEffect, useState } from "react";
import { ApiError, getToken, request, setToken, setUnauthorizedHandler } from "./api";
import { Band } from "./components/Band";
import { Notice, type NoticeState } from "./components/Notice";
import type { AuthStatus, Me, SessionInfo } from "./types";
import { PERMISSIONS } from "./types";
import { AccountView } from "./views/AccountView";
import { AdminView } from "./views/AdminView";
import { LoginView, SetupView } from "./views/AuthViews";
import { ProjectsView } from "./views/ProjectsView";
import { UsersView } from "./views/UsersView";

type Screen = "projects" | "users" | "admin" | "account";

type Phase =
  | { kind: "loading" }
  | { kind: "unreachable"; message: string }
  | { kind: "setup" }
  | { kind: "login"; message: string | null }
  | { kind: "ready"; me: Me };

export function App() {
  const [status, setStatus] = useState<AuthStatus | null>(null);
  const [phase, setPhase] = useState<Phase>({ kind: "loading" });
  const [screen, setScreen] = useState<Screen>("projects");
  const [notice, setNotice] = useState<NoticeState | null>(null);

  const notify = useCallback((n: NoticeState) => setNotice(n), []);

  const boot = useCallback(async () => {
    try {
      const s = await request<AuthStatus>("GET", "/auth/status");
      setStatus(s);
      if (s.setup_required) return setPhase({ kind: "setup" });
      if (!getToken()) return setPhase({ kind: "login", message: null });
      setPhase({ kind: "ready", me: await request<Me>("GET", "/auth/me") });
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) return setPhase({ kind: "login", message: null });
      setPhase({ kind: "unreachable", message: e instanceof ApiError ? e.message : "RouteX ne répond pas." });
    }
  }, []);

  useEffect(() => {
    setUnauthorizedHandler(() => {
      setNotice(null);
      setPhase({ kind: "login", message: "Votre session a expiré ou a été fermée. Reconnectez-vous." });
    });
    void boot();
    return () => setUnauthorizedHandler(null);
  }, [boot]);

  function onSession(session: SessionInfo) {
    setToken(session.token);
    setScreen("projects");
    setNotice(null);
    setPhase({ kind: "ready", me: session.user });
  }

  async function logout() {
    try {
      await request<void>("POST", "/auth/logout");
    } catch {
      /* la session est de toute façon abandonnée côté interface */
    }
    setToken(null);
    setNotice(null);
    setPhase({ kind: "login", message: "Vous êtes déconnecté." });
  }

  function go(next: Screen) {
    setNotice(null);
    setScreen(next);
  }

  const version = status?.version;

  if (phase.kind === "loading") {
    return (
      <>
        <Band version={version} />
        <p className="loading">Démarrage…</p>
      </>
    );
  }
  if (phase.kind === "unreachable") {
    return (
      <>
        <Band version={version} />
        <main className="auth">
          <div className="panel">
            <div className="panel__body stack">
              <h1>RouteX ne répond pas</h1>
              <p>{phase.message}</p>
              <button className="btn btn--primary" type="button" onClick={() => void boot()}>
                Réessayer
              </button>
            </div>
          </div>
        </main>
      </>
    );
  }
  if (phase.kind === "setup") {
    return (
      <>
        <Band version={version} />
        <SetupView onSession={onSession} />
      </>
    );
  }
  if (phase.kind === "login") {
    return (
      <>
        <Band version={version} />
        <LoginView onSession={onSession} message={phase.message} />
      </>
    );
  }

  const { me } = phase;
  const isAdmin = me.permissions.includes(PERMISSIONS.userManage);
  const nav: { id: Screen; label: string; show: boolean }[] = [
    { id: "projects", label: "Projets", show: true },
    { id: "users", label: "Utilisateurs", show: isAdmin },
    { id: "admin", label: "Administration", show: me.permissions.includes(PERMISSIONS.auditRead) },
  ];
  const defaults = { currency: status?.default_currency ?? "HTG", country: status?.default_country ?? "" };

  return (
    <>
      <Band version={version}>
        <nav className="band__nav" aria-label="Navigation principale">
          {nav
            .filter((n) => n.show)
            .map((n) => (
              <button key={n.id} type="button" aria-current={screen === n.id ? "page" : undefined} onClick={() => go(n.id)}>
                {n.label}
              </button>
            ))}
        </nav>
        <div className="band__account">
          <span className="band__user">
            {me.full_name}, {me.role_label.toLowerCase()}
          </span>
          <button type="button" aria-current={screen === "account" ? "page" : undefined} onClick={() => go("account")}>
            Mon compte
          </button>
          <button type="button" onClick={() => void logout()}>
            Se déconnecter
          </button>
        </div>
      </Band>
      {notice && (
        <div className="page page--notice">
          <Notice notice={notice} onClose={() => setNotice(null)} />
        </div>
      )}
      {screen === "projects" && <ProjectsView me={me} defaults={defaults} notify={notify} />}
      {screen === "users" && isAdmin && <UsersView me={me} notify={notify} />}
      {screen === "admin" && isAdmin && <AdminView notify={notify} />}
      {screen === "account" && <AccountView me={me} notify={notify} />}
    </>
  );
}
