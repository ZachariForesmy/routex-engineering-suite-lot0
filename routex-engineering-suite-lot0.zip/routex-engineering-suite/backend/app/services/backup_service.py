"""Sauvegarde de la base SQLite (D-015).

La copie utilise l'API de sauvegarde en ligne de SQLite, cohérente même en
mode WAL et pendant que l'application tourne, puis vérifie l'intégrité de la
copie avant de la conserver sous son nom définitif.
"""

from __future__ import annotations

import hashlib
import re
import sqlite3
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from app.core.timeutil import utcnow

_SAFE_LABEL = re.compile(r"[^a-z0-9-]+")


class BackupError(RuntimeError):
    pass


@dataclass(frozen=True)
class BackupInfo:
    path: Path
    size_bytes: int
    sha256: str
    created_at: datetime
    integrity: str


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def check_integrity(db_file: Path) -> str:
    """Retourne « ok » si ``PRAGMA integrity_check`` ne signale aucun défaut."""
    try:
        conn = sqlite3.connect(f"file:{db_file.as_posix()}?mode=ro", uri=True)
        try:
            rows = conn.execute("PRAGMA integrity_check").fetchall()
        finally:
            conn.close()
    except sqlite3.DatabaseError as exc:
        return f"fichier illisible : {exc}"
    return "ok" if rows == [("ok",)] else "; ".join(str(r[0]) for r in rows)


def create_backup(db_path: Path, backups_dir: Path, label: str = "manuelle") -> BackupInfo:
    if not db_path.exists():
        raise BackupError(f"Base introuvable : {db_path}")
    backups_dir.mkdir(parents=True, exist_ok=True)
    created_at = utcnow()
    stamp = created_at.astimezone().strftime("%Y%m%d-%H%M%S")
    safe_label = _SAFE_LABEL.sub("-", label.lower()).strip("-") or "sauvegarde"
    final = backups_dir / f"routex_{stamp}_{safe_label}.sqlite3"
    counter = 1
    while final.exists():
        counter += 1
        final = backups_dir / f"routex_{stamp}_{safe_label}-{counter}.sqlite3"
    partial = final.with_suffix(".partial")

    source = sqlite3.connect(db_path)
    target = sqlite3.connect(partial)
    try:
        source.backup(target)
        target.execute("PRAGMA journal_mode=DELETE")  # copie autonome, sans fichier -wal
    finally:
        target.close()
        source.close()

    integrity = check_integrity(partial)
    if integrity != "ok":
        partial.unlink(missing_ok=True)
        raise BackupError(f"La copie de sauvegarde est corrompue : {integrity}")
    partial.replace(final)
    return BackupInfo(
        path=final,
        size_bytes=final.stat().st_size,
        sha256=_sha256(final),
        created_at=created_at,
        integrity=integrity,
    )


def list_backups(backups_dir: Path) -> list[Path]:
    if not backups_dir.exists():
        return []
    return sorted(backups_dir.glob("routex_*.sqlite3"), key=lambda p: p.stat().st_mtime, reverse=True)
