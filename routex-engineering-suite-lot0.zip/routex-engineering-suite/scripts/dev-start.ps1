#Requires -Version 5.1
<#
.SYNOPSIS
    Lance RouteX en mode developpement sous Windows.

.DESCRIPTION
    - backend FastAPI avec rechargement automatique sur http://127.0.0.1:8765
      (nouvelle fenetre) ;
    - interface Vite sur http://127.0.0.1:5173 (cette fenetre), qui relaie /api
      vers le backend.
    Les donnees de developpement sont dans .dev-data\ a la racine du depot,
    jamais dans le dossier utilisateur reel.

        powershell -ExecutionPolicy Bypass -File scripts\dev-start.ps1
#>
[CmdletBinding()]
param([string]$Python = "python")

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$Root = Split-Path -Parent $PSScriptRoot
$Backend = Join-Path $Root "backend"
$Frontend = Join-Path $Root "frontend"
$Py = Join-Path $Backend ".venv\Scripts\python.exe"

if (-not (Test-Path $Py)) {
    Write-Host "Creation de l'environnement Python..." -ForegroundColor Cyan
    & $Python -m venv (Join-Path $Backend ".venv")
    & $Py -m pip install --quiet --upgrade pip
    & $Py -m pip install --quiet -c (Join-Path $Backend "requirements-lock.txt") -e "$Backend[dev]"
    if ($LASTEXITCODE -ne 0) { throw "Installation des dependances Python impossible." }
}

if (-not (Test-Path (Join-Path $Frontend "node_modules"))) {
    Write-Host "Installation des dependances de l'interface..." -ForegroundColor Cyan
    Push-Location $Frontend
    try { & npm.cmd ci --no-audit --no-fund } finally { Pop-Location }
    if ($LASTEXITCODE -ne 0) { throw "npm ci a echoue." }
}

$env:ROUTEX_DEV = "1"
$env:ROUTEX_DATA_DIR = Join-Path $Root ".dev-data"

Write-Host "Backend : http://127.0.0.1:8765 (API, documentation sur /docs)" -ForegroundColor Green
Start-Process -FilePath $Py -WorkingDirectory $Backend -ArgumentList @(
    "-m", "uvicorn", "app.main:create_app", "--factory",
    "--host", "127.0.0.1", "--port", "8765", "--reload", "--reload-dir", "app"
)

Write-Host "Interface : http://127.0.0.1:5173" -ForegroundColor Green
Push-Location $Frontend
try { & npm.cmd run dev } finally { Pop-Location }
