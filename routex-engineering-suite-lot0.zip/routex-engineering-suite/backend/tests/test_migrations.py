"""Migrations : base neuve, cohérence modèles/migrations, migration d'une base
existante avec sauvegarde préalable (TX-014), protections au démarrage."""

from __future__ import annotations

import shutil
import sqlite3
from pathlib import Path

import pytest
from alembic.autogenerate import compare_metadata
from alembic.runtime.migration import MigrationContext

import app.models  # noqa: F401
from app.core.errors import DatabaseStateError
from app.db import migrate
from app.db.base import Base
from app.db.session import make_engine
from app.services.backup_service import check_integrity

EXTRA_REVISION = '''"""Révision de test : ajoute une table."""
import sqlalchemy as sa
from alembic import op

revision = "9999"
down_revision = "{head}"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table("test_extra", sa.Column("id", sa.Integer, primary_key=True))
    with op.batch_alter_table("projects") as batch_op:
        batch_op.add_column(sa.Column("test_note", sa.Text(), nullable=True))


def downgrade() -> None:
    with op.batch_alter_table("projects") as batch_op:
        batch_op.drop_column("test_note")
    op.drop_table("test_extra")
'''


def _paths(tmp_path: Path) -> tuple[Path, Path]:
    return tmp_path / "data" / "routex.sqlite3", tmp_path / "backups"


def test_fresh_database_reaches_head(tmp_path: Path) -> None:
    db_path, backups = _paths(tmp_path)
    engine = make_engine(db_path)
    report = migrate.prepare_database(engine, db_path, backups)
    assert report.migrated and report.previous_revision is None and report.backup_path is None
    assert migrate.current_revision(engine) == migrate.head_revision()
    # Second démarrage : rien à faire
    again = migrate.prepare_database(engine, db_path, backups)
    assert not again.migrated
    engine.dispose()


def test_models_match_migrations(tmp_path: Path) -> None:
    """Toute modification de modèle doit être accompagnée d'une migration."""
    db_path, backups = _paths(tmp_path)
    engine = make_engine(db_path)
    migrate.prepare_database(engine, db_path, backups)
    with engine.connect() as conn:
        diff = compare_metadata(MigrationContext.configure(conn, opts={"compare_type": True}), Base.metadata)
    engine.dispose()
    assert diff == [], f"Modèles et migrations divergent : {diff}"


def test_foreign_keys_and_wal_are_active(tmp_path: Path) -> None:
    db_path, backups = _paths(tmp_path)
    engine = make_engine(db_path)
    migrate.prepare_database(engine, db_path, backups)
    with engine.connect() as conn:
        assert conn.exec_driver_sql("PRAGMA foreign_keys").scalar() == 1
        assert conn.exec_driver_sql("PRAGMA journal_mode").scalar() == "wal"
    engine.dispose()


def test_existing_database_is_backed_up_then_migrated_without_data_loss(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, client, create_project, settings  # type: ignore[no-untyped-def]
) -> None:
    """TX-014 : une base « version N » contenant des données passe en « version
    N+1 » ; une sauvegarde est créée avant, les données sont intactes."""
    project = create_project(code="AVANT-MIGRATION")
    client.app.state.engine.dispose()  # type: ignore[attr-defined]

    scripts = tmp_path / "migrations-copy"
    shutil.copytree(migrate.migrations_dir(), scripts, ignore=shutil.ignore_patterns("__pycache__"))
    head = migrate.head_revision()
    (scripts / "versions" / "9999_test_extra.py").write_text(EXTRA_REVISION.format(head=head), encoding="utf-8")
    monkeypatch.setattr(migrate, "migrations_dir", lambda: scripts)

    engine = make_engine(settings.db_path)
    report = migrate.prepare_database(engine, settings.db_path, settings.backups_dir)
    engine.dispose()

    assert report.migrated and report.previous_revision == head and report.current_revision == "9999"
    assert report.backup_path is not None and report.backup_path.exists()
    assert check_integrity(report.backup_path) == "ok"

    conn = sqlite3.connect(settings.db_path)
    try:
        row = conn.execute("SELECT code, name, test_note FROM projects WHERE id = ?", (project["id"],)).fetchone()
        fk_violations = conn.execute("PRAGMA foreign_key_check").fetchall()
    finally:
        conn.close()
    assert row == ("AVANT-MIGRATION", project["name"], None)
    assert fk_violations == []

    # La sauvegarde contient la base dans son état d'avant migration
    backup = sqlite3.connect(report.backup_path)
    try:
        assert backup.execute("SELECT version_num FROM alembic_version").fetchone() == (head,)
        assert backup.execute("SELECT count(*) FROM projects").fetchone() == (1,)
    finally:
        backup.close()


def test_unknown_revision_blocks_startup(tmp_path: Path) -> None:
    db_path, backups = _paths(tmp_path)
    engine = make_engine(db_path)
    migrate.prepare_database(engine, db_path, backups)
    with engine.begin() as conn:
        conn.exec_driver_sql("UPDATE alembic_version SET version_num = 'zzzz-futur'")
    with pytest.raises(DatabaseStateError, match="inconnue"):
        migrate.prepare_database(engine, db_path, backups)
    engine.dispose()


def test_foreign_database_is_not_touched(tmp_path: Path) -> None:
    db_path, backups = _paths(tmp_path)
    db_path.parent.mkdir(parents=True)
    conn = sqlite3.connect(db_path)
    conn.execute("CREATE TABLE autre_logiciel (id INTEGER)")
    conn.commit()
    conn.close()
    engine = make_engine(db_path)
    with pytest.raises(DatabaseStateError, match="n'a pas été créée par RouteX"):
        migrate.prepare_database(engine, db_path, backups)
    engine.dispose()
