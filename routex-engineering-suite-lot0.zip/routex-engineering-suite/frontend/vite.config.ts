import react from "@vitejs/plugin-react";
import { defineConfig } from "vitest/config";

// En développement, l'interface (port 5173) relaie /api vers le backend local.
const backend = `http://127.0.0.1:${process.env.ROUTEX_PORT ?? "8765"}`;

export default defineConfig({
  plugins: [react()],
  server: {
    host: "127.0.0.1",
    port: 5173,
    strictPort: true,
    proxy: { "/api": { target: backend, changeOrigin: false } },
  },
  build: {
    outDir: "dist",
    emptyOutDir: true,
    sourcemap: false,
    assetsInlineLimit: 0, // polices en fichiers (CSP : pas de data: pour font-src)
  },
  test: {
    environment: "node",
    include: ["tests/**/*.test.ts"],
  },
});
