"""Authentification, premier administrateur et sessions (D-007)."""

from __future__ import annotations

import threading
from datetime import datetime, timedelta

from sqlalchemy import delete, func, select, update
from sqlalchemy.orm import Session

from app.core.errors import AuthenticationError, ConflictError
from app.core.permissions import Role
from app.core.security import hash_password, hash_token, needs_rehash, new_session_token, verify_password
from app.core.timeutil import utcnow
from app.models import User, UserSession
from app.services import audit_service
from app.services.actor import Actor

_setup_lock = threading.Lock()

INVALID_CREDENTIALS = "Identifiant ou mot de passe incorrect."
SESSION_EXPIRED = "Session absente ou expirée. Veuillez vous reconnecter."


def actor_from_user(user: User, session_id: str | None = None) -> Actor:
    return Actor(
        id=user.id, username=user.username, full_name=user.full_name, role=user.role, session_id=session_id
    )


def setup_required(db: Session) -> bool:
    return (db.scalar(select(func.count(User.id))) or 0) == 0


def _open_session(db: Session, user: User, hours: int) -> tuple[str, datetime, UserSession]:
    token, token_hash = new_session_token()
    now = utcnow()
    session = UserSession(token_hash=token_hash, user_id=user.id, created_at=now, expires_at=now + timedelta(hours=hours))
    db.add(session)
    db.flush()
    return token, session.expires_at, session


def setup_first_admin(
    db: Session, *, username: str, full_name: str, password: str, session_hours: int
) -> tuple[str, datetime, User]:
    """Crée le premier compte (administrateur). Refusé dès qu'un compte existe."""
    with _setup_lock:
        if not setup_required(db):
            raise ConflictError(
                "L'application est déjà configurée : un compte existe. Connectez-vous.", code="deja_configure"
            )
        user = User(username=username, full_name=full_name, role=Role.ADMIN.value, password_hash=hash_password(password))
        db.add(user)
        db.flush()
        user.last_login_at = utcnow()
        token, expires_at, session = _open_session(db, user, session_hours)
        actor = actor_from_user(user, session.id)
        audit_service.record(db, actor, "auth.setup", entity_type="user", entity_id=user.id)
        audit_service.record(db, actor, "auth.login", entity_type="user", entity_id=user.id)
        db.commit()
        return token, expires_at, user


def login(db: Session, *, username: str, password: str, session_hours: int) -> tuple[str, datetime, User]:
    user = db.scalar(select(User).where(User.username == username))
    if not verify_password(user.password_hash if user else None, password) or user is None:
        audit_service.record(db, None, "auth.login_failed", username=username, details={"identifiant": username[:64]})
        db.commit()
        raise AuthenticationError(INVALID_CREDENTIALS, code="identifiants_invalides")
    if not user.is_active:
        audit_service.record(db, actor_from_user(user), "auth.login_refused_inactive", entity_type="user", entity_id=user.id)
        db.commit()
        raise AuthenticationError("Ce compte est désactivé. Contactez l'administrateur.", code="compte_desactive")

    if needs_rehash(user.password_hash):
        user.password_hash = hash_password(password)
    now = utcnow()
    db.execute(delete(UserSession).where(UserSession.user_id == user.id, UserSession.expires_at < now - timedelta(days=30)))
    user.last_login_at = now
    token, expires_at, session = _open_session(db, user, session_hours)
    audit_service.record(db, actor_from_user(user, session.id), "auth.login", entity_type="user", entity_id=user.id)
    db.commit()
    return token, expires_at, user


def resolve_token(db: Session, token: str) -> tuple[Actor, User]:
    row = db.execute(
        select(UserSession, User).join(User, User.id == UserSession.user_id).where(UserSession.token_hash == hash_token(token))
    ).first()
    if row is None:
        raise AuthenticationError(SESSION_EXPIRED, code="session_invalide")
    session, user = row
    if session.revoked_at is not None or session.expires_at <= utcnow() or not user.is_active:
        raise AuthenticationError(SESSION_EXPIRED, code="session_invalide")
    return actor_from_user(user, session.id), user


def logout(db: Session, actor: Actor) -> None:
    if actor.session_id:
        db.execute(update(UserSession).where(UserSession.id == actor.session_id).values(revoked_at=utcnow()))
    audit_service.record(db, actor, "auth.logout", entity_type="user", entity_id=actor.id)
    db.commit()


def revoke_user_sessions(db: Session, user_id: str, *, except_session: str | None = None) -> None:
    stmt = update(UserSession).where(UserSession.user_id == user_id, UserSession.revoked_at.is_(None))
    if except_session:
        stmt = stmt.where(UserSession.id != except_session)
    db.execute(stmt.values(revoked_at=utcnow()))


def change_password(db: Session, actor: Actor, *, current_password: str, new_password: str) -> None:
    user = db.get(User, actor.id)
    if user is None or not verify_password(user.password_hash, current_password):
        raise AuthenticationError("Mot de passe actuel incorrect.", code="mot_de_passe_incorrect")
    user.password_hash = hash_password(new_password)
    revoke_user_sessions(db, user.id, except_session=actor.session_id)
    audit_service.record(db, actor, "auth.password_changed", entity_type="user", entity_id=user.id)
    db.commit()


def reset_password_offline(db: Session, *, username: str, new_password: str) -> User:
    """Réinitialisation locale (ligne de commande) — nécessite l'accès au poste."""
    user = db.scalar(select(User).where(User.username == username))
    if user is None:
        raise AuthenticationError(f"Aucun compte « {username} ».", code="compte_inconnu")
    user.password_hash = hash_password(new_password)
    user.is_active = True
    revoke_user_sessions(db, user.id)
    audit_service.record(db, None, "auth.password_reset_offline", entity_type="user", entity_id=user.id, username="(console locale)")
    db.commit()
    return user
