export type Role = "admin" | "ingenieur" | "technicien" | "lecture";
export type ProjectStatus = "actif" | "archive";

export interface User {
  id: string;
  username: string;
  full_name: string;
  role: Role;
  role_label: string;
  is_active: boolean;
  created_at: string;
  last_login_at: string | null;
}

export interface Me extends User {
  permissions: string[];
}

export interface SessionInfo {
  token: string;
  expires_at: string;
  user: Me;
}

export interface AuthStatus {
  app_name: string;
  version: string;
  setup_required: boolean;
  default_currency: string;
  default_country: string;
}

export interface Project {
  id: string;
  code: string;
  name: string;
  client: string;
  location: string;
  country: string;
  currency: string;
  unit_system: "SI";
  description: string;
  start_date: string | null;
  end_date: string | null;
  status: ProjectStatus;
  archived_at: string | null;
  revision: number;
  created_at: string;
  updated_at: string;
  created_by_name: string;
  updated_by_name: string;
}

/** Champs saisis dans le formulaire projet (toujours des chaînes côté interface). */
export interface ProjectDraft {
  code: string;
  name: string;
  client: string;
  location: string;
  country: string;
  currency: string;
  description: string;
  start_date: string;
  end_date: string;
}

export interface Backup {
  file_name: string;
  size_bytes: number;
  created_at: string;
  sha256?: string | null;
  integrity?: string | null;
}

export interface AuditEntry {
  id: number;
  at: string;
  username: string;
  action: string;
  entity_type: string;
  entity_id: string;
  details: Record<string, unknown>;
}

export interface AuditPage {
  items: AuditEntry[];
  total: number;
  limit: number;
  offset: number;
}

export const PERMISSIONS = {
  projectWrite: "project.write",
  projectArchive: "project.archive",
  userManage: "user.manage",
  backupCreate: "backup.create",
  auditRead: "audit.read",
} as const;
