import type { Project, ProjectDraft, ProjectStatus } from "./types";

const pad = (n: number) => String(n).padStart(2, "0");

/** « 2026-11-01 » → « 01/11/2026 ». Les dates de projet sont calendaires (sans fuseau). */
export function formatDate(iso: string | null | undefined): string {
  if (!iso) return "";
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  return match ? `${match[3]}/${match[2]}/${match[1]}` : iso;
}

/** Horodatage UTC de l'API → heure locale du poste, ex. « 20/10/2026 18:50 ». */
export function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function statusLabel(status: ProjectStatus): string {
  return status === "archive" ? "Archivé" : "Actif";
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} o`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1).replace(".", ",")} Ko`;
  return `${(bytes / (1024 * 1024)).toFixed(1).replace(".", ",")} Mo`;
}

export const CURRENCIES = ["HTG", "USD", "EUR", "XOF", "XAF", "CAD", "DOP"] as const;

export function emptyDraft(defaultCurrency = "HTG", defaultCountry = "Haïti"): ProjectDraft {
  return {
    code: "",
    name: "",
    client: "",
    location: "",
    country: defaultCountry,
    currency: defaultCurrency,
    description: "",
    start_date: "",
    end_date: "",
  };
}

export function draftFromProject(p: Project): ProjectDraft {
  return {
    code: p.code,
    name: p.name,
    client: p.client,
    location: p.location,
    country: p.country,
    currency: p.currency,
    description: p.description,
    start_date: p.start_date ?? "",
    end_date: p.end_date ?? "",
  };
}

/** Corps de requête de création : dates vides → null, devise en majuscules. */
export function draftToPayload(draft: ProjectDraft): Record<string, string | null> {
  return {
    code: draft.code.trim(),
    name: draft.name.trim(),
    client: draft.client.trim(),
    location: draft.location.trim(),
    country: draft.country.trim(),
    currency: draft.currency.trim().toUpperCase(),
    description: draft.description.trim(),
    start_date: draft.start_date || null,
    end_date: draft.end_date || null,
  };
}

/** Uniquement les champs modifiés (PATCH), pour que le journal d'audit reste exact. */
export function changedFields(original: Project, draft: ProjectDraft): Record<string, string | null> {
  const next = draftToPayload(draft);
  const before = draftToPayload(draftFromProject(original));
  const changes: Record<string, string | null> = {};
  for (const key of Object.keys(next)) {
    if (next[key] !== before[key]) changes[key] = next[key] ?? null;
  }
  return changes;
}

/** Contrôles immédiats côté interface ; le backend reste l'autorité. */
export function validateDraft(draft: ProjectDraft): Record<string, string> {
  const errors: Record<string, string> = {};
  if (!draft.code.trim()) errors.code = "Le code est obligatoire.";
  else if (!/^[A-Za-z0-9][A-Za-z0-9._/-]*$/.test(draft.code.trim()))
    errors.code = "Lettres, chiffres et . _ / - uniquement, sans espace.";
  if (!draft.name.trim()) errors.name = "L'intitulé est obligatoire.";
  if (!/^[A-Za-z]{3}$/.test(draft.currency.trim())) errors.currency = "Code ISO à 3 lettres (ex. HTG, USD).";
  if (draft.start_date && draft.end_date && draft.end_date < draft.start_date)
    errors.end_date = "La date de fin précède la date de début.";
  return errors;
}

const ACTION_LABELS: Record<string, string> = {
  "auth.setup": "Configuration initiale",
  "auth.login": "Connexion",
  "auth.login_failed": "Échec de connexion",
  "auth.login_refused_inactive": "Connexion refusée (compte désactivé)",
  "auth.logout": "Déconnexion",
  "auth.password_changed": "Mot de passe changé",
  "auth.password_reset_offline": "Mot de passe réinitialisé (console)",
  "user.create": "Compte créé",
  "user.update": "Compte modifié",
  "project.create": "Projet créé",
  "project.update": "Projet modifié",
  "project.archive": "Projet archivé",
  "project.unarchive": "Projet désarchivé",
  "export.pdf": "Export PDF",
  "export.xlsx": "Export Excel",
  "export.csv": "Export CSV",
  "backup.create": "Sauvegarde",
};

export function actionLabel(action: string): string {
  return ACTION_LABELS[action] ?? action;
}
