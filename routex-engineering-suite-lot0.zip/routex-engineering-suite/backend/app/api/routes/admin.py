from __future__ import annotations

from datetime import UTC, datetime
from typing import Annotated

from fastapi import APIRouter, Depends, Query, status

from app.api.deps import AppSettings, DbSession, require
from app.core.permissions import Permission
from app.schemas.admin import AuditEntryOut, AuditPageOut, BackupOut
from app.services import audit_service, backup_service
from app.services.actor import Actor

router = APIRouter(prefix="/admin", tags=["Administration"])
BackupOperator = Annotated[Actor, Depends(require(Permission.BACKUP_CREATE))]
Auditor = Annotated[Actor, Depends(require(Permission.AUDIT_READ))]


@router.post("/backup", response_model=BackupOut, status_code=status.HTTP_201_CREATED,
             summary="Sauvegarder la base (copie cohérente + contrôle d'intégrité)")
def create_backup(actor: BackupOperator, db: DbSession, settings: AppSettings) -> BackupOut:
    info = backup_service.create_backup(settings.db_path, settings.backups_dir, label="manuelle")
    audit_service.record(
        db, actor, "backup.create", entity_type="backup", entity_id=info.path.name,
        details={"fichier": info.path.name, "taille_octets": info.size_bytes, "sha256": info.sha256,
                 "integrite": info.integrity},
    )
    db.commit()
    return BackupOut(file_name=info.path.name, size_bytes=info.size_bytes, created_at=info.created_at,
                     sha256=info.sha256, integrity=info.integrity)


@router.get("/backups", response_model=list[BackupOut], summary="Sauvegardes présentes dans le dossier de sauvegarde")
def list_backups(_actor: BackupOperator, settings: AppSettings) -> list[BackupOut]:
    result = []
    for path in backup_service.list_backups(settings.backups_dir):
        stat = path.stat()
        result.append(BackupOut(file_name=path.name, size_bytes=stat.st_size,
                                created_at=datetime.fromtimestamp(stat.st_mtime, tz=UTC)))
    return result


@router.get("/audit-log", response_model=AuditPageOut, summary="Journal d'audit (du plus récent au plus ancien)")
def audit_log(
    _actor: Auditor,
    db: DbSession,
    limit: Annotated[int, Query(ge=1, le=500)] = 100,
    offset: Annotated[int, Query(ge=0)] = 0,
) -> AuditPageOut:
    entries, total = audit_service.list_entries(db, limit, offset)
    items = [
        AuditEntryOut(id=e.id, at=e.at, username=e.username, action=e.action, entity_type=e.entity_type,
                      entity_id=e.entity_id, details=audit_service.parse_details(e))
        for e in entries
    ]
    return AuditPageOut(items=items, total=total, limit=limit, offset=offset)
