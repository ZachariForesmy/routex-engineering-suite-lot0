"""RouteX Engineering Suite — backend local."""

APP_NAME = "RouteX Engineering Suite"
APP_ID = "routex"
__version__ = "0.1.0.dev0"
