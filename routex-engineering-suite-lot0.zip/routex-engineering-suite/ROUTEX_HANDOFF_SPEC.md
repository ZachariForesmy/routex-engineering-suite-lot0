# RouteX Engineering Suite

## Dossier de transfert technique pour Claude et Claude Code

**Version :** 1.0\
**Date :** 20 octobre 2026\
**Statut :** Cahier des charges de référence --- base de développement\
**Langue de travail :** français\
**Cible initiale :** application Windows de bureau, locale et utilisable
hors connexion

------------------------------------------------------------------------

# 1. Instructions de démarrage pour Claude / Claude Code

Tu agis comme un **architecte logiciel senior, développeur full-stack et
ingénieur logiciel spécialisé dans les applications techniques de génie
civil**. Tu dois transformer ce dossier en une application réellement
exécutable, maintenable, testable et documentée.

## Règles impératives

1.  **Lis intégralement ce dossier avant de modifier ou de créer du
    code.**
2.  Ne prétends jamais qu'une fonctionnalité est terminée si elle n'est
    pas implémentée, testée et démontrée.
3.  Développe par lots verticaux, avec une application exécutable à la
    fin de chaque lot.
4.  Ne crée pas de fonctionnalités fictives, de boutons inactifs ou de
    données présentées comme réelles sans les signaler comme données de
    démonstration.
5.  Les calculs d'ingénierie doivent être déterministes, documentés,
    testés avec des cas de référence et soumis à la validation d'un
    ingénieur. L'IA peut assister le développement et la rédaction, mais
    ne doit pas remplacer la validation professionnelle.
6.  Toute formule doit indiquer ses unités, hypothèses, limites d'emploi
    et méthode de calcul.
7.  Ne fixe pas arbitrairement une norme technique ou un coefficient.
    Les normes, paramètres et méthodes doivent être configurables par
    projet, avec référence, version, date et provenance.
8.  L'application doit fonctionner sans connexion Internet après
    installation. Aucune fonctionnalité centrale ne doit dépendre d'un
    service cloud.
9.  Préserve les données existantes lors des migrations de base de
    données. Prévois des sauvegardes et une restauration testable.
10. Utilise Git, des migrations versionnées, des tests automatisés, une
    journalisation exploitable et une documentation actualisée.
11. Si une information essentielle manque, formule une hypothèse
    explicite dans `docs/DECISIONS.md`, puis poursuis sans bloquer
    inutilement le projet. Demande confirmation uniquement si le choix
    peut compromettre l'architecture, la sécurité ou la validité d'un
    calcul.
12. N'implémente pas toutes les disciplines d'un seul coup. Commence par
    le socle et le module métrés/devis, puis ajoute le planning et les
    fonctions avancées.
13. À chaque étape, fournis un résumé des fichiers créés/modifiés, les
    commandes exactes d'installation et de lancement, les tests
    exécutés, leurs résultats et les limites restantes.
14. Ne considère pas le projet prêt à être livré tant que l'installation
    propre sur Windows, l'exécution hors ligne, les tests de calcul, la
    sauvegarde et la restauration n'ont pas été vérifiés.

## Première mission demandée

Commence par : - examiner l'environnement de travail et les outils
disponibles ; - créer le dépôt avec une structure claire ; - créer
`README.md`, `docs/DECISIONS.md`, `docs/ROADMAP.md`, `docs/TEST_PLAN.md`
et les migrations initiales ; - construire un premier vertical slice
exécutable : démarrage de l'application, création d'un projet,
sauvegarde SQLite, affichage de la liste des projets, export d'un
rapport simple en PDF et en Excel ; - exécuter les tests et corriger les
erreurs ; - fournir les commandes pour lancer l'application en mode
développement et construire une version Windows distribuable.

Ne commence pas par générer une énorme quantité de code non testé.
Produis d'abord un socle minimal, fonctionnel et vérifiable.

------------------------------------------------------------------------

# 2. Vision du produit

**Nom du produit :** RouteX Engineering Suite

RouteX est une application locale de bureau destinée à préparer et gérer
des études et dossiers d'exécution pour les travaux de : - routes et
voiries ; - VRD ; - drainage et assainissement ; - alimentation en eau
potable (AEP) ; - réseaux divers ; - métrés, quantitatifs, estimations
et décomptes ; - planification et suivi des travaux ; - échanges de
données avec des logiciels de CAO.

L'application est destinée à des ingénieurs, techniciens, métreurs,
conducteurs de travaux et gestionnaires de projets. Elle doit être
pratique pour une petite équipe travaillant sur un même ordinateur, avec
plusieurs comptes utilisateurs employés successivement.

## Objectifs principaux

1.  Préparer rapidement des métrés et quantitatifs vérifiables.
2.  Produire des devis estimatifs, BPU, DQE, sous-détails de prix et
    pièces jointes de paiement.
3.  Planifier les tâches et suivre l'avancement des travaux.
4.  Importer/exporter les données et dessins compatibles DXF.
5.  Construire progressivement des outils de géométrie routière,
    cubatures, drainage, assainissement, AEP et réseaux.
6.  Générer des documents professionnels PDF et des tableaux Excel.
7.  Maintenir une traçabilité des calculs, versions, modifications et
    validations.
8.  fonctionner hors connexion, sans dépendance obligatoire à un
    abonnement ou service distant.

## Principes de conception

-   Fiabilité avant sophistication.
-   Calculs transparents et reproductibles.
-   Unités explicites et conversions contrôlées.
-   Paramètres et normes configurables.
-   Traçabilité des hypothèses et des révisions.
-   Interface en français dans la première version.
-   Architecture modulaire permettant d'ajouter des fonctions sans
    réécrire le socle.
-   Aucune prétention de conformité réglementaire automatique sans
    vérification et validation des règles applicables.

------------------------------------------------------------------------

# 3. Périmètre fonctionnel et priorités

## P0 --- Socle indispensable

-   Installation et lancement sur Windows.
-   Interface locale.
-   Comptes utilisateurs et rôles de base.
-   Création, modification, archivage et recherche de projets.
-   Paramètres par projet : client/maître d'ouvrage, pays, devise,
    unités, dates, références techniques.
-   Base de données SQLite locale.
-   Gestion de documents, pièces jointes et révisions.
-   Journal des opérations importantes.
-   Sauvegarde et restauration.
-   Export PDF, XLSX et CSV.
-   Mode hors connexion vérifié.

## P1 --- Métrés et estimations

-   Bibliothèque d'ouvrages et de postes de prix.
-   Création de postes propres à un projet.
-   Unités et conversions.
-   Métrés manuels et calculés.
-   Formules configurables et documentées.
-   BPU (bordereau des prix unitaires).
-   DQE (détail quantitatif et estimatif).
-   Sous-détails de prix : matériaux, main-d'œuvre, matériel, transport,
    frais, marges et autres paramètres configurables.
-   Totaux, sous-totaux, taxes et arrondis paramétrables.
-   Historique des prix et des versions.
-   Fiches de calcul et rapports imprimables.
-   Import/export de tableaux Excel selon des modèles documentés.

## P2 --- Attachements et décomptes

-   Attachements par période.
-   Quantités mesurées, présentées, vérifiées, acceptées et cumulées.
-   Quantités contractuelles et dépassements.
-   Historique des corrections.
-   Circuit de validation configurable.
-   Décompte provisoire et récapitulatif des paiements.
-   Export PDF et XLSX.
-   Conservation des attachements antérieurs après correction ou
    révision.

## P3 --- Planning et suivi

-   Structure de découpage du projet (WBS).
-   Tâches, durées, calendriers et jalons.
-   Liens de dépendance entre tâches.
-   Diagramme de Gantt.
-   Calcul du chemin critique et des marges.
-   Ressources humaines, équipements et équipes.
-   Productivité prévue/réelle.
-   Avancement planifié/réel.
-   Baseline de référence et mises à jour.
-   Journal des changements de planning.
-   Export du planning.

## P4 --- CAO et topographie

-   Import/export DXF.
-   Liste des calques, entités et unités.
-   Import de points topographiques CSV/TXT selon un modèle configuré.
-   Contrôle des champs, unités, doublons, coordonnées invalides et
    systèmes de coordonnées.
-   Export des points et résultats vers CSV/XLSX/DXF.
-   Journal d'import avec avertissements.
-   Préserver les fichiers sources et ne jamais les écraser
    silencieusement.
-   Ne pas annoncer une compatibilité DWG native dans la V1. L'échange
    DWG doit passer par un logiciel ou convertisseur compatible choisi
    et testé par l'utilisateur.

## P5 --- Études d'exécution avancées

Développer séparément, avec tests de référence et validation
professionnelle :

### Voirie

-   axes et éléments géométriques ;
-   alignements et courbes ;
-   profils en long et profils en travers ;
-   sections types ;
-   surfaces et cubatures ;
-   calculs de terrassement ;
-   génération de tableaux et rapports d'exécution.

### Drainage et assainissement

-   bassins versants et paramètres hydrologiques ;
-   calculs de débit selon méthode sélectionnée ;
-   conduites, regards, caniveaux et exutoires ;
-   calcul hydraulique avec hypothèses explicites ;
-   tableaux de résultats et vérifications de capacité.

### AEP

-   nœuds, conduites, réservoirs et accessoires ;
-   pertes de charge selon une méthode choisie et documentée ;
-   contrôles de pression et de vitesse ;
-   calcul de réseaux ramifiés dans une première étape ;
-   solveur de réseaux maillés uniquement après définition d'une méthode
    numérique validée et de cas de référence.

### Réseaux divers

-   objets et segments de réseau ;
-   nomenclature, longueurs, profondeurs et quantités ;
-   profils et détails d'exécution selon les besoins définis.

## Hors périmètre initial

-   Calcul structurel certifié.
-   Remplacement complet de logiciels professionnels de CAO/BIM.
-   Édition DWG native garantie.
-   Calculs hydrauliques ou géométriques sans données d'entrée
    contrôlées.
-   Certification automatique de conformité aux normes.
-   Collaboration multi-postes simultanée en réseau.
-   Synchronisation cloud obligatoire.
-   Décisions d'ingénierie prises automatiquement par un modèle d'IA
    sans validation humaine.

------------------------------------------------------------------------

# 4. Utilisateurs et droits

Prévoir au minimum les rôles suivants :

-   **Administrateur** : utilisateurs, paramètres globaux,
    sauvegarde/restauration, configuration.
-   **Ingénieur/Responsable** : projets, calculs, validation, révisions,
    rapports.
-   **Technicien/Métreur** : saisie et modification des données
    autorisées, métrés, import de fichiers.
-   **Lecture seule** : consultation et export autorisé.

Les droits doivent être contrôlés côté backend, et pas uniquement en
masquant des boutons dans l'interface. Le système peut être utilisé par
2 à 5 comptes sur le même ordinateur, successivement. La version
initiale n'a pas besoin de permettre l'édition concurrente depuis
plusieurs ordinateurs.

------------------------------------------------------------------------

# 5. Architecture technique recommandée

## Cible

Application Windows locale, avec interface de bureau ou interface web
locale empaquetée. L'utilisateur ne doit pas avoir à gérer manuellement
un serveur.

## Stack de départ

-   **Frontend :** React + TypeScript.
-   **Backend :** Python + FastAPI.
-   **Base de données :** SQLite, avec migrations versionnées.
-   **Accès base :** SQLAlchemy ou une couche d'accès équivalente, avec
    transactions explicites.
-   **Validation des données :** Pydantic côté API et validation
    complémentaire côté interface.
-   **Rapports :** bibliothèque PDF maintenue et `openpyxl` pour les
    fichiers XLSX.
-   **CAO :** bibliothèque DXF compatible, par exemple `ezdxf`, après
    vérification de licence et des entités nécessaires.
-   **Tests :** pytest côté backend et outil de test adapté au frontend.
-   **Packaging Windows :** choisir et documenter une solution
    appropriée après un prototype technique ; ne pas mélanger plusieurs
    approches de packaging sans raison.
-   **Git :** contrôle de version obligatoire.

Cette stack est une proposition initiale. Avant de figer les
dépendances, vérifie les versions stables compatibles, les licences, la
disponibilité hors ligne et la faisabilité du packaging Windows. Ne
dépends pas de téléchargements en ligne au démarrage de l'application.

## Vue logique

``` text
Utilisateur
   |
Interface locale (React + TypeScript)
   |
API locale (FastAPI)
   |
Services métier
   |-- Projets et utilisateurs
   |-- Métrés et quantitatifs
   |-- Prix et estimations
   |-- Attachements
   |-- Planning
   |-- CAO / topographie
   |-- Calculs d'ingénierie
   |-- Rapports et exports
   |-- Sauvegarde et audit
   |
SQLite + répertoire de documents du projet
```

## Contraintes d'architecture

-   Séparer l'interface, l'API, les règles métier et l'accès aux
    données.
-   Les formules de calcul ne doivent pas être écrites directement dans
    les composants d'interface.
-   Utiliser des transactions pour les opérations multi-tables.
-   Ajouter des migrations pour chaque changement de schéma.
-   Enregistrer les nombres avec une précision adaptée ; définir une
    stratégie explicite pour les arrondis monétaires et les quantités.
-   Stocker les dates et heures selon une convention documentée.
-   Prévoir les erreurs, les journaux et des messages utilisateurs
    compréhensibles.
-   Ne jamais supprimer définitivement un projet ou un document sans
    confirmation et règle de conservation définie.
-   Ne pas stocker les mots de passe en clair ; utiliser une méthode de
    hachage reconnue.
-   Les secrets et clés ne doivent pas être codés en dur dans le dépôt.

------------------------------------------------------------------------

# 6. Structure de dépôt proposée

``` text
routex-engineering-suite/
├── README.md
├── CHANGELOG.md
├── LICENSE-THIRD-PARTY.md
├── .gitignore
├── .env.example
├── docs/
│   ├── SPECIFICATION.md
│   ├── ARCHITECTURE.md
│   ├── DECISIONS.md
│   ├── ROADMAP.md
│   ├── TEST_PLAN.md
│   ├── ENGINEERING_FORMULAS.md
│   ├── DATABASE.md
│   ├── API.md
│   ├── INSTALL_WINDOWS.md
│   ├── USER_GUIDE.md
│   ├── BACKUP_RESTORE.md
│   └── RELEASE_CHECKLIST.md
├── frontend/
│   ├── package.json
│   ├── src/
│   └── tests/
├── backend/
│   ├── pyproject.toml
│   ├── app/
│   │   ├── main.py
│   │   ├── api/
│   │   ├── core/
│   │   ├── db/
│   │   ├── models/
│   │   ├── schemas/
│   │   ├── services/
│   │   ├── calculations/
│   │   ├── exports/
│   │   └── cad/
│   └── tests/
├── migrations/
├── templates/
│   ├── reports/
│   ├── excel/
│   └── imports/
├── sample_data/
│   └── README.md
├── scripts/
│   ├── dev-start.ps1
│   ├── build-windows.ps1
│   └── verify-release.ps1
└── packaging/
```

Ajuste la structure si un prototype démontre qu'une autre organisation
est plus robuste, mais documente toute déviation.

------------------------------------------------------------------------

# 7. Modèle de données initial

Créer des migrations et contraintes de clés étrangères. Les tables
suivantes sont une base conceptuelle ; les normaliser et les compléter
avant la mise en production.

## Identité et projets

-   `users`
-   `roles` ou rôles contrôlés
-   `project_memberships`
-   `projects`
-   `project_settings`
-   `disciplines`
-   `project_disciplines`
-   `reference_standards`
-   `project_standards`

## Documents et audit

-   `documents`
-   `document_revisions`
-   `audit_log`
-   `backup_history`

## Bibliothèque et métrés

-   `work_items`
-   `project_work_items`
-   `formula_definitions`
-   `quantity_takeoffs`
-   `calculations`
-   `calculation_dependencies`

## Prix et estimations

-   `price_items`
-   `estimates`
-   `estimate_lines`

## Attachements

-   `attachments`
-   `attachment_lines`
-   `attachment_approvals`

## Planning

-   `tasks`
-   `task_dependencies`
-   `task_updates`
-   `task_baselines`
-   `resources`
-   `task_resources`

## Géométrie et réseaux --- ajout progressif

-   `survey_points`
-   `alignments`
-   `alignment_elements`
-   `profiles`
-   `profile_points`
-   `network_nodes`
-   `network_segments`

## Principes de données

-   Chaque enregistrement métier doit avoir un identifiant stable.
-   Utiliser les clés étrangères et des index sur les champs fréquemment
    recherchés.
-   Prévoir `created_at`, `updated_at` et, lorsque pertinent,
    `created_by`.
-   Utiliser une suppression logique ou un archivage pour les données
    importantes.
-   Chaque calcul doit pouvoir retrouver ses données d'entrée, formule,
    unités, version du moteur et date d'exécution.
-   Les révisions approuvées ne doivent pas être écrasées
    silencieusement.
-   Toute migration doit être testée sur une base neuve et une copie
    d'une base existante.

------------------------------------------------------------------------

# 8. Règles métier et formules initiales

Les formules ci-dessous sont des exemples de méthodes à implémenter, non
une déclaration de conformité universelle. Les méthodes et coefficients
doivent être choisis et validés pour chaque projet.

## 8.1 Quantité et estimation

Pour un poste (i) :

\[ M_i = Q_i `\times `{=tex}PU_i \]

où : - (Q_i) = quantité retenue ; - (PU_i) = prix unitaire applicable à
la version sélectionnée ; - (M_i) = montant du poste.

Le système doit distinguer quantité brute, quantité corrigée, unité,
formule, hypothèses, date, auteur et révision.

## 8.2 Aire d'une section polygonale

Pour une liste ordonnée de coordonnées planes fermant un polygone,
appliquer la formule du lacet (shoelace) et contrôler que le polygone
est valide. Définir le traitement des auto-intersections, des unités et
des coordonnées invalides.

## 8.3 Cubature --- méthode des aires moyennes

\[ V = `\frac{A_1 + A_2}{2}`{=tex} `\times `{=tex}d \]

où (A_1) et (A_2) sont les aires des sections consécutives et (d) la
distance entre elles. Afficher la méthode et avertir l'utilisateur
qu'elle est une approximation.

## 8.4 Cubature --- formule prismoïdale

\[ V = `\frac{d}{6}`{=tex}(A_1 + 4A_m + A_2) \]

où (A_m) est l'aire de la section médiane. Ne pas présenter cette
méthode comme disponible si la section médiane n'est pas connue ou
calculée.

## 8.5 Courbe circulaire simple

\[ L = R`\theta`{=tex} \]

où (R) est le rayon et (`\theta`{=tex}) l'angle au centre exprimé en
radians. Si l'utilisateur entre des degrés, effectuer une conversion
explicite et afficher l'unité.

## 8.6 Hydrologie --- méthode rationnelle

\[ Q = C i A \]

La conversion des unités est obligatoire. Le système doit demander la
méthode retenue, les unités de (i) et de (A), la source des paramètres
et les limites d'application. Ne pas utiliser un coefficient de
ruissellement par défaut sans le signaler.

## 8.7 Écoulement uniforme --- Manning

\[ Q = `\frac{1}{n}`{=tex} A_h R_h\^{2/3} S\^{1/2} \]

où (A_h) est la section mouillée, (R_h) le rayon hydraulique, (S) la
pente d'énergie et (n) le coefficient de Manning. Vérifier les unités,
la géométrie et le domaine d'application. Les conditions limites et les
hypothèses doivent apparaître dans le rapport.

## 8.8 Réseaux AEP

-   Sélection explicite de la méthode de pertes de charge.
-   Unités homogènes et conversions testées.
-   Contrôles de pression et de vitesse.
-   Réseaux ramifiés avant réseaux maillés.
-   Aucun solveur maillé en production sans tests de convergence, bilan
    de masse et cas de référence.
-   Les résultats doivent inclure les hypothèses et avertissements.

## 8.9 Planning

Le calcul du chemin critique doit gérer les dépendances, calendriers,
durées, jalons et cycles invalides. Un cycle de dépendances doit
produire un message compréhensible et bloquer le calcul plutôt que
générer un résultat trompeur.

------------------------------------------------------------------------

# 9. Imports, exports et rapports

## Formats

-   PDF : rapports lisibles, paginés et prêts à imprimer.
-   XLSX : feuilles structurées, en-têtes, unités, formules documentées
    lorsque pertinent, totaux et styles professionnels.
-   CSV : import/export des données tabulaires.
-   DXF : géométrie CAO, avec rapport d'import/export.
-   TXT/CSV : points topographiques selon des modèles paramétrables.

## Règles

-   Prévisualiser et valider un import avant enregistrement.
-   Détecter les colonnes manquantes, unités incohérentes, lignes
    invalides et doublons.
-   Afficher un bilan : lignes lues, acceptées, rejetées et
    avertissements.
-   Ne jamais écraser un fichier source sans confirmation explicite.
-   Pour chaque export, enregistrer la date, le projet, la révision et
    les options de génération.
-   Ajouter une page de garde et un pied de page configurables aux
    rapports.
-   Les exports ne doivent pas être les seules copies des données : la
    base locale reste la source structurée.

------------------------------------------------------------------------

# 10. API locale indicative

Préfixe : `/api/v1`

Routes indicatives, à adapter au besoin : - `POST /auth/login` -
`GET /projects` - `POST /projects` - `GET /projects/{project_id}` -
`PATCH /projects/{project_id}` -
`GET /projects/{project_id}/documents` -
`POST /projects/{project_id}/documents` -
`GET /projects/{project_id}/takeoffs` -
`POST /projects/{project_id}/takeoffs` -
`POST /projects/{project_id}/takeoffs/preview` -
`GET /projects/{project_id}/estimates` -
`POST /projects/{project_id}/estimates` -
`GET /projects/{project_id}/attachments` -
`POST /projects/{project_id}/attachments` -
`GET /projects/{project_id}/schedule` -
`POST /projects/{project_id}/schedule/tasks` -
`POST /imports/points/preview` - `POST /imports/dxf/preview` -
`POST /exports/dxf` - `POST /reports/pdf` - `POST /reports/xlsx` -
`POST /admin/backup` - `POST /admin/restore` - `GET /admin/audit-log`

Chaque route doit disposer de schémas d'entrée/sortie, validation,
gestion des erreurs, droits d'accès et tests. Documenter l'API générée
par FastAPI et les codes d'erreur.

------------------------------------------------------------------------

# 11. Sécurité, sauvegarde et mode hors ligne

-   Stocker la base et les fichiers dans un répertoire utilisateur
    documenté, pas dans un répertoire temporaire.
-   Prévoir une sauvegarde manuelle et, si approprié, une sauvegarde
    automatique configurable.
-   La restauration doit vérifier l'intégrité de la sauvegarde et
    demander confirmation avant de remplacer les données.
-   Tester une restauration complète dans un emplacement isolé.
-   Exclure la base active et les secrets du dépôt Git.
-   Ajouter une procédure de récupération après panne.
-   Ne pas envoyer de données de projet vers Internet.
-   Signaler clairement toute fonction qui nécessite ultérieurement une
    connexion.
-   Le premier lancement doit pouvoir créer la base et l'utilisateur
    administrateur selon une procédure sûre.
-   Documenter la réinitialisation de mot de passe et la gestion des
    comptes.
-   Protéger les exports et pièces de projet selon les droits des
    utilisateurs.

------------------------------------------------------------------------

# 12. Stratégie de tests et critères d'acceptation

## Tests techniques

-   Tests unitaires des formules et conversions.
-   Tests d'intégration API/base de données.
-   Tests de migration.
-   Tests d'import/export.
-   Tests d'autorisation.
-   Tests de génération PDF/XLSX.
-   Tests de sauvegarde/restauration.
-   Tests de packaging et de démarrage hors connexion.
-   Tests d'interface sur les parcours essentiels.

## Tests de référence d'ingénierie

Créer des cas documentés avec : - données d'entrée ; - unités ; -
méthode ; - résultat attendu ; - tolérance ; - source ou validation de
l'ingénieur ; - version du moteur de calcul.

Ne pas inventer de valeurs de référence pour déclarer un calcul exact.
Tant qu'un ingénieur n'a pas approuvé le cas, le marquer « provisoire
--- à valider ».

## Matrice d'acceptation initiale

-   **TX-001** : création, fermeture et réouverture d'un projet sans
    perte.
-   **TX-002** : sauvegarde et restauration d'une base de test.
-   **TX-003** : conversion d'unités avec cas de référence.
-   **TX-004** : calcul d'un montant de poste et total général.
-   **TX-005** : conservation de l'historique des prix.
-   **TX-006** : génération d'un attachement avec quantités cumulées.
-   **TX-007** : détection d'un cycle dans les dépendances du planning.
-   **TX-008** : import de points valide et rejet documenté des lignes
    invalides.
-   **TX-009** : export DXF et vérification de la réouverture dans un
    outil compatible.
-   **TX-010** : génération PDF avec pagination correcte.
-   **TX-011** : génération XLSX avec nombres, unités et totaux
    cohérents.
-   **TX-012** : contrôle des droits sur les opérations sensibles.
-   **TX-013** : fonctionnement après désactivation du réseau.
-   **TX-014** : migration d'une base existante vers la nouvelle
    version.
-   **TX-015** : calcul de cubature comparé à un cas de référence
    validé.
-   **TX-016** : test hydraulique comparé à un cas de référence validé
    avant activation de la fonction.
-   **TX-017** : aucune modification silencieuse d'un document source
    lors d'un import.
-   **TX-018** : avertissement lorsqu'un calcul dépend de données
    modifiées depuis son dernier calcul.

## Seuils de livraison

-   Aucun défaut bloquant ou critique ouvert.
-   Tous les cas de référence approuvés passent.
-   Tests automatisés des fonctions métier critiques.
-   Sauvegarde et restauration vérifiées.
-   Installation propre sur Windows vérifiée.
-   Fonctionnement hors ligne vérifié.
-   Documentation d'installation et de récupération disponible.
-   Liste des limites connues publiée.

Un pourcentage de couverture de tests est utile, mais ne remplace pas la
qualité des cas de référence et leur validation métier.

------------------------------------------------------------------------

# 13. Feuille de route de développement

## Lot 0 --- Cadrage et preuve technique

-   Valider les décisions techniques.
-   Vérifier les dépendances et licences.
-   Prototyper le lancement local et le packaging Windows.
-   Créer le dépôt, les conventions et les premiers tests.

**Sortie attendue :** application squelette qui démarre localement.

## Lot 1 --- Socle

-   Interface principale.
-   Base SQLite et migrations.
-   Utilisateurs et rôles.
-   Projets, paramètres, documents.
-   Journal d'audit et sauvegarde.

**Sortie attendue :** application locale utilisable pour gérer des
projets.

## Lot 2 --- Métrés

-   Ouvrages, unités, formules.
-   Saisie et calcul des quantités.
-   Fiches de calcul et exports.

**Sortie attendue :** module de métrés vérifiable.

## Lot 3 --- Estimations

-   BPU, DQE, sous-détails de prix.
-   Gestion des versions et révisions.
-   Exports PDF/XLSX.

**Sortie attendue :** production d'un dossier quantitatif et estimatif.

## Lot 4 --- Attachements

-   Mesures périodiques.
-   Quantités présentées/acceptées/cumulées.
-   Workflow de validation et décomptes.

## Lot 5 --- Planning

-   Tâches, calendriers, dépendances, Gantt.
-   Chemin critique.
-   Avancement et ressources.

## Lot 6 --- CAO et topographie

-   Import points.
-   Import/export DXF.
-   Validation et rapport d'import.

## Lot 7 --- Géométrie routière et cubatures

-   Axes, profils, sections et volumes.
-   Cas de référence validés par un ingénieur.

## Lot 8 --- Drainage, assainissement et AEP

-   Hydrologie et hydraulique.
-   Réseaux et contrôles.
-   Activation progressive après validation des résultats.

Chaque lot doit se terminer par une version exécutable, un jeu de tests,
une documentation et une démonstration reproductible.

------------------------------------------------------------------------

# 14. Développement assisté par IA

L'IA peut aider à : - structurer le code ; - générer des composants et
services ; - écrire des tests ; - produire la documentation ; - analyser
des erreurs ; - proposer des cas limites ; - préparer des scripts de
packaging.

L'IA ne doit pas : - déclarer un calcul conforme à une norme sans preuve
; - inventer les données de référence ; - valider seule les résultats
d'ingénierie ; - effacer des données ou changer le schéma sans migration
; - ajouter une dépendance sans vérifier licence, maintenance et
compatibilité ; - masquer un test échoué ou une fonctionnalité
incomplète.

Pour chaque fonction d'ingénierie, le processus attendu est : 1.
spécification de la méthode ; 2. définition des unités et hypothèses ;
3. implémentation isolée ; 4. tests unitaires et cas limites ; 5.
comparaison avec des résultats de référence ; 6. validation par
l'ingénieur responsable ; 7. documentation de la version ; 8. activation
dans l'application.

------------------------------------------------------------------------

# 15. Livrables attendus

-   `SRC-01` : code source complet.
-   `BUILD-01` : procédure de construction reproductible.
-   `APP-01` : installateur ou paquet Windows exécutable.
-   `DB-01` : schéma de base et migrations.
-   `API-01` : documentation API.
-   `DOC-01` : manuel utilisateur en français.
-   `DOC-02` : manuel technique et architecture.
-   `DOC-03` : procédure de sauvegarde/restauration.
-   `CALC-01` : catalogue des formules, unités, hypothèses et limites.
-   `TEST-01` : tests automatisés et résultats.
-   `REF-01` : cas de référence d'ingénierie approuvés.
-   `TPL-01` : modèles PDF/XLSX/CSV.
-   `REL-01` : notes de version, limites connues et liste de
    vérification de livraison.

------------------------------------------------------------------------

# 16. Décisions ouvertes à consigner

Claude Code doit créer `docs/DECISIONS.md` et consigner au minimum : -
technologie de packaging Windows retenue ; - emplacement de la base et
des documents ; - gestion des mots de passe et récupération des comptes
; - devise par défaut et prise en charge de plusieurs devises ; - unités
par défaut et stratégie de conversion ; - modèles PDF/XLSX ; - versions
DXF supportées et entités prises en charge ; - conventions d'import des
points topographiques ; - références normatives et méthodes disponibles
par discipline ; - politique de sauvegarde ; - stratégie de
versionnement et de migration ; - politique de conservation et
d'archivage.

Ne bloque pas le développement sur les paramètres non essentiels :
choisis des valeurs de départ clairement documentées et modifiables, à
l'exception des décisions qui touchent la validité des calculs, la
sécurité ou l'intégrité des données.

------------------------------------------------------------------------

# 17. Définition de « version exécutable »

Une version ne peut être qualifiée d'exécutable/livrable que si : - elle
s'installe ou se lance sur un Windows propre selon une procédure
documentée ; - elle démarre sans accès Internet ; - elle permet de
créer, enregistrer, fermer et rouvrir un projet ; - elle conserve ses
données après redémarrage ; - les fonctions annoncées sont réellement
disponibles ; - les erreurs sont gérées sans corruption de la base ; -
les rapports annoncés peuvent être exportés et ouverts ; - les tests
pertinents passent ; - la sauvegarde et la restauration fonctionnent ; -
les limites connues sont listées.

Un prototype qui ne remplit pas encore tous ces critères doit être nommé
« prototype » ou « version de développement », et non version finale.

------------------------------------------------------------------------

# 18. Prompt court à utiliser dans Claude Code

Après avoir placé ce fichier à la racine du dépôt sous le nom
`ROUTEX_HANDOFF_SPEC.md`, envoyer à Claude Code :

> Lis entièrement `ROUTEX_HANDOFF_SPEC.md` et suis ses règles. Commence
> par inspecter le dépôt et l'environnement, puis crée
> `docs/DECISIONS.md`, `docs/ROADMAP.md`, `docs/TEST_PLAN.md` et une
> structure de projet propre. Implémente le Lot 0 et un premier vertical
> slice réellement exécutable : application locale, base SQLite avec
> migrations, création/liste/édition de projets, export simple PDF et
> XLSX, tests automatisés et procédure de lancement Windows. Ne passe
> pas aux modules d'ingénierie avancés tant que le socle n'est pas
> testé. Exécute les tests, corrige les erreurs et rapporte précisément
> les résultats, les fichiers modifiés, les commandes de lancement et
> les limites restantes. Ne prétends pas avoir construit ou testé un
> installateur si ce n'est pas le cas.

------------------------------------------------------------------------

# 19. Note de cadrage

Ce dossier est un cahier des charges logiciel et un plan de transfert,
pas un logiciel déjà compilé. La production d'une application Windows
exige l'implémentation dans un environnement de développement,
l'exécution des tests et la construction du paquet. Les calculs destinés
à des travaux réels doivent être contrôlés par un ingénieur compétent et
comparés à des références validées avant leur utilisation
professionnelle.
