from __future__ import annotations

from datetime import timedelta

from fastapi.testclient import TestClient
from sqlalchemy import select, update

from app.core.timeutil import utcnow
from app.models import AuditEntry, User, UserSession
from tests.conftest import ADMIN, DEFAULT_PASSWORD, bearer


def _audit_actions(client: TestClient) -> list[str]:
    with client.app.state.sessionmaker() as db:  # type: ignore[attr-defined]
        return list(db.scalars(select(AuditEntry.action).order_by(AuditEntry.id)).all())


def test_first_launch_requires_setup_then_only_once(client: TestClient) -> None:
    assert client.get("/api/v1/auth/status").json()["setup_required"] is True
    r = client.post("/api/v1/auth/setup", json=ADMIN)
    assert r.status_code == 201
    body = r.json()
    assert body["user"]["role"] == "admin"
    assert "user.manage" in body["user"]["permissions"]
    assert client.get("/api/v1/auth/status").json()["setup_required"] is False

    again = client.post("/api/v1/auth/setup", json={**ADMIN, "username": "intrus"})
    assert again.status_code == 409
    assert again.json()["code"] == "deja_configure"


def test_password_is_hashed_with_argon2(client: TestClient, admin_headers: dict[str, str]) -> None:
    with client.app.state.sessionmaker() as db:  # type: ignore[attr-defined]
        user = db.scalar(select(User).where(User.username == "admin"))
        assert user is not None
        assert user.password_hash.startswith("$argon2id$")
        assert ADMIN["password"] not in user.password_hash
        token_hashes = db.scalars(select(UserSession.token_hash)).all()
    token = admin_headers["Authorization"].split()[1]
    assert token not in token_hashes  # seule l'empreinte est stockée


def test_short_password_is_rejected(client: TestClient) -> None:
    r = client.post("/api/v1/auth/setup", json={**ADMIN, "password": "court"})
    assert r.status_code == 422
    assert "Mot de passe" in r.json()["detail"]


def test_login_success_is_case_insensitive_and_audited(client: TestClient, admin_headers: dict[str, str]) -> None:
    r = client.post("/api/v1/auth/login", json={"username": "ADMIN", "password": ADMIN["password"]})
    assert r.status_code == 200
    assert r.json()["user"]["username"] == "admin"
    assert _audit_actions(client).count("auth.login") == 2


def test_login_failure_gives_generic_message_and_is_audited(client: TestClient, admin_headers: dict[str, str]) -> None:
    wrong_pwd = client.post("/api/v1/auth/login", json={"username": "admin", "password": "mauvais-mot-de-passe"})
    unknown = client.post("/api/v1/auth/login", json={"username": "personne", "password": "mauvais-mot-de-passe"})
    assert wrong_pwd.status_code == unknown.status_code == 401
    assert wrong_pwd.json()["detail"] == unknown.json()["detail"] == "Identifiant ou mot de passe incorrect."
    assert _audit_actions(client).count("auth.login_failed") == 2


def test_requests_without_valid_token_are_rejected(client: TestClient, admin_headers: dict[str, str]) -> None:
    assert client.get("/api/v1/projects").status_code == 401
    assert client.get("/api/v1/projects", headers=bearer("jeton-invente")).status_code == 401
    assert client.get("/api/v1/projects", headers={"Authorization": "Basic abc"}).status_code == 401


def test_logout_revokes_token(client: TestClient, admin_headers: dict[str, str]) -> None:
    assert client.get("/api/v1/auth/me", headers=admin_headers).status_code == 200
    assert client.post("/api/v1/auth/logout", headers=admin_headers).status_code == 204
    assert client.get("/api/v1/auth/me", headers=admin_headers).status_code == 401


def test_expired_session_is_rejected(client: TestClient, admin_headers: dict[str, str]) -> None:
    with client.app.state.sessionmaker() as db:  # type: ignore[attr-defined]
        db.execute(update(UserSession).values(expires_at=utcnow() - timedelta(minutes=1)))
        db.commit()
    r = client.get("/api/v1/auth/me", headers=admin_headers)
    assert r.status_code == 401
    assert "expirée" in r.json()["detail"]


def test_deactivated_user_cannot_login_and_loses_sessions(client: TestClient, admin_headers: dict[str, str], make_user) -> None:  # type: ignore[no-untyped-def]
    tech_headers = make_user("technicien", "tech1")
    users = client.get("/api/v1/users", headers=admin_headers).json()
    tech_id = next(u["id"] for u in users if u["username"] == "tech1")
    assert client.patch(f"/api/v1/users/{tech_id}", headers=admin_headers, json={"is_active": False}).status_code == 200
    assert client.get("/api/v1/auth/me", headers=tech_headers).status_code == 401
    r = client.post("/api/v1/auth/login", json={"username": "tech1", "password": DEFAULT_PASSWORD})
    assert r.status_code == 401 and r.json()["code"] == "compte_desactive"


def test_change_password_revokes_other_sessions(client: TestClient, admin_headers: dict[str, str]) -> None:
    other = bearer(client.post("/api/v1/auth/login", json={"username": "admin", "password": ADMIN["password"]}).json()["token"])
    bad = client.post("/api/v1/auth/change-password", headers=admin_headers,
                      json={"current_password": "faux-mot-de-passe", "new_password": "nouveau-mot-de-passe"})
    assert bad.status_code == 401
    ok = client.post("/api/v1/auth/change-password", headers=admin_headers,
                     json={"current_password": ADMIN["password"], "new_password": "nouveau-mot-de-passe"})
    assert ok.status_code == 204
    assert client.get("/api/v1/auth/me", headers=admin_headers).status_code == 200  # session courante conservée
    assert client.get("/api/v1/auth/me", headers=other).status_code == 401
    assert client.post("/api/v1/auth/login", json={"username": "admin", "password": "nouveau-mot-de-passe"}).status_code == 200


def test_last_active_admin_cannot_be_demoted_or_deactivated(client: TestClient, admin_headers: dict[str, str]) -> None:
    me = client.get("/api/v1/auth/me", headers=admin_headers).json()
    r = client.patch(f"/api/v1/users/{me['id']}", headers=admin_headers, json={"role": "lecture"})
    assert r.status_code == 422 and r.json()["code"] == "dernier_administrateur"
    r = client.patch(f"/api/v1/users/{me['id']}", headers=admin_headers, json={"is_active": False})
    assert r.status_code == 422


def test_admin_can_reset_another_users_password(client: TestClient, admin_headers: dict[str, str], make_user) -> None:  # type: ignore[no-untyped-def]
    make_user("ingenieur", "ing1")
    ing_id = next(u["id"] for u in client.get("/api/v1/users", headers=admin_headers).json() if u["username"] == "ing1")
    r = client.patch(f"/api/v1/users/{ing_id}", headers=admin_headers, json={"new_password": "reinitialise-2026"})
    assert r.status_code == 200
    assert client.post("/api/v1/auth/login", json={"username": "ing1", "password": DEFAULT_PASSWORD}).status_code == 401
    assert client.post("/api/v1/auth/login", json={"username": "ing1", "password": "reinitialise-2026"}).status_code == 200


def test_duplicate_username_is_rejected_case_insensitively(client: TestClient, admin_headers: dict[str, str]) -> None:
    r = client.post("/api/v1/users", headers=admin_headers,
                    json={"username": "ADMIN", "full_name": "Doublon", "role": "lecture", "password": DEFAULT_PASSWORD})
    assert r.status_code == 409
