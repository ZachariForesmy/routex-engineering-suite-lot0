"""Dépendances FastAPI : session de base, utilisateur courant, permissions."""

from __future__ import annotations

from collections.abc import Callable, Iterator
from typing import Annotated

from fastapi import Depends, Request
from sqlalchemy.orm import Session

from app.core.config import Settings
from app.core.errors import AuthenticationError, PermissionDeniedError
from app.core.permissions import Permission, has_permission
from app.services import auth_service
from app.services.actor import Actor


def get_settings(request: Request) -> Settings:
    return request.app.state.settings  # type: ignore[no-any-return]


def get_db(request: Request) -> Iterator[Session]:
    db: Session = request.app.state.sessionmaker()
    try:
        yield db
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


DbSession = Annotated[Session, Depends(get_db)]
AppSettings = Annotated[Settings, Depends(get_settings)]


def get_current_actor(request: Request, db: DbSession) -> Actor:
    scheme, _, token = request.headers.get("Authorization", "").partition(" ")
    if scheme.lower() != "bearer" or not token.strip():
        raise AuthenticationError(auth_service.SESSION_EXPIRED, code="session_absente")
    actor, _user = auth_service.resolve_token(db, token.strip())
    return actor


CurrentActor = Annotated[Actor, Depends(get_current_actor)]


def require(permission: Permission) -> Callable[[Actor], Actor]:
    def checker(actor: CurrentActor) -> Actor:
        if not has_permission(actor.role, permission):
            raise PermissionDeniedError(
                f"Votre rôle ({actor.role_label}) ne permet pas cette opération.", code="acces_refuse"
            )
        return actor

    return checker
