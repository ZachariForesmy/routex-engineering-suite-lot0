# Recette avant livraison — RouteX

À dérouler pour chaque version, sur un **Windows 10/11 propre** (machine
virtuelle neuve ou poste sans outil de développement). Cocher chaque ligne et
joindre le résultat aux notes de version.

## A. Construction (poste de build Windows)

- [ ] `scripts\build-windows.ps1` se termine sans erreur.
- [ ] Les tests automatisés passent (backend, interface).
- [ ] `verify_release.py` : tous les contrôles « OK ».
- [ ] Archive ZIP et fichier `.sha256` produits.

## B. Installation propre (poste de test)

- [ ] Copier l'archive, vérifier l'empreinte SHA-256.
- [ ] Extraire, lancer `RouteX.exe` : la console affiche l'adresse, le
      navigateur s'ouvre sur « Premier démarrage ».
- [ ] Le dossier `%LOCALAPPDATA%\RouteX\` est créé.

## C. Hors ligne (TX-013)

- [ ] Désactiver toutes les cartes réseau (ou mode avion), redémarrer le poste.
- [ ] Lancer RouteX : démarrage normal, interface complète (polices
      correctes, pas d'élément manquant).
- [ ] Créer le compte administrateur, un projet, exporter PDF et Excel.
- [ ] Ouvrir le PDF et le fichier Excel : contenu et accents corrects.

## D. Persistance et sauvegarde (TX-001, TX-002)

- [ ] Fermer la console, relancer : le projet est présent.
- [ ] Administration → Sauvegarder maintenant : message « intégrité vérifiée ».
- [ ] Restaurer cette sauvegarde selon `BACKUP_RESTORE.md` : données
      identiques.
- [ ] Couper l'application brutalement (Gestionnaire des tâches) pendant
      l'utilisation, relancer : aucune perte des opérations validées.

## E. Droits (TX-012)

- [ ] Créer un compte « Lecture seule » : il consulte et exporte, ne peut ni
      créer ni modifier (boutons absents ; refus de l'API vérifiés par les
      tests automatisés).

## F. Mise à jour (TX-014)

- [ ] Installer la version précédente, créer des données, puis installer la
      nouvelle version : données conservées, sauvegarde `avant-migration`
      présente si le schéma a changé.

## G. Publication

- [ ] `CHANGELOG.md` à jour, limites connues listées.
- [ ] Version qualifiée de « prototype » ou « version de développement » tant
      que les critères du §17 de la spécification ne sont pas tous remplis.
