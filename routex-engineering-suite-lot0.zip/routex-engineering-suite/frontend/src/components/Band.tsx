import type { ReactNode } from "react";

/** Bandeau de l'application : panneau bleu puis chaussée à marquage axial. */
export function Band({ children, version }: { children?: ReactNode; version?: string }) {
  return (
    <header>
      <div className="band">
        <div className="band__inner">
          <div className="band__brand">
            <span className="band__name">RouteX</span>
            <span className="band__suite">Engineering Suite</span>
          </div>
          {children}
        </div>
      </div>
      <div className="road" aria-hidden="true" />
      {version?.includes("dev") && (
        <div className="devflag">
          Version de développement {version} : à ne pas utiliser pour des études réelles sans validation.
        </div>
      )}
    </header>
  );
}
