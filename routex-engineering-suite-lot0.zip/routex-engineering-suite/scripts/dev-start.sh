#!/usr/bin/env bash
# Lance RouteX en mode développement (Linux/macOS) :
#   backend  http://127.0.0.1:8765 (rechargement automatique, /docs)
#   interface http://127.0.0.1:5173 (relaie /api vers le backend)
# Données de développement : .dev-data/ à la racine du dépôt.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PY="$ROOT/backend/.venv/bin/python"

if [[ ! -x "$PY" ]]; then
  python3 -m venv "$ROOT/backend/.venv"
  "$PY" -m pip install --quiet --upgrade pip
  "$PY" -m pip install --quiet -c "$ROOT/backend/requirements-lock.txt" -e "$ROOT/backend[dev]"
fi
[[ -d "$ROOT/frontend/node_modules" ]] || (cd "$ROOT/frontend" && npm ci --no-audit --no-fund)

export ROUTEX_DEV=1 ROUTEX_DATA_DIR="$ROOT/.dev-data"
(cd "$ROOT/backend" && exec "$PY" -m uvicorn app.main:create_app --factory \
   --host 127.0.0.1 --port 8765 --reload --reload-dir app) &
BACKEND_PID=$!
trap 'kill $BACKEND_PID 2>/dev/null || true' EXIT

cd "$ROOT/frontend" && npm run dev
