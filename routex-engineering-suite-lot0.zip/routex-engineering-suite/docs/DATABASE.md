# Base de données — RouteX

SQLite (mode WAL, `synchronous=FULL`, clés étrangères actives), SQLAlchemy 2,
migrations Alembic dans `backend/migrations/versions/`.

## Schéma — révision 0001 (Lot 0)

### `users`
| Colonne | Type | Notes |
|---|---|---|
| id | texte (UUID) | clé primaire |
| username | texte 64, NOCASE | unique, insensible à la casse |
| full_name | texte 120 | affiché sur les rapports |
| role | texte 20 | `admin`, `ingenieur`, `technicien`, `lecture` (contrainte CHECK) |
| password_hash | texte | Argon2id |
| is_active | booléen | les comptes sont désactivés, jamais supprimés |
| created_at, updated_at, last_login_at | horodatage UTC | |

### `user_sessions`
Jeton de session : seule l'empreinte SHA-256 (`token_hash`, unique) est
stockée. `expires_at`, `revoked_at`. Index sur `user_id`.

### `projects`
| Colonne | Type | Notes |
|---|---|---|
| id | texte (UUID) | clé primaire stable |
| code | texte 40, NOCASE | identifiant métier unique |
| name | texte 200 | intitulé |
| client, location, country | texte | maître d'ouvrage, localisation, pays |
| currency | texte 3 | ISO 4217 (CHECK longueur 3) |
| unit_system | texte | `SI` uniquement (CHECK) |
| description | texte | |
| start_date, end_date | date | CHECK fin ≥ début |
| status | texte | `actif` / `archive` (CHECK) |
| archived_at | horodatage UTC | |
| revision | entier ≥ 1 | incrémenté à chaque modification (D-013) |
| created_by, updated_by | FK `users.id` | RESTRICT |
| created_at, updated_at | horodatage UTC | |

Index : `status`, `name`.

### `audit_log`
Entier auto-incrémenté (ordre strict), `at` (UTC), `user_id` (FK, nullable
pour les échecs de connexion), `username` (copie au moment de l'opération),
`action`, `entity_type`, `entity_id`, `details` (JSON). Index sur `at` et
(`entity_type`, `entity_id`). Jamais modifié ni supprimé par l'application.

## Conventions

- Nommage des contraintes fixé (`pk_`, `fk_`, `uq_`, `ck_`, `ix_`) : requis pour
  les migrations « batch » de SQLite.
- Horodatages : UTC sans fuseau dans SQLite, restitués avec fuseau UTC par
  l'ORM (type `UTCDateTime`) ; un horodatage sans fuseau est refusé.
- Montants et quantités (à partir du Lot 2) : `Decimal` stocké en texte, voir
  D-011.

## Procédure de migration

1. Modifier les modèles (`backend/app/models/`).
2. Générer une révision :
   ```bash
   cd backend
   ROUTEX_DB_URL=sqlite:///./tmp-migration.sqlite3 .venv/bin/alembic upgrade head
   ROUTEX_DB_URL=sqlite:///./tmp-migration.sqlite3 .venv/bin/alembic revision --autogenerate --rev-id 0002 -m "description"
   ```
3. Relire la migration : remplacer tout type applicatif par un type
   SQLAlchemy standard, vérifier les valeurs par défaut des colonnes ajoutées
   à des tables non vides, écrire `downgrade()`.
4. `pytest` : `test_models_match_migrations` échoue si modèles et migrations
   divergent ; ajouter un test de migration sur une base contenant des données
   (modèle : `test_existing_database_is_backed_up_then_migrated_without_data_loss`).
5. Ne jamais modifier une migration publiée.

Au démarrage, l'application : sauvegarde la base si elle doit migrer, migre en
une transaction avec clés étrangères suspendues puis vérifiées
(`PRAGMA foreign_key_check`), et refuse de démarrer sur une base de révision
inconnue ou une base SQLite étrangère.
