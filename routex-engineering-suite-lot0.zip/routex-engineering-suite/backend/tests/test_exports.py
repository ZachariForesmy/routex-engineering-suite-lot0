"""TX-010 (PDF paginé), TX-011 (XLSX cohérent), CSV, traçabilité des exports."""

from __future__ import annotations

import csv
import hashlib
import io
import json
from datetime import date, datetime

from fastapi.testclient import TestClient
from openpyxl import load_workbook
from pypdf import PdfReader
from sqlalchemy import select

from app.models import AuditEntry


def _many_projects(create_project, n: int) -> None:  # type: ignore[no-untyped-def]
    for i in range(1, n + 1):
        create_project(code=f"P-{i:03d}", name=f"Aménagement du tronçon n°{i} — Pétion-Ville / Kenscoff",
                       start_date="2026-11-01", end_date="2027-06-30")


def test_tx010_projects_pdf_is_paginated(client: TestClient, admin_headers: dict[str, str], create_project) -> None:  # type: ignore[no-untyped-def]
    _many_projects(create_project, 60)
    r = client.get("/api/v1/reports/projects.pdf", headers=admin_headers)
    assert r.status_code == 200
    assert r.headers["content-type"] == "application/pdf"
    assert r.content.startswith(b"%PDF-")
    reader = PdfReader(io.BytesIO(r.content))
    pages = len(reader.pages)
    assert pages >= 2
    for index, page in enumerate(reader.pages, start=1):
        text = page.extract_text()
        assert f"Page {index} / {pages}" in text
        assert "RouteX Engineering Suite" in text
    first = reader.pages[0].extract_text()
    assert "Liste des projets" in first and "60 projet(s)" in first
    assert "Pétion-Ville" in first  # caractères accentués conservés (police embarquée)
    assert reader.metadata is not None and reader.metadata.title == "Liste des projets"


def test_pdf_embeds_its_fonts(client: TestClient, admin_headers: dict[str, str], create_project) -> None:  # type: ignore[no-untyped-def]
    create_project()
    content = client.get("/api/v1/reports/projects.pdf", headers=admin_headers).content
    fonts = set()
    for page in PdfReader(io.BytesIO(content)).pages:
        for font in page["/Resources"]["/Font"].values():
            obj = font.get_object()
            fonts.add(str(obj["/BaseFont"]))
            assert "/FontDescriptor" in obj and "/FontFile2" in obj["/FontDescriptor"], obj["/BaseFont"]
    assert all("DejaVuSans" in f for f in fonts)


def test_empty_list_pdf_has_explicit_message(client: TestClient, admin_headers: dict[str, str]) -> None:
    r = client.get("/api/v1/reports/projects.pdf", headers=admin_headers, params={"q": "rien"})
    text = PdfReader(io.BytesIO(r.content)).pages[0].extract_text()
    assert "Aucun projet ne correspond aux critères." in text
    assert "« rien »" in text


def test_tx011_projects_xlsx_has_typed_cells(client: TestClient, admin_headers: dict[str, str], create_project) -> None:  # type: ignore[no-untyped-def]
    create_project(code="A-1", start_date="2026-11-01", end_date="2027-06-30")
    create_project(code="B-2", start_date=None, end_date=None, name="Projet sans dates")
    r = client.get("/api/v1/reports/projects.xlsx", headers=admin_headers)
    assert r.status_code == 200
    wb = load_workbook(io.BytesIO(r.content))
    assert wb.sheetnames == ["Projets", "Informations"]
    ws = wb["Projets"]
    header = [c.value for c in ws[1]]
    assert header == ["Code", "Intitulé", "Maître d'ouvrage", "Localisation", "Pays", "Devise", "Début", "Fin", "Statut"]
    assert ws.max_row == 3
    assert ws.freeze_panes == "A2"
    assert ws.auto_filter.ref == "A1:I3"
    row = [c.value for c in ws[2]]
    assert row[0] == "A-1" and row[8] == "Actif"
    assert isinstance(row[6], (date, datetime)) and row[6].date() if isinstance(row[6], datetime) else True
    start = ws["G2"].value
    assert (start.date() if isinstance(start, datetime) else start) == date(2026, 11, 1)
    assert ws["G2"].number_format == "DD/MM/YYYY"
    assert ws["G3"].value is None
    info = {r[0].value: r[1].value for r in wb["Informations"].iter_rows()}
    assert info["Nombre de projets"] == "2"
    assert info["Filtre — Projets archivés"] == "exclus"


def test_csv_export_is_excel_friendly(client: TestClient, admin_headers: dict[str, str], create_project) -> None:  # type: ignore[no-untyped-def]
    create_project(code="C-1", name="Canal; « drainage »", start_date="2026-11-01")
    r = client.get("/api/v1/reports/projects.csv", headers=admin_headers)
    assert r.content.startswith(b"\xef\xbb\xbf")  # BOM UTF-8
    rows = list(csv.reader(io.StringIO(r.content.decode("utf-8-sig")), delimiter=";"))
    assert rows[0][0] == "Code"
    assert rows[1][:2] == ["C-1", "Canal; « drainage »"]  # séparateur protégé par guillemets
    assert rows[1][6] == "2026-11-01"


def test_project_sheet_exports(client: TestClient, admin_headers: dict[str, str], create_project) -> None:  # type: ignore[no-untyped-def]
    p = create_project(description="Ligne 1\nLigne 2 avec <balise> & esperluette")
    pdf = client.get(f"/api/v1/projects/{p['id']}/report.pdf", headers=admin_headers)
    assert pdf.status_code == 200
    assert "RouteX_fiche_RTX-2026-001_r1.pdf" in pdf.headers["content-disposition"]
    text = PdfReader(io.BytesIO(pdf.content)).pages[0].extract_text()
    assert "RTX-2026-001" in text and "<balise> & esperluette" in text and "Page 1 / 1" in text

    xlsx = client.get(f"/api/v1/projects/{p['id']}/report.xlsx", headers=admin_headers)
    ws = load_workbook(io.BytesIO(xlsx.content))["Fiche projet"]
    values = {r[0].value: r[1].value for r in ws.iter_rows(min_row=2)}
    assert values["Code"] == "RTX-2026-001"
    assert values["Devise"] == "HTG"
    start = values["Date de début"]
    assert (start.date() if isinstance(start, datetime) else start) == date(2026, 11, 1)


def test_exports_are_traced_with_checksum(client: TestClient, admin_headers: dict[str, str], create_project) -> None:  # type: ignore[no-untyped-def]
    p = create_project()
    r = client.get("/api/v1/reports/projects.xlsx", headers=admin_headers, params={"q": "RTX", "include_archived": True})
    r2 = client.get(f"/api/v1/projects/{p['id']}/report.pdf", headers=admin_headers)
    with client.app.state.sessionmaker() as db:  # type: ignore[attr-defined]
        entries = db.scalars(select(AuditEntry).where(AuditEntry.action.like("export.%")).order_by(AuditEntry.id)).all()
    assert [e.action for e in entries] == ["export.xlsx", "export.pdf"]
    list_details = json.loads(entries[0].details)
    assert list_details["filtres"] == {"q": "RTX", "include_archived": True}
    assert list_details["sha256"] == hashlib.sha256(r.content).hexdigest() == r.headers["x-routex-sha256"]
    sheet_details = json.loads(entries[1].details)
    assert sheet_details["revision"] == 1 and sheet_details["code"] == "RTX-2026-001"
    assert sheet_details["sha256"] == hashlib.sha256(r2.content).hexdigest()


def test_unsupported_format_is_rejected(client: TestClient, admin_headers: dict[str, str], create_project) -> None:  # type: ignore[no-untyped-def]
    p = create_project()
    assert client.get("/api/v1/reports/projects.docx", headers=admin_headers).status_code == 422
    assert client.get(f"/api/v1/projects/{p['id']}/report.csv", headers=admin_headers).status_code == 422
