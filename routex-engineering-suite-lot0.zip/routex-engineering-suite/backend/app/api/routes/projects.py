from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, Query, status

from app.api.deps import DbSession, require
from app.core.permissions import Permission
from app.schemas.project import ArchiveIn, ProjectCreateIn, ProjectListOut, ProjectOut, ProjectUpdateIn
from app.services import project_service
from app.services.actor import Actor

router = APIRouter(prefix="/projects", tags=["Projets"])
Reader = Annotated[Actor, Depends(require(Permission.PROJECT_READ))]
Writer = Annotated[Actor, Depends(require(Permission.PROJECT_WRITE))]
Archiver = Annotated[Actor, Depends(require(Permission.PROJECT_ARCHIVE))]


@router.get("", response_model=ProjectListOut, summary="Rechercher / lister les projets")
def list_projects(
    _actor: Reader,
    db: DbSession,
    q: Annotated[str, Query(max_length=200, description="Recherche dans code, intitulé, maître d'ouvrage, localisation")] = "",
    include_archived: Annotated[bool, Query(description="Inclure les projets archivés")] = False,
) -> ProjectListOut:
    items = project_service.list_projects(db, q=q, include_archived=include_archived)
    return ProjectListOut(items=items, total=len(items))


@router.post("", response_model=ProjectOut, status_code=status.HTTP_201_CREATED, summary="Créer un projet")
def create_project(payload: ProjectCreateIn, actor: Writer, db: DbSession) -> ProjectOut:
    return project_service.create_project(db, actor, payload)


@router.get("/{project_id}", response_model=ProjectOut, summary="Lire un projet")
def get_project(project_id: str, _actor: Reader, db: DbSession) -> ProjectOut:
    return project_service.get_project_out(db, project_id)


@router.patch("/{project_id}", response_model=ProjectOut,
              summary="Modifier un projet (409 si la révision fournie n'est plus la révision courante)")
def update_project(project_id: str, payload: ProjectUpdateIn, actor: Writer, db: DbSession) -> ProjectOut:
    return project_service.update_project(db, actor, project_id, payload)


@router.post("/{project_id}/archive", response_model=ProjectOut, summary="Archiver un projet (réversible)")
def archive_project(project_id: str, payload: ArchiveIn, actor: Archiver, db: DbSession) -> ProjectOut:
    return project_service.set_archived(db, actor, project_id, archived=True, revision=payload.revision)


@router.post("/{project_id}/unarchive", response_model=ProjectOut, summary="Désarchiver un projet")
def unarchive_project(project_id: str, payload: ArchiveIn, actor: Archiver, db: DbSession) -> ProjectOut:
    return project_service.set_archived(db, actor, project_id, archived=False, revision=payload.revision)
