from __future__ import annotations

from collections.abc import Callable, Iterator
from pathlib import Path
from typing import Any

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.core.config import Settings
from app.main import create_app

ADMIN = {"username": "admin", "full_name": "Admin Test", "password": "mot-de-passe-admin"}
DEFAULT_PASSWORD = "mot-de-passe-solide"


@pytest.fixture
def settings(tmp_path: Path) -> Settings:
    return Settings(data_dir=tmp_path / "routex-data", frontend_dist=None)


@pytest.fixture
def app(settings: Settings) -> Iterator[FastAPI]:
    application = create_app(settings)
    yield application
    application.state.engine.dispose()


@pytest.fixture
def client(app: FastAPI) -> Iterator[TestClient]:
    with TestClient(app, base_url="http://127.0.0.1") as c:
        yield c


def bearer(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture
def admin_headers(client: TestClient) -> dict[str, str]:
    r = client.post("/api/v1/auth/setup", json=ADMIN)
    assert r.status_code == 201, r.text
    return bearer(r.json()["token"])


@pytest.fixture
def make_user(client: TestClient, admin_headers: dict[str, str]) -> Callable[..., dict[str, str]]:
    """Crée un compte du rôle demandé et retourne ses en-têtes d'authentification."""

    def _make(role: str, username: str | None = None) -> dict[str, str]:
        username = username or f"user-{role}"
        r = client.post(
            "/api/v1/users", headers=admin_headers,
            json={"username": username, "full_name": f"Utilisateur {role}", "role": role, "password": DEFAULT_PASSWORD},
        )
        assert r.status_code == 201, r.text
        r = client.post("/api/v1/auth/login", json={"username": username, "password": DEFAULT_PASSWORD})
        assert r.status_code == 200, r.text
        return bearer(r.json()["token"])

    return _make


def project_payload(**overrides: Any) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "code": "RTX-2026-001",
        "name": "Réhabilitation de la route Delmas 33",
        "client": "Ministère des Travaux publics",
        "location": "Delmas",
        "country": "Haïti",
        "currency": "HTG",
        "description": "Chaussée, drainage longitudinal et éclairage.",
        "start_date": "2026-11-01",
        "end_date": "2027-06-30",
    }
    payload.update(overrides)
    return payload


@pytest.fixture
def create_project(client: TestClient, admin_headers: dict[str, str]) -> Callable[..., dict[str, Any]]:
    def _create(**overrides: Any) -> dict[str, Any]:
        r = client.post("/api/v1/projects", headers=admin_headers, json=project_payload(**overrides))
        assert r.status_code == 201, r.text
        return r.json()  # type: ignore[no-any-return]

    return _create
