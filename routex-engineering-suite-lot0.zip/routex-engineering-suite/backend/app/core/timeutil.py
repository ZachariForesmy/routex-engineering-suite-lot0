"""Convention de temps (D-006) : stockage en UTC, affichage en heure locale."""

from __future__ import annotations

from datetime import UTC, date, datetime


def utcnow() -> datetime:
    return datetime.now(UTC)


def to_local(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.astimezone()


def format_local_datetime(dt: datetime) -> str:
    """Ex. « 20/10/2026 à 18:50 (UTC−05:00) »."""
    local = to_local(dt)
    offset = local.strftime("%z")  # +HHMM
    sign = "−" if offset.startswith("-") else "+"
    return f"{local:%d/%m/%Y à %H:%M} (UTC{sign}{offset[1:3]}:{offset[3:5]})"


def format_date(d: date | None) -> str:
    return d.strftime("%d/%m/%Y") if d else ""
