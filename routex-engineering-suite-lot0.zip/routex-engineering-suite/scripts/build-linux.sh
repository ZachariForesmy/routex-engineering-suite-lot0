#!/usr/bin/env bash
# Construit et vérifie le paquet PyInstaller sous Linux. Sert à valider la
# recette de packaging (même spec que Windows) ; la cible de distribution reste
# Windows (scripts/build-windows.ps1).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VENV="$ROOT/backend/.venv-build"
PY="$VENV/bin/python"

[[ -x "$PY" ]] || python3 -m venv "$VENV"
"$PY" -m pip install --quiet --upgrade pip
"$PY" -m pip install --quiet -c "$ROOT/backend/requirements-lock.txt" -e "$ROOT/backend[dev,build]"

(cd "$ROOT/frontend" && npm ci --no-audit --no-fund && npm run build)

if [[ "${SKIP_TESTS:-0}" != "1" ]]; then
  (cd "$ROOT/backend" && "$PY" -m pytest -q -p no:cacheprovider)
  (cd "$ROOT/frontend" && npm test)
fi

(cd "$ROOT" && "$PY" -m PyInstaller packaging/routex.spec --noconfirm --clean \
   --distpath "$ROOT/dist" --workpath "$ROOT/build/pyinstaller")

"$PY" -I "$ROOT/scripts/verify_release.py" "$ROOT/dist/RouteX/RouteX"

VERSION="$("$PY" -c 'import app; print(app.__version__)')"
ARCHIVE="$ROOT/dist/RouteX-$VERSION-linux-x64.tar.gz"
tar -C "$ROOT/dist" -czf "$ARCHIVE" RouteX
(cd "$ROOT/dist" && sha256sum "$(basename "$ARCHIVE")" > "$(basename "$ARCHIVE").sha256")
echo "Paquet prêt : $ARCHIVE"
