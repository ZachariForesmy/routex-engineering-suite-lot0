import { useCallback, useEffect, useMemo, useState } from "react";
import { ApiError, download, request } from "../api";
import { ProjectDetail } from "../components/ProjectDetail";
import { ProjectForm } from "../components/ProjectForm";
import type { NoticeState } from "../components/Notice";
import { changedFields, draftFromProject, draftToPayload, emptyDraft, formatDate, statusLabel } from "../format";
import type { Me, Project, ProjectDraft } from "../types";
import { PERMISSIONS } from "../types";

interface Props {
  me: Me;
  defaults: { currency: string; country: string };
  notify: (notice: NoticeState) => void;
}

type Mode = "view" | "create" | "edit";

export function ProjectsView({ me, defaults, notify }: Props) {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  const [includeArchived, setIncludeArchived] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [mode, setMode] = useState<Mode>("view");
  const [busy, setBusy] = useState(false);

  const canWrite = me.permissions.includes(PERMISSIONS.projectWrite);
  const canArchive = me.permissions.includes(PERMISSIONS.projectArchive);

  useEffect(() => {
    const timer = setTimeout(() => setDebounced(query.trim()), 250);
    return () => clearTimeout(timer);
  }, [query]);

  const load = useCallback(async () => {
    try {
      const data = await request<{ items: Project[]; total: number }>("GET", "/projects", undefined, {
        q: debounced,
        include_archived: includeArchived,
      });
      setProjects(data.items);
    } catch (e) {
      notify({ kind: "error", text: e instanceof ApiError ? e.message : "Chargement des projets impossible." });
    } finally {
      setLoaded(true);
    }
  }, [debounced, includeArchived, notify]);

  useEffect(() => {
    void load();
  }, [load]);

  const selected = useMemo(() => projects.find((p) => p.id === selectedId) ?? null, [projects, selectedId]);

  function select(id: string) {
    setSelectedId(id);
    setMode("view");
  }

  async function create(draft: ProjectDraft) {
    const created = await request<Project>("POST", "/projects", draftToPayload(draft));
    notify({ kind: "ok", text: `Projet ${created.code} créé.` });
    setQuery("");
    setDebounced("");
    await load();
    setSelectedId(created.id);
    setMode("view");
  }

  async function update(draft: ProjectDraft) {
    if (!selected) return;
    const changes = changedFields(selected, draft);
    if (Object.keys(changes).length === 0) {
      setMode("view");
      return;
    }
    try {
      const updated = await request<Project>("PATCH", `/projects/${selected.id}`, { revision: selected.revision, ...changes });
      notify({ kind: "ok", text: `Projet ${updated.code} enregistré (révision ${updated.revision}).` });
      await load();
      setMode("view");
    } catch (e) {
      if (e instanceof ApiError && e.code === "revision_perimee") {
        notify({ kind: "error", text: `${e.message} Vos modifications n'ont pas été enregistrées ; la fiche à jour est affichée.` });
        await load();
        setMode("view");
        return;
      }
      throw e;
    }
  }

  async function toggleArchive() {
    if (!selected) return;
    const archiving = selected.status === "actif";
    const question = archiving
      ? `Archiver le projet ${selected.code} ? Il ne sera plus modifiable ni affiché par défaut, mais restera consultable. L'opération est réversible.`
      : `Désarchiver le projet ${selected.code} ?`;
    if (!window.confirm(question)) return;
    setBusy(true);
    try {
      const result = await request<Project>("POST", `/projects/${selected.id}/${archiving ? "archive" : "unarchive"}`, {
        revision: selected.revision,
      });
      notify({ kind: "ok", text: archiving ? `Projet ${result.code} archivé.` : `Projet ${result.code} désarchivé.` });
      if (archiving && !includeArchived) setSelectedId(null);
      await load();
    } catch (e) {
      notify({ kind: "error", text: e instanceof ApiError ? e.message : "Opération impossible." });
      await load();
    } finally {
      setBusy(false);
    }
  }

  async function exportFile(path: string, params?: Record<string, string | boolean>) {
    setBusy(true);
    try {
      const name = await download(path, params);
      notify({ kind: "ok", text: `Export enregistré : ${name}` });
    } catch (e) {
      notify({ kind: "error", text: e instanceof ApiError ? e.message : "Export impossible." });
    } finally {
      setBusy(false);
    }
  }

  const listParams = { q: debounced, include_archived: includeArchived };

  return (
    <main className="page">
      <div className="page__head">
        <h1>
          Projets
          {loaded && <span className="page__count">{projects.length}</span>}
        </h1>
        {canWrite && (
          <button className="btn btn--primary" type="button" onClick={() => setMode("create")}>
            Nouveau projet
          </button>
        )}
      </div>

      <div className="workspace">
        <section className="panel" aria-label="Registre des projets">
          <div className="toolbar">
            <div className="toolbar__search">
              <label className="small muted" htmlFor="project-search">
                Rechercher (code, intitulé, maître d'ouvrage, localisation)
              </label>
              <input id="project-search" type="search" value={query} onChange={(e) => setQuery(e.target.value)} />
            </div>
            <label className="check">
              <input type="checkbox" checked={includeArchived} onChange={(e) => setIncludeArchived(e.target.checked)} />
              Inclure les archivés
            </label>
            <div className="toolbar__group" role="group" aria-label="Exporter la liste affichée">
              <span className="small muted">Exporter la liste</span>
              <button className="btn btn--small" type="button" disabled={busy} onClick={() => exportFile("/reports/projects.pdf", listParams)}>
                PDF
              </button>
              <button className="btn btn--small" type="button" disabled={busy} onClick={() => exportFile("/reports/projects.xlsx", listParams)}>
                Excel
              </button>
              <button className="btn btn--small" type="button" disabled={busy} onClick={() => exportFile("/reports/projects.csv", listParams)}>
                CSV
              </button>
            </div>
          </div>

          {!loaded ? (
            <p className="loading">Chargement…</p>
          ) : projects.length === 0 ? (
            <div className="empty">
              {debounced || includeArchived ? (
                <p>Aucun projet ne correspond à cette recherche.</p>
              ) : canWrite ? (
                <>
                  <p>Aucun projet pour l'instant.</p>
                  <button className="btn btn--primary" type="button" onClick={() => setMode("create")}>
                    Créer le premier projet
                  </button>
                </>
              ) : (
                <p>Aucun projet. Un ingénieur ou un administrateur peut en créer.</p>
              )}
            </div>
          ) : (
            <div className="table-wrap">
              <table className="register">
                <thead>
                  <tr>
                    <th scope="col">Code</th>
                    <th scope="col">Intitulé</th>
                    <th scope="col">Maître d'ouvrage</th>
                    <th scope="col">Localisation</th>
                    <th scope="col">Début</th>
                    <th scope="col">Statut</th>
                  </tr>
                </thead>
                <tbody>
                  {projects.map((p) => (
                    <tr key={p.id} aria-selected={p.id === selectedId} onClick={() => select(p.id)}>
                      <td className="code">
                        <button className="btn btn--link" type="button" onClick={() => select(p.id)}>
                          {p.code}
                        </button>
                      </td>
                      <td>{p.name}</td>
                      <td>{p.client}</td>
                      <td>{[p.location, p.country].filter(Boolean).join(", ")}</td>
                      <td className="nowrap">{formatDate(p.start_date)}</td>
                      <td>
                        <span className={`status status--${p.status}`}>{statusLabel(p.status)}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <div>
          {mode === "create" ? (
            <ProjectForm
              key="create"
              title="Nouveau projet"
              submitLabel="Créer le projet"
              initial={emptyDraft(defaults.currency, defaults.country)}
              onSubmit={create}
              onCancel={() => setMode("view")}
            />
          ) : mode === "edit" && selected ? (
            <ProjectForm
              key={`edit-${selected.id}-${selected.revision}`}
              title={`Modifier ${selected.code}`}
              submitLabel="Enregistrer les modifications"
              initial={draftFromProject(selected)}
              onSubmit={update}
              onCancel={() => setMode("view")}
            />
          ) : selected ? (
            <ProjectDetail
              project={selected}
              canWrite={canWrite}
              canArchive={canArchive}
              busy={busy}
              onEdit={() => setMode("edit")}
              onToggleArchive={toggleArchive}
              onExport={(format) => exportFile(`/projects/${selected.id}/report.${format}`)}
            />
          ) : (
            projects.length > 0 && (
              <section className="panel">
                <div className="panel__body">
                  <p className="muted">Sélectionnez un projet dans le registre pour afficher sa fiche.</p>
                </div>
              </section>
            )
          )}
        </div>
      </div>
    </main>
  );
}
