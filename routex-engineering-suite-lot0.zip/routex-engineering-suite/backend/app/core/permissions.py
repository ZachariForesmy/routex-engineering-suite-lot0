"""Matrice unique des rôles et permissions (D-008).

Les droits sont vérifiés côté backend sur chaque route ; l'interface ne fait
que masquer les actions non autorisées pour le confort de l'utilisateur.
"""

from __future__ import annotations

from enum import StrEnum


class Role(StrEnum):
    ADMIN = "admin"
    INGENIEUR = "ingenieur"
    TECHNICIEN = "technicien"
    LECTURE = "lecture"


ROLE_LABELS: dict[Role, str] = {
    Role.ADMIN: "Administrateur",
    Role.INGENIEUR: "Ingénieur / Responsable",
    Role.TECHNICIEN: "Technicien / Métreur",
    Role.LECTURE: "Lecture seule",
}


class Permission(StrEnum):
    PROJECT_READ = "project.read"
    PROJECT_EXPORT = "project.export"
    PROJECT_WRITE = "project.write"
    PROJECT_ARCHIVE = "project.archive"
    USER_MANAGE = "user.manage"
    BACKUP_CREATE = "backup.create"
    AUDIT_READ = "audit.read"


_READ = {Permission.PROJECT_READ, Permission.PROJECT_EXPORT}

ROLE_PERMISSIONS: dict[Role, frozenset[Permission]] = {
    Role.ADMIN: frozenset(Permission),
    Role.INGENIEUR: frozenset(_READ | {Permission.PROJECT_WRITE, Permission.PROJECT_ARCHIVE}),
    Role.TECHNICIEN: frozenset(_READ),
    Role.LECTURE: frozenset(_READ),
}


def has_permission(role: str, permission: Permission) -> bool:
    try:
        return permission in ROLE_PERMISSIONS[Role(role)]
    except ValueError:
        return False


def permissions_for(role: str) -> list[str]:
    try:
        return sorted(p.value for p in ROLE_PERMISSIONS[Role(role)])
    except ValueError:
        return []
