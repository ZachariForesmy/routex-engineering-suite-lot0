"""Fabrique de l'application FastAPI.

Usage en développement :
    uvicorn app.main:create_app --factory --host 127.0.0.1 --port 8765
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from pathlib import Path

from fastapi import FastAPI, Request, Response
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware

from app import APP_NAME, __version__
from app.api.errors import install_error_handlers
from app.api.routes import admin, auth, projects, reports, system, users
from app.core.config import Settings
from app.core.logging import get_logger, setup_logging
from app.db.migrate import prepare_database
from app.db.session import make_engine, make_sessionmaker

API_PREFIX = "/api/v1"
CSP = (
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; "
    "font-src 'self'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; "
    "base-uri 'none'; form-action 'self'"
)
_DOCS_PATHS = ("/docs", "/redoc", "/openapi.json")

NOT_BUILT_PAGE = """<!doctype html><html lang="fr"><meta charset="utf-8">
<title>RouteX — interface non compilée</title>
<body>
<h1>RouteX : l'API fonctionne, mais l'interface n'est pas compilée</h1>
<p>Compilez l'interface : <code>cd frontend &amp;&amp; npm install &amp;&amp; npm run build</code>,
puis relancez l'application. En développement, utilisez plutôt <code>npm run dev</code>
(interface sur http://localhost:5173).</p>
<p>État de l'API : <a href="/api/v1/system/health">/api/v1/system/health</a></p>
</body></html>"""


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or Settings.from_env()
    settings.ensure_dirs()
    setup_logging(settings.logs_dir)
    log = get_logger()

    engine = make_engine(settings.db_path)
    report = prepare_database(engine, settings.db_path, settings.backups_dir)
    log.info("Base prête (%s, révision %s) — données : %s", settings.db_path.name, report.current_revision, settings.data_dir)

    app = FastAPI(
        title=f"{APP_NAME} — API locale",
        version=__version__,
        description="API locale de RouteX. Toutes les routes métier exigent un jeton de session (Bearer).",
        docs_url="/docs" if settings.dev_mode else None,
        redoc_url=None,
        openapi_url="/openapi.json" if settings.dev_mode else None,
    )
    app.state.settings = settings
    app.state.engine = engine
    app.state.sessionmaker = make_sessionmaker(engine)
    app.state.migration_report = report

    install_error_handlers(app)
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=list(settings.allowed_hosts))

    @app.middleware("http")
    async def security_headers(request: Request, call_next: Callable[[Request], Awaitable[Response]]) -> Response:
        response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "no-referrer")
        if not (settings.dev_mode and request.url.path.startswith(_DOCS_PATHS)):
            response.headers.setdefault("Content-Security-Policy", CSP)
        if request.url.path.startswith(API_PREFIX):
            response.headers.setdefault("Cache-Control", "no-store")
        return response

    for module in (system, auth, users, projects, reports, admin):
        app.include_router(module.router, prefix=API_PREFIX)

    @app.api_route(API_PREFIX + "/{rest:path}", methods=["GET", "POST", "PATCH", "PUT", "DELETE"], include_in_schema=False)
    def api_not_found(rest: str) -> JSONResponse:
        return JSONResponse(status_code=404, content={"detail": "Route d'API inconnue.", "code": "http_404", "errors": []})

    _mount_frontend(app, settings.frontend_dist)
    return app


def _mount_frontend(app: FastAPI, dist: Path | None) -> None:
    if dist is not None and (dist / "index.html").is_file():
        app.mount("/", StaticFiles(directory=dist, html=True), name="frontend")
        return

    @app.get("/", include_in_schema=False)
    def frontend_missing() -> HTMLResponse:
        return HTMLResponse(NOT_BUILT_PAGE)
