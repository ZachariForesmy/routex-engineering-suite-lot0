"""Journal d'audit. Les entrées sont ajoutées à la session de l'opération
journalisée : elles sont validées ou annulées avec elle."""

from __future__ import annotations

import json
from datetime import date, datetime
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models import AuditEntry
from app.services.actor import Actor


def _default(value: Any) -> str:
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    return str(value)


def record(
    db: Session,
    actor: Actor | None,
    action: str,
    *,
    entity_type: str = "",
    entity_id: str = "",
    details: dict[str, Any] | None = None,
    username: str | None = None,
) -> AuditEntry:
    entry = AuditEntry(
        user_id=actor.id if actor else None,
        username=(actor.username if actor else (username or ""))[:64],
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        details=json.dumps(details or {}, ensure_ascii=False, default=_default, sort_keys=True),
    )
    db.add(entry)
    return entry


def list_entries(db: Session, limit: int, offset: int) -> tuple[list[AuditEntry], int]:
    total = db.scalar(select(func.count(AuditEntry.id))) or 0
    rows = db.scalars(
        select(AuditEntry).order_by(AuditEntry.id.desc()).limit(limit).offset(offset)
    ).all()
    return list(rows), total


def parse_details(entry: AuditEntry) -> dict[str, Any]:
    try:
        value = json.loads(entry.details or "{}")
    except json.JSONDecodeError:
        return {"brut": entry.details}
    return value if isinstance(value, dict) else {"valeur": value}
