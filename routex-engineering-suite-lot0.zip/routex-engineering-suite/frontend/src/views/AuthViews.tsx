import { useState, type FormEvent } from "react";
import { ApiError, request } from "../api";
import type { SessionInfo } from "../types";

interface Props {
  onSession: (session: SessionInfo) => void;
  message?: string | null;
}

const MIN_PASSWORD = 10;

export function SetupView({ onSession }: Props) {
  const [username, setUsername] = useState("admin");
  const [fullName, setFullName] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (password.length < MIN_PASSWORD) return setError(`Le mot de passe doit compter au moins ${MIN_PASSWORD} caractères.`);
    if (password !== confirm) return setError("Les deux mots de passe saisis diffèrent.");
    setBusy(true);
    setError(null);
    try {
      onSession(await request<SessionInfo>("POST", "/auth/setup", { username, full_name: fullName, password }));
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Création du compte impossible.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="auth">
      <div className="panel">
        <div className="panel__body">
          <h1>Premier démarrage</h1>
          <p className="muted">
            Créez le compte administrateur de ce poste. Il pourra ensuite ouvrir des comptes pour les ingénieurs,
            techniciens et lecteurs.
          </p>
          <form onSubmit={submit} className="stack" noValidate>
            <div className="field">
              <label htmlFor="setup-user">Identifiant</label>
              <input id="setup-user" type="text" autoComplete="username" value={username} onChange={(e) => setUsername(e.target.value)} required />
              <span className="hint">Lettres, chiffres, point, tiret ou soulignement.</span>
            </div>
            <div className="field">
              <label htmlFor="setup-name">Nom complet</label>
              <input id="setup-name" type="text" autoComplete="name" value={fullName} onChange={(e) => setFullName(e.target.value)} required />
              <span className="hint">Apparaît sur les rapports et dans le journal.</span>
            </div>
            <div className="field">
              <label htmlFor="setup-pwd">Mot de passe</label>
              <input id="setup-pwd" type="password" autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
              <span className="hint">{MIN_PASSWORD} caractères minimum.</span>
            </div>
            <div className="field">
              <label htmlFor="setup-pwd2">Confirmer le mot de passe</label>
              <input id="setup-pwd2" type="password" autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} required />
            </div>
            {error && <p className="field error" role="alert">{error}</p>}
            <button className="btn btn--primary" type="submit" disabled={busy}>
              {busy ? "Création…" : "Créer le compte administrateur"}
            </button>
          </form>
        </div>
      </div>
    </main>
  );
}

export function LoginView({ onSession, message }: Props) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      onSession(await request<SessionInfo>("POST", "/auth/login", { username, password }));
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Connexion impossible.");
      setPassword("");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="auth">
      <div className="panel">
        <div className="panel__body">
          <h1>Connexion</h1>
          {message ? <p className="muted">{message}</p> : <p className="muted">Identifiez-vous pour accéder aux projets.</p>}
          <form onSubmit={submit} className="stack" noValidate>
            <div className="field">
              <label htmlFor="login-user">Identifiant</label>
              <input id="login-user" type="text" autoComplete="username" autoFocus value={username} onChange={(e) => setUsername(e.target.value)} />
            </div>
            <div className="field">
              <label htmlFor="login-pwd">Mot de passe</label>
              <input id="login-pwd" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} />
            </div>
            {error && <p className="field error" role="alert">{error}</p>}
            <button className="btn btn--primary" type="submit" disabled={busy || !username || !password}>
              {busy ? "Connexion…" : "Se connecter"}
            </button>
            <p className="small muted">
              Mot de passe oublié : demandez à un administrateur de le réinitialiser depuis l'écran Utilisateurs.
            </p>
          </form>
        </div>
      </div>
    </main>
  );
}
