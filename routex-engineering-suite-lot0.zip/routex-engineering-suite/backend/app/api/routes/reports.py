"""Exports PDF / XLSX / CSV. Chaque export est tracé dans le journal d'audit
(format, filtres, révision, empreinte SHA-256, taille) — D-012."""

from __future__ import annotations

from typing import Annotated, Literal
from urllib.parse import quote

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response

from app.api.deps import DbSession, require
from app.core.permissions import Permission
from app.core.timeutil import utcnow
from app.exports import csv_reports, pdf_reports, xlsx_reports
from app.exports.common import RenderedReport, ReportMeta, describe_list_filters
from app.services import audit_service, project_service
from app.services.actor import Actor

router = APIRouter(tags=["Rapports et exports"])
Exporter = Annotated[Actor, Depends(require(Permission.PROJECT_EXPORT))]

_LIST_RENDERERS = {"pdf": pdf_reports.render_projects_list, "xlsx": xlsx_reports.render_projects_list,
                   "csv": csv_reports.render_projects_list}
_SHEET_RENDERERS = {"pdf": pdf_reports.render_project_sheet, "xlsx": xlsx_reports.render_project_sheet}


def _download(report: RenderedReport) -> Response:
    ascii_name = report.file_name.encode("ascii", "replace").decode().replace("?", "_")
    return Response(
        content=report.content,
        media_type=report.media_type,
        headers={
            "Content-Disposition": f"attachment; filename=\"{ascii_name}\"; filename*=UTF-8''{quote(report.file_name)}",
            "Cache-Control": "no-store",
            "X-RouteX-SHA256": report.sha256,
        },
    )


def _author(actor: Actor) -> str:
    return f"{actor.full_name} ({actor.username})"


@router.get("/reports/projects.{fmt}", summary="Exporter la liste des projets (pdf, xlsx ou csv)")
def export_projects_list(
    fmt: Literal["pdf", "xlsx", "csv"],
    actor: Exporter,
    db: DbSession,
    q: Annotated[str, Query(max_length=200)] = "",
    include_archived: bool = False,
) -> Response:
    projects = project_service.list_projects(db, q=q, include_archived=include_archived)
    meta = ReportMeta(title="Liste des projets", generated_at=utcnow(), author=_author(actor),
                      filters=describe_list_filters(q, include_archived))
    report = _LIST_RENDERERS[fmt](projects, meta)
    audit_service.record(
        db, actor, f"export.{fmt}", entity_type="report", entity_id="projects_list",
        details={"rapport": "liste_projets", "filtres": {"q": q, "include_archived": include_archived},
                 "nb_projets": len(projects), "fichier": report.file_name,
                 "sha256": report.sha256, "taille_octets": report.size_bytes},
    )
    db.commit()
    return _download(report)


@router.get("/projects/{project_id}/report.{fmt}", summary="Exporter la fiche d'un projet (pdf ou xlsx)")
def export_project_sheet(project_id: str, fmt: Literal["pdf", "xlsx"], actor: Exporter, db: DbSession) -> Response:
    project = project_service.get_project_out(db, project_id)
    meta = ReportMeta(title="Fiche projet", generated_at=utcnow(), author=_author(actor))
    report = _SHEET_RENDERERS[fmt](project, meta)
    audit_service.record(
        db, actor, f"export.{fmt}", entity_type="project", entity_id=project.id,
        details={"rapport": "fiche_projet", "code": project.code, "revision": project.revision,
                 "fichier": report.file_name, "sha256": report.sha256, "taille_octets": report.size_bytes},
    )
    db.commit()
    return _download(report)
