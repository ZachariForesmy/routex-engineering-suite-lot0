"""Hachage des mots de passe (Argon2id) et jetons de session (D-007)."""

from __future__ import annotations

import hashlib
import secrets

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError

MIN_PASSWORD_LENGTH = 10

_hasher = PasswordHasher()
# Hachage factice pour garder un temps de réponse constant lorsque
# l'identifiant n'existe pas (évite l'énumération des comptes).
_DUMMY_HASH = _hasher.hash("routex-dummy-password-for-timing")


def hash_password(password: str) -> str:
    return _hasher.hash(password)


def verify_password(password_hash: str | None, password: str) -> bool:
    try:
        return _hasher.verify(password_hash or _DUMMY_HASH, password) and password_hash is not None
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False


def needs_rehash(password_hash: str) -> bool:
    return _hasher.check_needs_rehash(password_hash)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def new_session_token() -> tuple[str, str]:
    """Retourne (jeton remis au client, empreinte stockée en base)."""
    token = secrets.token_urlsafe(32)
    return token, hash_token(token)
