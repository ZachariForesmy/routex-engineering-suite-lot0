import { useState, type FormEvent } from "react";
import { ApiError, request } from "../api";
import type { NoticeState } from "../components/Notice";
import { formatDateTime } from "../format";
import type { Me } from "../types";

export function AccountView({ me, notify }: { me: Me; notify: (notice: NoticeState) => void }) {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (next !== confirm) return setError("Les deux saisies du nouveau mot de passe diffèrent.");
    setBusy(true);
    setError(null);
    try {
      await request<void>("POST", "/auth/change-password", { current_password: current, new_password: next });
      setCurrent("");
      setNext("");
      setConfirm("");
      notify({ kind: "ok", text: "Mot de passe changé. Vos autres sessions ont été fermées." });
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Changement impossible.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="page">
      <div className="page__head">
        <h1>Mon compte</h1>
      </div>
      <div className="workspace">
        <section className="panel">
          <div className="panel__body">
            <dl className="facts">
              <div className="facts-row">
                <dt>Identifiant</dt>
                <dd>{me.username}</dd>
              </div>
              <div className="facts-row">
                <dt>Nom complet</dt>
                <dd>{me.full_name}</dd>
              </div>
              <div className="facts-row">
                <dt>Rôle</dt>
                <dd>{me.role_label}</dd>
              </div>
              <div className="facts-row">
                <dt>Connexion</dt>
                <dd>{formatDateTime(me.last_login_at)}</dd>
              </div>
            </dl>
          </div>
        </section>
        <form className="panel" onSubmit={submit} noValidate>
          <div className="panel__head">
            <h2>Changer de mot de passe</h2>
          </div>
          <div className="panel__body stack">
            <div className="field">
              <label htmlFor="acc-current">Mot de passe actuel</label>
              <input id="acc-current" type="password" autoComplete="current-password" value={current} onChange={(e) => setCurrent(e.target.value)} />
            </div>
            <div className="field">
              <label htmlFor="acc-next">Nouveau mot de passe</label>
              <input id="acc-next" type="password" autoComplete="new-password" value={next} onChange={(e) => setNext(e.target.value)} />
              <span className="hint">10 caractères minimum.</span>
            </div>
            <div className="field">
              <label htmlFor="acc-confirm">Confirmer le nouveau mot de passe</label>
              <input id="acc-confirm" type="password" autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
            </div>
            {error && <p className="field error" role="alert">{error}</p>}
            <div className="form-actions">
              <button className="btn btn--primary" type="submit" disabled={busy || !current || !next}>
                Changer le mot de passe
              </button>
            </div>
          </div>
        </form>
      </div>
    </main>
  );
}
