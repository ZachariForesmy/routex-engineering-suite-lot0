"""Gestion des comptes (administrateur). Les comptes ne sont jamais supprimés
(D-014) : ils sont désactivés."""

from __future__ import annotations

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.errors import BusinessRuleError, ConflictError, NotFoundError
from app.core.permissions import Role
from app.core.security import hash_password
from app.models import User
from app.schemas.user import UserCreateIn, UserUpdateIn
from app.services import audit_service
from app.services.actor import Actor
from app.services.auth_service import revoke_user_sessions


def list_users(db: Session) -> list[User]:
    return list(db.scalars(select(User).order_by(User.is_active.desc(), User.username)).all())


def _get(db: Session, user_id: str) -> User:
    user = db.get(User, user_id)
    if user is None:
        raise NotFoundError("Utilisateur introuvable.")
    return user


def _username_taken(db: Session, username: str, exclude_id: str | None = None) -> bool:
    stmt = select(User.id).where(User.username == username)
    if exclude_id:
        stmt = stmt.where(User.id != exclude_id)
    return db.scalar(stmt) is not None


def create_user(db: Session, actor: Actor, data: UserCreateIn) -> User:
    if _username_taken(db, data.username):
        raise ConflictError(f"L'identifiant « {data.username} » est déjà utilisé.", code="identifiant_existant")
    user = User(
        username=data.username,
        full_name=data.full_name,
        role=data.role.value,
        password_hash=hash_password(data.password),
    )
    db.add(user)
    db.flush()
    audit_service.record(
        db, actor, "user.create", entity_type="user", entity_id=user.id,
        details={"identifiant": user.username, "role": user.role},
    )
    db.commit()
    return user


def _other_active_admins(db: Session, user_id: str) -> int:
    return db.scalar(
        select(func.count(User.id)).where(User.role == Role.ADMIN.value, User.is_active.is_(True), User.id != user_id)
    ) or 0


def update_user(db: Session, actor: Actor, user_id: str, data: UserUpdateIn) -> User:
    user = _get(db, user_id)
    changes: dict[str, object] = {}

    loses_admin = user.role == Role.ADMIN.value and user.is_active and (
        (data.role is not None and data.role != Role.ADMIN) or data.is_active is False
    )
    if loses_admin and _other_active_admins(db, user.id) == 0:
        raise BusinessRuleError(
            "Impossible : ce compte est le dernier administrateur actif. Nommez d'abord un autre administrateur.",
            code="dernier_administrateur",
        )
    if data.is_active is False and user.id == actor.id:
        raise BusinessRuleError("Vous ne pouvez pas désactiver votre propre compte.", code="auto_desactivation")

    if data.full_name is not None and data.full_name != user.full_name:
        changes["nom_complet"] = [user.full_name, data.full_name]
        user.full_name = data.full_name
    if data.role is not None and data.role.value != user.role:
        changes["role"] = [user.role, data.role.value]
        user.role = data.role.value
    if data.is_active is not None and data.is_active != user.is_active:
        changes["actif"] = [user.is_active, data.is_active]
        user.is_active = data.is_active
        if not data.is_active:
            revoke_user_sessions(db, user.id)
    if data.new_password is not None:
        user.password_hash = hash_password(data.new_password)
        revoke_user_sessions(db, user.id, except_session=actor.session_id if user.id == actor.id else None)
        changes["mot_de_passe"] = "réinitialisé"

    if changes:
        audit_service.record(db, actor, "user.update", entity_type="user", entity_id=user.id, details=changes)
        db.commit()
    return user
