# Sauvegarde et restauration — RouteX

## Sauvegarder

Trois moyens, qui produisent le même type de fichier dans
`%LOCALAPPDATA%\RouteX\backups\` :

| Moyen | Nom du fichier |
|---|---|
| Interface : **Administration → Sauvegarder maintenant** (administrateur) | `routex_AAAAMMJJ-HHMMSS_manuelle.sqlite3` |
| Ligne de commande : `RouteX.exe backup` | `routex_…_console.sqlite3` |
| Automatique, avant toute migration de schéma | `routex_…_avant-migration-<révision>.sqlite3` |

La copie est faite à chaud par l'API de sauvegarde de SQLite (cohérente même
pendant l'utilisation), puis contrôlée par `PRAGMA integrity_check` avant
d'être conservée. Une copie défectueuse est supprimée et l'erreur signalée.

**Recommandation :** copier régulièrement le dossier `backups\` sur un support
externe (clé USB, disque) ; une sauvegarde sur le même disque ne protège pas
d'une panne du disque.

Limite actuelle : les sauvegardes ne contiennent que la base. Le dossier
`documents\` (pièces jointes, à partir du Lot 1) devra être inclus.

## Restaurer (procédure manuelle, Lot 0)

L'écran de restauration est prévu au Lot 1. En attendant :

1. Fermer RouteX (fermer la fenêtre console).
2. Mettre de côté la base actuelle : renommer
   `%LOCALAPPDATA%\RouteX\data\routex.sqlite3` en
   `routex.sqlite3.avant-restauration`, et supprimer `routex.sqlite3-wal` et
   `routex.sqlite3-shm` s'ils existent.
3. Copier le fichier de sauvegarde choisi dans `data\` et le renommer
   `routex.sqlite3`.
4. Lancer RouteX. Si la sauvegarde provient d'une version plus ancienne, elle
   est migrée automatiquement (avec une nouvelle sauvegarde préalable).
5. Se connecter et vérifier les projets. En cas de problème, refaire
   l'étape 3 avec `routex.sqlite3.avant-restauration`.

Les comptes et mots de passe sont ceux de la date de la sauvegarde.

## Récupération après panne

- **Arrêt brutal (coupure de courant)** : SQLite en mode WAL avec
  `synchronous=FULL` garantit que les transactions validées sont conservées ;
  au redémarrage, le journal WAL est rejoué automatiquement.
- **RouteX refuse de démarrer** : lire le message dans la console et
  `logs\routex.log`. Messages possibles :
  - *révision inconnue* : la base a été ouverte par une version plus récente
    de RouteX ; utiliser cette version ou restaurer une sauvegarde ;
  - *base non créée par RouteX* : le fichier `routex.sqlite3` n'est pas une
    base RouteX ; restaurer une sauvegarde.
- **Base endommagée** : restaurer la sauvegarde la plus récente (ci-dessus).

## Vérification

`backend/tests/test_backup.py` vérifie qu'une sauvegarde faite pendant
l'utilisation, copiée dans un emplacement isolé, démarre une instance
complète avec toutes les données.
