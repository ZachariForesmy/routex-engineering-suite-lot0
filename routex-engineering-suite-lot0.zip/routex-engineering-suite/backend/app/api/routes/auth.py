from __future__ import annotations

from fastapi import APIRouter, status

from app import APP_NAME, __version__
from app.api.deps import AppSettings, CurrentActor, DbSession
from app.core.errors import NotFoundError
from app.models import User
from app.schemas.auth import AuthStatusOut, ChangePasswordIn, LoginIn, SessionOut, SetupIn
from app.schemas.user import MeOut
from app.services import auth_service

router = APIRouter(prefix="/auth", tags=["Authentification"])


@router.get("/status", response_model=AuthStatusOut, summary="Premier lancement ? (sans authentification)")
def auth_status(db: DbSession, settings: AppSettings) -> AuthStatusOut:
    return AuthStatusOut(
        app_name=APP_NAME, version=__version__, setup_required=auth_service.setup_required(db),
        default_currency=settings.default_currency, default_country=settings.default_country,
    )


@router.post("/setup", response_model=SessionOut, status_code=status.HTTP_201_CREATED,
             summary="Créer le premier compte administrateur (uniquement si aucun compte n'existe)")
def setup(payload: SetupIn, db: DbSession, settings: AppSettings) -> SessionOut:
    token, expires_at, user = auth_service.setup_first_admin(
        db, username=payload.username, full_name=payload.full_name, password=payload.password,
        session_hours=settings.session_hours,
    )
    return SessionOut(token=token, expires_at=expires_at, user=MeOut.model_validate(user))


@router.post("/login", response_model=SessionOut, summary="Ouvrir une session")
def login(payload: LoginIn, db: DbSession, settings: AppSettings) -> SessionOut:
    token, expires_at, user = auth_service.login(
        db, username=payload.username, password=payload.password, session_hours=settings.session_hours
    )
    return SessionOut(token=token, expires_at=expires_at, user=MeOut.model_validate(user))


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT, summary="Fermer la session courante")
def logout(actor: CurrentActor, db: DbSession) -> None:
    auth_service.logout(db, actor)


@router.get("/me", response_model=MeOut, summary="Utilisateur connecté et ses permissions")
def me(actor: CurrentActor, db: DbSession) -> MeOut:
    user = db.get(User, actor.id)
    if user is None:
        raise NotFoundError("Utilisateur introuvable.")
    return MeOut.model_validate(user)


@router.post("/change-password", status_code=status.HTTP_204_NO_CONTENT,
             summary="Changer son mot de passe (révoque les autres sessions)")
def change_password(payload: ChangePasswordIn, actor: CurrentActor, db: DbSession) -> None:
    auth_service.change_password(
        db, actor, current_password=payload.current_password, new_password=payload.new_password
    )
