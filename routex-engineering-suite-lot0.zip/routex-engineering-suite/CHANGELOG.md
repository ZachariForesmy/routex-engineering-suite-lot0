# Journal des versions

## 0.1.0.dev0 — 20/10/2026 — Lot 0 (version de développement)

Premier socle exécutable. Non destiné à des études réelles.

### Ajouté
- Application locale : serveur FastAPI sur 127.0.0.1 servant l'API et
  l'interface React ; lanceur qui prépare la base et ouvre le navigateur.
- Base SQLite (WAL) avec migration Alembic initiale ; sauvegarde automatique
  avant migration ; refus des bases inconnues.
- Premier compte administrateur, connexion, 4 rôles contrôlés côté serveur,
  gestion des comptes, changement et réinitialisation de mot de passe.
- Projets : création, recherche, modification avec contrôle de révision,
  archivage réversible.
- Exports : liste des projets (PDF, XLSX, CSV), fiche projet (PDF, XLSX) ;
  tracés dans le journal d'audit avec empreinte SHA-256.
- Journal d'audit ; sauvegarde vérifiée depuis l'interface et en ligne de
  commande.
- Recette PyInstaller, scripts de build/vérification Windows et Linux.
- 71 tests backend, 13 tests interface, 1 parcours navigateur complet.

### Limites connues
Voir README, section « Limites connues ». En particulier : paquet Windows non
encore construit ni testé sur Windows.
