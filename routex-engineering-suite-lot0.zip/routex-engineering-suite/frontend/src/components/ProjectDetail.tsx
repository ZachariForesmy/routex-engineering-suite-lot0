import { formatDate, formatDateTime, statusLabel } from "../format";
import type { Project } from "../types";

interface Props {
  project: Project;
  canWrite: boolean;
  canArchive: boolean;
  busy: boolean;
  onEdit: () => void;
  onToggleArchive: () => void;
  onExport: (format: "pdf" | "xlsx") => void;
}

export function ProjectDetail({ project, canWrite, canArchive, busy, onEdit, onToggleArchive, onExport }: Props) {
  const archived = project.status === "archive";
  const facts: [string, string][] = [
    ["Maître d'ouvrage", project.client || "Non renseigné"],
    ["Localisation", [project.location, project.country].filter(Boolean).join(", ") || "Non renseignée"],
    ["Devise", project.currency],
    ["Unités", "Système international"],
    ["Début", formatDate(project.start_date) || "Non fixé"],
    ["Fin", formatDate(project.end_date) || "Non fixée"],
    ["Statut", statusLabel(project.status)],
    ["Révision", String(project.revision)],
    ["Créé", `${formatDateTime(project.created_at)}, ${project.created_by_name}`],
    ["Modifié", `${formatDateTime(project.updated_at)}, ${project.updated_by_name}`],
  ];

  return (
    <section className="panel" aria-labelledby="sheet-title">
      <div className="panel__head">
        <p className="sheet__code">{project.code}</p>
        <h2 className="sheet__title" id="sheet-title">
          {project.name}
        </h2>
      </div>
      <div className="panel__body stack">
        {archived && (
          <p className="archived-note small">
            Projet archivé le {formatDateTime(project.archived_at)}. Il reste consultable et exportable ; désarchivez-le
            pour le modifier.
          </p>
        )}
        <dl className="facts">
          {facts.map(([label, value]) => (
            <div key={label} className="facts-row">
              <dt>{label}</dt>
              <dd>{value}</dd>
            </div>
          ))}
        </dl>
        <div>
          <h3>Description</h3>
          <p className="description">{project.description || <span className="muted">Aucune description.</span>}</p>
        </div>
        <div className="actions-row">
          {canWrite && !archived && (
            <button className="btn btn--primary" type="button" onClick={onEdit} disabled={busy}>
              Modifier
            </button>
          )}
          <button className="btn" type="button" onClick={() => onExport("pdf")} disabled={busy}>
            Fiche PDF
          </button>
          <button className="btn" type="button" onClick={() => onExport("xlsx")} disabled={busy}>
            Fiche Excel
          </button>
          {canArchive && (
            <button className={`btn${archived ? "" : " btn--danger"}`} type="button" onClick={onToggleArchive} disabled={busy}>
              {archived ? "Désarchiver" : "Archiver"}
            </button>
          )}
        </div>
      </div>
    </section>
  );
}
