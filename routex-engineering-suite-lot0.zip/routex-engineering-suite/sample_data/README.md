# Données d'exemple

Vide au Lot 0. Ce dossier accueillera des jeux de données **de démonstration**
(fichiers de points topographiques, bordereaux d'exemple, DXF de test) à partir
des Lots 2 et 6.

Règles :
- chaque fichier est explicitement identifié comme données de démonstration ;
- aucune donnée de projet réel sans l'accord écrit de son propriétaire ;
- un fichier servant de cas de référence d'ingénierie indique sa source, ses
  unités, la tolérance et l'état de validation (« provisoire — à valider »
  tant qu'un ingénieur ne l'a pas approuvé).
