from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel

from app.schemas.common import OutModel


class BackupOut(BaseModel):
    file_name: str
    size_bytes: int
    created_at: datetime
    sha256: str | None = None
    integrity: str | None = None


class AuditEntryOut(OutModel):
    id: int
    at: datetime
    username: str
    action: str
    entity_type: str
    entity_id: str
    details: dict[str, Any]


class AuditPageOut(BaseModel):
    items: list[AuditEntryOut]
    total: int
    limit: int
    offset: int
