export interface NoticeState {
  kind: "ok" | "error";
  text: string;
}

export function Notice({ notice, onClose }: { notice: NoticeState | null; onClose: () => void }) {
  if (!notice) return null;
  return (
    <div className={`notice notice--${notice.kind}`} role={notice.kind === "error" ? "alert" : "status"}>
      <span>{notice.text}</span>
      <button type="button" onClick={onClose}>
        Fermer
      </button>
    </div>
  );
}
