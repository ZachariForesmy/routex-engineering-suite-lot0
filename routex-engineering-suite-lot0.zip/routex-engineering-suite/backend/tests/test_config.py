from __future__ import annotations

from pathlib import Path

import pytest

from app.core import config
from app.core.config import ConfigError, Settings


def test_windows_data_dir_uses_localappdata(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setattr(config.sys, "platform", "win32")
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "Local"))
    assert config.default_data_dir() == tmp_path / "Local" / "RouteX"


def test_linux_data_dir_uses_xdg(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setattr(config.sys, "platform", "linux")
    monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path / "xdg"))
    assert config.default_data_dir() == tmp_path / "xdg" / "RouteX"


def test_env_overrides(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("ROUTEX_DATA_DIR", str(tmp_path / "custom"))
    monkeypatch.setenv("ROUTEX_PORT", "9123")
    monkeypatch.setenv("ROUTEX_DEFAULT_CURRENCY", "usd")
    monkeypatch.setenv("ROUTEX_DEV", "1")
    s = Settings.from_env()
    assert s.data_dir == (tmp_path / "custom").resolve()
    assert s.port == 9123
    assert s.default_currency == "USD"
    assert s.dev_mode is True
    assert s.db_path == s.data_dir / "data" / "routex.sqlite3"


@pytest.mark.parametrize("value", ["abc", "80", "70000"])
def test_invalid_port_is_rejected_with_french_message(monkeypatch: pytest.MonkeyPatch, value: str) -> None:
    monkeypatch.setenv("ROUTEX_PORT", value)
    with pytest.raises(ConfigError, match="ROUTEX_PORT"):
        Settings.from_env()


def test_server_cannot_listen_on_network_interface(tmp_path: Path) -> None:
    with pytest.raises(ConfigError, match="interface locale"):
        Settings(data_dir=tmp_path, host="0.0.0.0")


def test_invalid_default_currency(tmp_path: Path) -> None:
    with pytest.raises(ConfigError):
        Settings(data_dir=tmp_path, default_currency="Gourde")
