# Plan de test — RouteX

## 1. Niveaux de test

| Niveau | Outil | Emplacement | Commande |
|---|---|---|---|
| Unitaires et intégration API + base | pytest | `backend/tests/` | `cd backend && .venv/bin/python -m pytest -q` |
| Migrations | pytest + Alembic | `backend/tests/test_migrations.py` | idem |
| Interface (logique) | Vitest | `frontend/tests/` | `cd frontend && npm test` |
| Typage et compilation | TypeScript 7, Vite | `frontend/` | `npm run build` |
| Parcours navigateur | Playwright (Chromium) | `e2e/` | `cd backend && .venv/bin/python -m pytest ../e2e -q` |
| Paquet produit | `scripts/verify_release.py` | — | `python scripts/verify_release.py dist/RouteX/RouteX[.exe]` |
| Poste Windows propre | recette manuelle | `RELEASE_CHECKLIST.md` | — |

Chaque test backend tourne sur une base SQLite neuve, créée **par les vraies
migrations** dans un dossier temporaire (pas de `create_all`), via l'API HTTP
réelle (TestClient). Aucun test ne dépend d'Internet.

## 2. Résultats — 20/10/2026, Lot 0

Environnement : Linux x86_64, Python 3.13.16, Node 22.22.0.

| Suite | Résultat |
|---|---|
| Backend pytest | **71 réussis**, 0 échec (≈ 21 s) |
| Interface Vitest | **13 réussis**, 0 échec |
| TypeScript + build Vite | sans erreur |
| Parcours Playwright | **1 parcours complet réussi**, 0 erreur console (donc aucune violation CSP) |
| `build-linux.sh` depuis un environnement vierge | réussi : installation, tests, PyInstaller, vérification |
| `verify_release.py` sur le paquet Linux | **12/12 contrôles** réussis |
| Idem, processus isolé sans réseau (boucle locale seule) | **12/12 contrôles** réussis |
| Scripts PowerShell | analyse syntaxique OK (PowerShell 7.5.4) ; **non exécutés sous Windows** |
| Paquet Windows | **non construit, non testé** |

Anomalies trouvées et corrigées pendant la vérification :
- PDF : colonnes de dates trop étroites (dates coupées sur deux lignes) ;
  police Helvetica référencée sans être embarquée.
- Lanceur : après un arrêt, le port en `TIME_WAIT` était pris pour un port
  occupé et l'application redémarrait sur un autre port (détecté par
  `verify_release.py`, test de redémarrage).
- Interface : débordement horizontal de la page sur écran étroit.

## 3. Matrice d'acceptation (§12)

État : ✅ couvert par un test automatisé qui passe · 🟡 partiel ·
⬜ lot ultérieur · 🔲 vérification manuelle à faire.

| Réf. | Exigence | État | Preuve |
|---|---|---|---|
| TX-001 | Création, fermeture, réouverture d'un projet sans perte | ✅ | `test_projects.py::test_tx001_project_survives_close_and_reopen` ; `verify_release.py` (paquet, arrêt/redémarrage du processus) |
| TX-002 | Sauvegarde et restauration d'une base de test | 🟡 | Sauvegarde : `test_backup.py` (copie à chaud, intégrité, démarrage d'une instance sur la copie isolée). Restauration en place par l'interface : Lot 1 ; procédure manuelle dans `BACKUP_RESTORE.md` |
| TX-003 | Conversion d'unités avec cas de référence | ⬜ | Lot 2 |
| TX-004 | Montant de poste et total général | ⬜ | Lot 3 |
| TX-005 | Historique des prix | ⬜ | Lot 3 |
| TX-006 | Attachement avec quantités cumulées | ⬜ | Lot 4 |
| TX-007 | Détection d'un cycle dans le planning | ⬜ | Lot 5 |
| TX-008 | Import de points, rejet documenté | ⬜ | Lot 6 |
| TX-009 | Export DXF et réouverture | ⬜ | Lot 6 |
| TX-010 | PDF avec pagination correcte | ✅ | `test_exports.py::test_tx010_projects_pdf_is_paginated` (60 projets, « Page X / N » sur chaque page), `test_pdf_embeds_its_fonts` |
| TX-011 | XLSX : nombres, unités, totaux cohérents | 🟡 | `test_tx011_projects_xlsx_has_typed_cells` (vraies dates, en-têtes, filtre, feuille d'informations). Nombres, unités et totaux : sans objet tant qu'il n'y a pas de quantités (Lot 2/3) |
| TX-012 | Contrôle des droits sur les opérations sensibles | ✅ | `test_permissions.py` (4 rôles × lecture, export, écriture, administration), `test_auth.py` ; parcours Playwright (technicien) |
| TX-013 | Fonctionnement réseau désactivé | 🟡 | Linux : paquet vérifié dans un espace réseau isolé (12/12). Windows : 🔲 `RELEASE_CHECKLIST.md` §C |
| TX-014 | Migration d'une base existante | ✅ | `test_migrations.py::test_existing_database_is_backed_up_then_migrated_without_data_loss` (révision supplémentaire réelle, sauvegarde préalable, données intactes, clés étrangères vérifiées) |
| TX-015 | Cubature vs cas de référence validé | ⬜ | Lot 7 — cas de référence à fournir et valider par un ingénieur |
| TX-016 | Hydraulique vs cas de référence validé | ⬜ | Lot 8 — idem |
| TX-017 | Aucune modification silencieuse d'un document source à l'import | ⬜ | Lot 6 |
| TX-018 | Avertissement si un calcul dépend de données modifiées | ⬜ | Lot 2 |

Tests complémentaires du Lot 0 (hors matrice) : cohérence modèles ↔
migrations, refus d'une base de version inconnue ou étrangère, contrôle de
révision (409), validation en français, unicité insensible à la casse,
échappement des jokers de recherche, en-têtes de sécurité, refus d'un en-tête
`Host` étranger, docs désactivées en production, lanceur (port, sauvegarde,
réinitialisation de mot de passe), détection d'une sauvegarde corrompue.

## 4. Cas de référence d'ingénierie

Aucun calcul d'ingénierie n'existe au Lot 0. Pour chaque fonction à venir,
un cas de référence comportera : données d'entrée, unités, méthode, résultat
attendu, tolérance, source ou nom de l'ingénieur validant, version du moteur.
Tant qu'il n'est pas approuvé, il est marqué **« provisoire — à valider »** et
la fonction n'est pas activée dans l'interface. Aucune valeur de référence ne
sera inventée.
