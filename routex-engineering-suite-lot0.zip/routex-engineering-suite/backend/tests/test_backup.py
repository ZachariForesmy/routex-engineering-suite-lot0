"""Sauvegarde à chaud (D-015). La restauration depuis l'interface est prévue
au Lot 1 ; ici on vérifie qu'une copie restaurée dans un emplacement isolé est
complète et exploitable (partie « sauvegarde » de TX-002)."""

from __future__ import annotations

import shutil
import sqlite3
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.core.config import Settings
from app.main import create_app
from app.services.backup_service import BackupError, check_integrity, create_backup, list_backups
from tests.conftest import ADMIN, bearer


def test_hot_backup_is_complete_and_restorable_in_isolation(
    client: TestClient, admin_headers: dict[str, str], create_project, settings: Settings, tmp_path: Path  # type: ignore[no-untyped-def]
) -> None:
    for i in range(5):
        create_project(code=f"SAV-{i}")
    r = client.post("/api/v1/admin/backup", headers=admin_headers)
    assert r.status_code == 201
    body = r.json()
    assert body["integrity"] == "ok"
    backup_file = settings.backups_dir / body["file_name"]
    assert backup_file.exists()
    assert not Path(str(backup_file) + "-wal").exists()  # copie autonome

    # Restauration dans un emplacement isolé, puis démarrage d'une instance dessus
    isolated = Settings(data_dir=tmp_path / "restauration", frontend_dist=None)
    isolated.ensure_dirs()
    shutil.copy2(backup_file, isolated.db_path)
    restored_app = create_app(isolated)
    with TestClient(restored_app, base_url="http://127.0.0.1") as c:
        token = c.post("/api/v1/auth/login", json={"username": ADMIN["username"], "password": ADMIN["password"]}).json()["token"]
        codes = [p["code"] for p in c.get("/api/v1/projects", headers=bearer(token)).json()["items"]]
    restored_app.state.engine.dispose()
    assert codes == [f"SAV-{i}" for i in range(5)]

    listed = client.get("/api/v1/admin/backups", headers=admin_headers).json()
    assert [b["file_name"] for b in listed] == [body["file_name"]]


def test_backup_of_missing_database_fails_cleanly(tmp_path: Path) -> None:
    with pytest.raises(BackupError, match="introuvable"):
        create_backup(tmp_path / "absente.sqlite3", tmp_path / "backups")


def test_corrupted_file_fails_integrity_check(tmp_path: Path) -> None:
    db = tmp_path / "base.sqlite3"
    conn = sqlite3.connect(db)
    conn.execute("CREATE TABLE t (x TEXT)")
    conn.executemany("INSERT INTO t VALUES (?)", [("x" * 500,)] * 200)
    conn.commit()
    conn.close()
    assert check_integrity(db) == "ok"
    data = bytearray(db.read_bytes())
    data[4096: 4096 + 12] = b"\xff" * 12  # en-tête de la 2e page b-tree détruit
    db.write_bytes(bytes(data))
    assert check_integrity(db) != "ok"


def test_backup_names_do_not_collide(tmp_path: Path) -> None:
    db = tmp_path / "base.sqlite3"
    sqlite3.connect(db).close()
    first = create_backup(db, tmp_path / "b", label="test")
    second = create_backup(db, tmp_path / "b", label="test")
    assert first.path != second.path
    assert len(list_backups(tmp_path / "b")) == 2
