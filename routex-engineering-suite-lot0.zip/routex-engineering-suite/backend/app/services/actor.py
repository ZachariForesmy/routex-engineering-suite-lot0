from __future__ import annotations

from dataclasses import dataclass

from app.core.permissions import ROLE_LABELS, Role


@dataclass(frozen=True)
class Actor:
    """Utilisateur authentifié à l'origine d'une opération."""

    id: str
    username: str
    full_name: str
    role: str
    session_id: str | None = None

    @property
    def role_label(self) -> str:
        try:
            return ROLE_LABELS[Role(self.role)]
        except ValueError:
            return self.role
