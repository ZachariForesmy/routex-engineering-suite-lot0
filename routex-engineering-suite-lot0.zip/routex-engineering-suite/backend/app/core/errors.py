"""Erreurs applicatives avec message utilisateur en français."""

from __future__ import annotations


class AppError(Exception):
    status_code = 400
    code = "erreur"

    def __init__(self, message: str, *, code: str | None = None) -> None:
        super().__init__(message)
        self.message = message
        if code:
            self.code = code


class NotFoundError(AppError):
    status_code = 404
    code = "introuvable"


class ConflictError(AppError):
    status_code = 409
    code = "conflit"


class AuthenticationError(AppError):
    status_code = 401
    code = "non_authentifie"


class PermissionDeniedError(AppError):
    status_code = 403
    code = "acces_refuse"


class BusinessRuleError(AppError):
    status_code = 422
    code = "regle_metier"


class DatabaseStateError(RuntimeError):
    """La base ne peut pas être ouverte sans risque (version inconnue, etc.)."""
