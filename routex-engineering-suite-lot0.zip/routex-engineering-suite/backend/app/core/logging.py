"""Journalisation technique (fichier tournant + console)."""

from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

LOGGER_NAME = "routex"
_FORMAT = "%(asctime)s %(levelname)-7s %(name)s — %(message)s"
_OWNED = "_routex_owned"


def setup_logging(logs_dir: Path, level: int = logging.INFO) -> logging.Logger:
    """Configure le logger ``routex``. Idempotent : les gestionnaires posés par
    un appel précédent sont remplacés (utile pour les tests)."""
    logger = logging.getLogger(LOGGER_NAME)
    logger.setLevel(level)
    for handler in list(logger.handlers):
        if getattr(handler, _OWNED, False):
            logger.removeHandler(handler)
            handler.close()

    logs_dir.mkdir(parents=True, exist_ok=True)
    file_handler = RotatingFileHandler(
        logs_dir / "routex.log", maxBytes=1_000_000, backupCount=5, encoding="utf-8"
    )
    stream_handler = logging.StreamHandler()
    for handler in (file_handler, stream_handler):
        handler.setFormatter(logging.Formatter(_FORMAT))
        setattr(handler, _OWNED, True)
        logger.addHandler(handler)
    logger.propagate = False
    return logger


def get_logger(name: str | None = None) -> logging.Logger:
    return logging.getLogger(f"{LOGGER_NAME}.{name}" if name else LOGGER_NAME)
