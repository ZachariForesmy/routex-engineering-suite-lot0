# API locale — RouteX (Lot 0)

Préfixe : `/api/v1`. Authentification : en-tête `Authorization: Bearer <jeton>`
obtenu par `/auth/setup` ou `/auth/login`. Spécification complète (générée,
hors ligne) : [`openapi.json`](openapi.json) — régénérer avec
`python backend/tools/export_openapi.py`. En mode développement
(`ROUTEX_DEV=1`), la documentation interactive est servie sur `/docs`.

## Routes

| Méthode | Route | Permission | Objet |
|---|---|---|---|
| GET | `/system/health` | publique | État de l'application |
| GET | `/auth/status` | publique | Premier lancement ? Devise et pays par défaut |
| POST | `/auth/setup` | publique, une seule fois | Premier compte administrateur |
| POST | `/auth/login` | publique | Ouvrir une session |
| POST | `/auth/logout` | connecté | Fermer la session |
| GET | `/auth/me` | connecté | Compte et permissions |
| POST | `/auth/change-password` | connecté | Changer son mot de passe |
| GET | `/users` | `user.manage` | Liste des comptes |
| POST | `/users` | `user.manage` | Créer un compte |
| PATCH | `/users/{id}` | `user.manage` | Rôle, activation, nouveau mot de passe |
| GET | `/projects?q=&include_archived=` | `project.read` | Recherche |
| POST | `/projects` | `project.write` | Créer |
| GET | `/projects/{id}` | `project.read` | Lire |
| PATCH | `/projects/{id}` | `project.write` | Modifier (champ `revision` obligatoire) |
| POST | `/projects/{id}/archive` | `project.archive` | Archiver (`{"revision": n}`) |
| POST | `/projects/{id}/unarchive` | `project.archive` | Désarchiver |
| GET | `/reports/projects.{pdf\|xlsx\|csv}?q=&include_archived=` | `project.export` | Liste des projets |
| GET | `/projects/{id}/report.{pdf\|xlsx}` | `project.export` | Fiche projet |
| POST | `/admin/backup` | `backup.create` | Sauvegarde vérifiée |
| GET | `/admin/backups` | `backup.create` | Sauvegardes existantes |
| GET | `/admin/audit-log?limit=&offset=` | `audit.read` | Journal d'audit |

Matrice rôles → permissions : [DECISIONS.md, D-008](DECISIONS.md).

Écart avec le §10 de la spécification : les exports utilisent `GET` avec le
format dans l'URL (téléchargement direct) au lieu de `POST /reports/pdf`.

## Codes de retour

| Code | Signification | `code` typiques |
|---|---|---|
| 400 | En-tête `Host` refusé | — |
| 401 | Session absente, expirée, révoquée ; identifiants invalides | `session_absente`, `session_invalide`, `identifiants_invalides`, `compte_desactive` |
| 403 | Rôle insuffisant | `acces_refuse` |
| 404 | Ressource ou route inconnue | `introuvable`, `http_404` |
| 409 | Conflit : code projet ou identifiant déjà pris, révision périmée, application déjà configurée | `code_existant`, `revision_perimee`, `deja_configure` |
| 422 | Données invalides ou règle métier | `donnees_invalides`, `dates_incoherentes`, `projet_archive`, `dernier_administrateur` |
| 500 | Erreur inattendue (détail dans `logs/routex.log`) | `erreur_interne` |

Format : `{"detail": "...", "code": "...", "errors": [{"field": "...", "message": "..."}]}`.

## Exports

Réponse en téléchargement (`Content-Disposition: attachment`), en-tête
`X-RouteX-SHA256` égal à l'empreinte enregistrée dans le journal d'audit.
