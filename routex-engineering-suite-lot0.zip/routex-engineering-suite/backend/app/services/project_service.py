"""Projets : création, recherche, modification avec contrôle de révision,
archivage réversible (D-013, D-014)."""

from __future__ import annotations

from datetime import date
from typing import Any

from sqlalchemy import or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, aliased

from app.core.errors import BusinessRuleError, ConflictError, NotFoundError
from app.core.timeutil import utcnow
from app.models import Project, User
from app.schemas.project import ProjectCreateIn, ProjectOut, ProjectUpdateIn
from app.services import audit_service
from app.services.actor import Actor

EDITABLE_FIELDS = (
    "code", "name", "client", "location", "country", "currency", "unit_system", "description",
    "start_date", "end_date",
)


def _escape_like(term: str) -> str:
    return term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def _with_names(db: Session, stmt: Any) -> list[ProjectOut]:
    creator, updater = aliased(User), aliased(User)
    rows = db.execute(
        stmt.add_columns(creator.full_name, updater.full_name)
        .join(creator, creator.id == Project.created_by)
        .join(updater, updater.id == Project.updated_by)
    ).all()
    result = []
    for project, created_name, updated_name in rows:
        out = ProjectOut.model_validate(project)
        out.created_by_name = created_name
        out.updated_by_name = updated_name
        result.append(out)
    return result


def list_projects(db: Session, *, q: str = "", include_archived: bool = False) -> list[ProjectOut]:
    stmt = select(Project)
    if not include_archived:
        stmt = stmt.where(Project.status == "actif")
    term = q.strip()
    if term:
        pattern = f"%{_escape_like(term)}%"
        stmt = stmt.where(
            or_(*(col.ilike(pattern, escape="\\") for col in (Project.code, Project.name, Project.client, Project.location)))
        )
    stmt = stmt.order_by(Project.status, Project.code)
    return _with_names(db, stmt)


def get_project(db: Session, project_id: str) -> Project:
    project = db.get(Project, project_id)
    if project is None:
        raise NotFoundError("Projet introuvable.")
    return project


def get_project_out(db: Session, project_id: str) -> ProjectOut:
    get_project(db, project_id)
    return _with_names(db, select(Project).where(Project.id == project_id))[0]


def _ensure_code_free(db: Session, code: str, exclude_id: str | None = None) -> None:
    stmt = select(Project.id).where(Project.code == code)
    if exclude_id:
        stmt = stmt.where(Project.id != exclude_id)
    if db.scalar(stmt) is not None:
        raise ConflictError(f"Le code projet « {code} » est déjà utilisé.", code="code_existant")


def _commit(db: Session) -> None:
    try:
        db.commit()
    except IntegrityError as exc:  # filet de sécurité (contrainte d'unicité, etc.)
        db.rollback()
        raise ConflictError("L'enregistrement viole une contrainte de la base (doublon ?).", code="contrainte") from exc


def create_project(db: Session, actor: Actor, data: ProjectCreateIn) -> ProjectOut:
    _ensure_code_free(db, data.code)
    now = utcnow()
    project = Project(
        **data.model_dump(), status="actif", revision=1,
        created_by=actor.id, updated_by=actor.id, created_at=now, updated_at=now,
    )
    db.add(project)
    db.flush()
    audit_service.record(
        db, actor, "project.create", entity_type="project", entity_id=project.id,
        details={"code": project.code, "intitule": project.name},
    )
    _commit(db)
    return get_project_out(db, project.id)


def _check_revision(project: Project, revision: int) -> None:
    if project.revision != revision:
        raise ConflictError(
            f"Le projet a été modifié entre-temps (révision actuelle {project.revision}, "
            f"vous avez lu la révision {revision}). Rechargez la fiche avant de modifier.",
            code="revision_perimee",
        )


def update_project(db: Session, actor: Actor, project_id: str, data: ProjectUpdateIn) -> ProjectOut:
    project = get_project(db, project_id)
    _check_revision(project, data.revision)
    if project.status == "archive":
        raise BusinessRuleError("Un projet archivé ne peut pas être modifié. Désarchivez-le d'abord.", code="projet_archive")

    requested = {f: getattr(data, f) for f in EDITABLE_FIELDS if f in data.model_fields_set}
    changes = {f: [getattr(project, f), v] for f, v in requested.items() if getattr(project, f) != v}
    if not changes:
        return get_project_out(db, project.id)

    start: date | None = requested.get("start_date", project.start_date)
    end: date | None = requested.get("end_date", project.end_date)
    if start and end and end < start:
        raise BusinessRuleError("La date de fin doit être postérieure ou égale à la date de début.", code="dates_incoherentes")
    if "code" in changes:
        _ensure_code_free(db, requested["code"], exclude_id=project.id)

    for field, (_old, new) in changes.items():
        setattr(project, field, new)
    project.revision += 1
    project.updated_by = actor.id
    project.updated_at = utcnow()
    audit_service.record(
        db, actor, "project.update", entity_type="project", entity_id=project.id,
        details={"code": project.code, "revision": project.revision, "modifications": changes},
    )
    _commit(db)
    return get_project_out(db, project.id)


def set_archived(db: Session, actor: Actor, project_id: str, *, archived: bool, revision: int) -> ProjectOut:
    project = get_project(db, project_id)
    _check_revision(project, revision)
    target = "archive" if archived else "actif"
    if project.status == target:
        raise BusinessRuleError(
            "Ce projet est déjà archivé." if archived else "Ce projet est déjà actif.", code="statut_inchange"
        )
    now = utcnow()
    project.status = target
    project.archived_at = now if archived else None
    project.revision += 1
    project.updated_by = actor.id
    project.updated_at = now
    audit_service.record(
        db, actor, "project.archive" if archived else "project.unarchive",
        entity_type="project", entity_id=project.id, details={"code": project.code, "revision": project.revision},
    )
    _commit(db)
    return get_project_out(db, project.id)
