"""Exporte la spécification OpenAPI hors ligne (D-009) : docs/openapi.json.

    python tools/export_openapi.py
"""

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app.core.config import Settings  # noqa: E402
from app.main import create_app  # noqa: E402


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        app = create_app(Settings(data_dir=Path(tmp), frontend_dist=None, dev_mode=True))
        spec = app.openapi()
        app.state.engine.dispose()
    target = ROOT.parent / "docs" / "openapi.json"
    target.write_text(json.dumps(spec, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"{target} — {len(spec['paths'])} routes")


if __name__ == "__main__":
    main()
