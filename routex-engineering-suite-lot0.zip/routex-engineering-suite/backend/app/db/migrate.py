"""Préparation de la base au démarrage : sauvegarde puis migration (D-004)."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from alembic import command
from alembic.config import Config
from alembic.runtime.migration import MigrationContext
from alembic.script import ScriptDirectory
from alembic.util import CommandError
from sqlalchemy import Engine, inspect

from app.core.errors import DatabaseStateError
from app.core.logging import get_logger
from app.core.resources import migrations_dir
from app.services.backup_service import create_backup

log = get_logger("db")


@dataclass(frozen=True)
class MigrationReport:
    previous_revision: str | None
    current_revision: str
    migrated: bool
    backup_path: Path | None


def alembic_config() -> Config:
    cfg = Config()
    cfg.set_main_option("script_location", str(migrations_dir()))
    return cfg


def head_revision() -> str:
    head = ScriptDirectory.from_config(alembic_config()).get_current_head()
    if head is None:
        raise DatabaseStateError("Aucune migration trouvée : paquet incomplet.")
    return head


def current_revision(engine: Engine) -> str | None:
    with engine.connect() as conn:
        return MigrationContext.configure(conn).get_current_revision()


def prepare_database(engine: Engine, db_path: Path, backups_dir: Path) -> MigrationReport:
    cfg = alembic_config()
    script = ScriptDirectory.from_config(cfg)
    head = head_revision()
    previous = current_revision(engine)

    if previous is None:
        tables = set(inspect(engine).get_table_names())
        if tables:
            raise DatabaseStateError(
                f"La base {db_path} contient des tables mais aucune version RouteX. "
                "Elle n'a pas été créée par RouteX : démarrage interrompu pour ne pas l'altérer."
            )
    else:
        try:
            script.get_revision(previous)
        except CommandError as exc:
            raise DatabaseStateError(
                f"La base est à la révision {previous!r}, inconnue de cette version de RouteX "
                "(base créée par une version plus récente ?). Démarrage interrompu."
            ) from exc

    if previous == head:
        return MigrationReport(previous, head, migrated=False, backup_path=None)

    backup_path: Path | None = None
    if previous is not None:
        info = create_backup(db_path, backups_dir, label=f"avant-migration-{previous}")
        backup_path = info.path
        log.info("Sauvegarde avant migration : %s", backup_path)

    log.info("Migration de la base : %s → %s", previous or "(vide)", head)
    _upgrade_to_head(engine, cfg)
    return MigrationReport(previous, head, migrated=True, backup_path=backup_path)


def _upgrade_to_head(engine: Engine, cfg: Config) -> None:
    """Migration transactionnelle. Les clés étrangères sont suspendues pendant
    la migration (les migrations « batch » recréent des tables), puis
    vérifiées : toute violation annule le démarrage."""
    with engine.connect() as conn:
        raw = conn.connection.driver_connection
        assert raw is not None
        raw.execute("PRAGMA foreign_keys=OFF")
        try:
            cfg.attributes["connection"] = conn
            command.upgrade(cfg, "head")
            if conn.in_transaction():
                conn.commit()
            violations = raw.execute("PRAGMA foreign_key_check").fetchall()
            if violations:
                raise DatabaseStateError(
                    f"La migration a laissé {len(violations)} référence(s) invalide(s). "
                    "Restaurez la sauvegarde faite avant migration."
                )
        except Exception:
            if conn.in_transaction():
                conn.rollback()
            raise
        finally:
            raw.execute("PRAGMA foreign_keys=ON")
