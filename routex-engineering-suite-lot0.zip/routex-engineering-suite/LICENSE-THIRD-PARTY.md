# Composants tiers — RouteX 0.1.0.dev0

Relevé au 20/10/2026 à partir des métadonnées des paquets installés. À
revérifier à chaque changement de version (décision : aucune dépendance
ajoutée sans contrôle de licence, de maintenance et de compatibilité).

## Embarqués dans l'application distribuée

| Composant | Version | Licence | Usage |
|---|---|---|---|
| FastAPI | 0.156.4 | MIT | API locale |
| Starlette | 1.9.0 | BSD-3-Clause | socle HTTP de FastAPI |
| Uvicorn | 0.54.0 | BSD-3-Clause | serveur HTTP local |
| h11 | 0.16.0 | MIT | protocole HTTP/1.1 |
| AnyIO | 4.15.1 | MIT | asynchrone |
| Click | 8.5.0 | BSD-3-Clause | dépendance d'Uvicorn |
| idna | 3.20 | BSD-3-Clause | dépendance d'AnyIO |
| SQLAlchemy | 2.1.5 | MIT | accès base |
| Alembic | 1.20.0 | MIT | migrations |
| Mako / MarkupSafe | 1.4.3 / 3.0.4 | MIT / BSD-3-Clause | dépendances d'Alembic |
| Pydantic / pydantic-core | 2.14.1 / 2.50.1 | MIT | validation |
| annotated-types, typing-inspection | 0.8.0, 0.4.4 | MIT | dépendances de Pydantic |
| typing-extensions | 4.16.0 | PSF-2.0 | dépendance commune |
| argon2-cffi / argon2-cffi-bindings | 25.1.0 / 26.1.0 | MIT | hachage des mots de passe |
| cffi | 2.1.1 | MIT-0 | dépendance d'argon2 |
| ReportLab (édition open source) | 5.0.1 | BSD | rapports PDF |
| Pillow | 13.0.0 | MIT-CMU | dépendance de ReportLab |
| charset-normalizer | 3.5.2 | MIT | dépendance de ReportLab |
| openpyxl / et-xmlfile | 3.1.5 / 2.0.0 | MIT | classeurs XLSX |
| DejaVu Sans (police, rapports PDF) | 2.37 | Bitstream Vera + domaine public | texte des PDF ; licence : `backend/app/resources/fonts/LICENSE-DejaVu.txt` |
| React / React DOM | 19.3.1 | MIT | interface |
| Barlow, Barlow Semi Condensed (polices, interface) | @fontsource 5.3.0 | SIL OFL 1.1 | texte de l'interface ; licences livrées avec l'interface (`frontend/public/licences/`, servies sous `/licences/`) |
| Python (interpréteur embarqué par PyInstaller) | 3.12+ | PSF-2.0 | exécution |

## Outils de construction et de test (non distribués)

| Composant | Licence | Remarque |
|---|---|---|
| PyInstaller 6.22.3 | GPL-2.0-or-later avec exception | l'exception autorise la distribution d'applications non libres ; le bootloader embarqué relève de cette exception |
| Vite 8, @vitejs/plugin-react 6, Vitest 5 | MIT | |
| TypeScript 7 | Apache-2.0 | |
| pytest 9, httpx2, pypdf 6 | MIT / BSD-3-Clause / BSD-3-Clause | |
| Playwright 1.56 | Apache-2.0 | tests de parcours navigateur |
