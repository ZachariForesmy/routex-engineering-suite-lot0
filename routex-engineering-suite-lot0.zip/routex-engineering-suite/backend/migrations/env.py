"""Environnement Alembic.

Deux modes :
- programmatique (application) : une connexion est fournie dans
  ``config.attributes["connection"]`` par ``app.db.migrate`` ;
- ligne de commande (développement) : l'URL vient de ``ROUTEX_DB_URL`` ou de
  ``alembic.ini``.
"""

from __future__ import annotations

import os
from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

import app.models  # noqa: F401  (enregistre les tables)
from app.db.base import Base

config = context.config
target_metadata = Base.metadata

if config.config_file_name is not None and config.attributes.get("connection") is None:
    fileConfig(config.config_file_name)


def _configure(connection) -> None:  # type: ignore[no-untyped-def]
    context.configure(
        connection=connection,
        target_metadata=target_metadata,
        render_as_batch=True,  # ALTER TABLE sous SQLite
        compare_type=True,
    )


def run_migrations_offline() -> None:
    context.configure(
        url=os.environ.get("ROUTEX_DB_URL") or config.get_main_option("sqlalchemy.url"),
        target_metadata=target_metadata,
        literal_binds=True,
        render_as_batch=True,
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connection = config.attributes.get("connection")
    if connection is not None:
        _configure(connection)
        with context.begin_transaction():
            context.run_migrations()
        return

    section = config.get_section(config.config_ini_section, {})
    if os.environ.get("ROUTEX_DB_URL"):
        section["sqlalchemy.url"] = os.environ["ROUTEX_DB_URL"]
    connectable = engine_from_config(section, prefix="sqlalchemy.", poolclass=pool.NullPool)
    with connectable.connect() as conn:
        _configure(conn)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
