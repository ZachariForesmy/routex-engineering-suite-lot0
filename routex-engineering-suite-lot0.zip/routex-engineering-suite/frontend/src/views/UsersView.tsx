import { useCallback, useEffect, useState, type FormEvent } from "react";
import { ApiError, request } from "../api";
import type { NoticeState } from "../components/Notice";
import { formatDateTime } from "../format";
import type { Me, Role, User } from "../types";

const ROLES: { value: Role; label: string; description: string }[] = [
  { value: "admin", label: "Administrateur", description: "Comptes, sauvegardes, journal, et tous les droits projet." },
  { value: "ingenieur", label: "Ingénieur / Responsable", description: "Crée, modifie et archive les projets." },
  { value: "technicien", label: "Technicien / Métreur", description: "Consulte et exporte ; la saisie des métrés viendra au Lot 2." },
  { value: "lecture", label: "Lecture seule", description: "Consulte et exporte." },
];

interface Props {
  me: Me;
  notify: (notice: NoticeState) => void;
}

export function UsersView({ me, notify }: Props) {
  const [users, setUsers] = useState<User[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  const load = useCallback(async () => {
    try {
      setUsers(await request<User[]>("GET", "/users"));
    } catch (e) {
      notify({ kind: "error", text: e instanceof ApiError ? e.message : "Chargement des comptes impossible." });
    }
  }, [notify]);

  useEffect(() => {
    void load();
  }, [load]);

  const selected = users.find((u) => u.id === selectedId) ?? null;

  return (
    <main className="page">
      <div className="page__head">
        <h1>
          Utilisateurs<span className="page__count">{users.length}</span>
        </h1>
        <button className="btn btn--primary" type="button" onClick={() => { setCreating(true); setSelectedId(null); }}>
          Nouveau compte
        </button>
      </div>
      <div className="workspace">
        <section className="panel" aria-label="Comptes">
          <div className="table-wrap">
            <table className="register">
              <thead>
                <tr>
                  <th scope="col">Identifiant</th>
                  <th scope="col">Nom complet</th>
                  <th scope="col">Rôle</th>
                  <th scope="col">État</th>
                  <th scope="col">Dernière connexion</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id} aria-selected={u.id === selectedId} onClick={() => { setSelectedId(u.id); setCreating(false); }}>
                    <td className="code">
                      <button className="btn btn--link" type="button" onClick={() => { setSelectedId(u.id); setCreating(false); }}>
                        {u.username}
                      </button>
                    </td>
                    <td>{u.full_name}</td>
                    <td>{u.role_label}</td>
                    <td>
                      <span className={`status ${u.is_active ? "" : "status--archive"}`}>{u.is_active ? "Actif" : "Désactivé"}</span>
                    </td>
                    <td className="nowrap">{formatDateTime(u.last_login_at) || "Jamais"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
        <div>
          {creating ? (
            <CreateUserForm
              onCancel={() => setCreating(false)}
              onCreated={async (u) => {
                notify({ kind: "ok", text: `Compte « ${u.username} » créé.` });
                setCreating(false);
                await load();
                setSelectedId(u.id);
              }}
            />
          ) : selected ? (
            <EditUserForm
              key={selected.id}
              user={selected}
              isSelf={selected.id === me.id}
              onSaved={async (text) => {
                notify({ kind: "ok", text });
                await load();
              }}
            />
          ) : (
            <section className="panel">
              <div className="panel__body stack">
                <p className="muted">Sélectionnez un compte pour changer son rôle, le désactiver ou réinitialiser son mot de passe.</p>
                <p className="small muted">Les comptes ne sont jamais supprimés : le journal d'audit y fait référence.</p>
              </div>
            </section>
          )}
        </div>
      </div>
    </main>
  );
}

function RoleSelect({ value, onChange, id }: { value: Role; onChange: (r: Role) => void; id: string }) {
  const current = ROLES.find((r) => r.value === value);
  return (
    <div className="field">
      <label htmlFor={id}>Rôle</label>
      <select id={id} value={value} onChange={(e) => onChange(e.target.value as Role)}>
        {ROLES.map((r) => (
          <option key={r.value} value={r.value}>
            {r.label}
          </option>
        ))}
      </select>
      {current && <span className="hint">{current.description}</span>}
    </div>
  );
}

function CreateUserForm({ onCancel, onCreated }: { onCancel: () => void; onCreated: (u: User) => Promise<void> }) {
  const [username, setUsername] = useState("");
  const [fullName, setFullName] = useState("");
  const [role, setRole] = useState<Role>("technicien");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await onCreated(await request<User>("POST", "/users", { username, full_name: fullName, role, password }));
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Création impossible.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="panel" onSubmit={submit} noValidate>
      <div className="panel__head">
        <h2>Nouveau compte</h2>
      </div>
      <div className="panel__body stack">
        <div className="field">
          <label htmlFor="nu-user">Identifiant</label>
          <input id="nu-user" type="text" autoComplete="off" value={username} onChange={(e) => setUsername(e.target.value)} />
        </div>
        <div className="field">
          <label htmlFor="nu-name">Nom complet</label>
          <input id="nu-name" type="text" value={fullName} onChange={(e) => setFullName(e.target.value)} />
        </div>
        <RoleSelect id="nu-role" value={role} onChange={setRole} />
        <div className="field">
          <label htmlFor="nu-pwd">Mot de passe initial</label>
          <input id="nu-pwd" type="password" autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <span className="hint">10 caractères minimum. Communiquez-le à la personne, qui pourra le changer depuis « Mon compte ».</span>
        </div>
        {error && <p className="field error" role="alert">{error}</p>}
        <div className="form-actions">
          <button className="btn btn--primary" type="submit" disabled={busy}>
            Créer le compte
          </button>
          <button className="btn" type="button" onClick={onCancel} disabled={busy}>
            Annuler
          </button>
        </div>
      </div>
    </form>
  );
}

function EditUserForm({ user, isSelf, onSaved }: { user: User; isSelf: boolean; onSaved: (text: string) => Promise<void> }) {
  const [role, setRole] = useState<Role>(user.role);
  const [active, setActive] = useState(user.is_active);
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    const payload: Record<string, unknown> = {};
    if (role !== user.role) payload.role = role;
    if (active !== user.is_active) payload.is_active = active;
    if (password) payload.new_password = password;
    if (Object.keys(payload).length === 0) return setError("Aucune modification à enregistrer.");
    setBusy(true);
    setError(null);
    try {
      await request<User>("PATCH", `/users/${user.id}`, payload);
      setPassword("");
      await onSaved(password ? `Compte « ${user.username} » mis à jour ; mot de passe réinitialisé.` : `Compte « ${user.username} » mis à jour.`);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Enregistrement impossible.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="panel" onSubmit={submit} noValidate>
      <div className="panel__head">
        <p className="sheet__code">{user.username}</p>
        <h2 className="sheet__title">{user.full_name}</h2>
      </div>
      <div className="panel__body stack">
        <p className="small muted">Compte créé le {formatDateTime(user.created_at)}.</p>
        <RoleSelect id="eu-role" value={role} onChange={setRole} />
        <label className="check">
          <input type="checkbox" checked={active} disabled={isSelf} onChange={(e) => setActive(e.target.checked)} />
          Compte actif
        </label>
        {isSelf && <p className="small muted">Vous ne pouvez pas désactiver votre propre compte.</p>}
        <div className="field">
          <label htmlFor="eu-pwd">Nouveau mot de passe (facultatif)</label>
          <input id="eu-pwd" type="password" autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <span className="hint">Ferme les sessions ouvertes de ce compte.</span>
        </div>
        {error && <p className="field error" role="alert">{error}</p>}
        <div className="form-actions">
          <button className="btn btn--primary" type="submit" disabled={busy}>
            Enregistrer
          </button>
        </div>
      </div>
    </form>
  );
}
