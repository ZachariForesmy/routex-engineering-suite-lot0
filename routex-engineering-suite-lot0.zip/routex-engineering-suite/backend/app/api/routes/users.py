from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, status

from app.api.deps import DbSession, require
from app.core.permissions import Permission
from app.schemas.user import UserCreateIn, UserOut, UserUpdateIn
from app.services import user_service
from app.services.actor import Actor

router = APIRouter(prefix="/users", tags=["Utilisateurs"])
UserManager = Annotated[Actor, Depends(require(Permission.USER_MANAGE))]


@router.get("", response_model=list[UserOut], summary="Liste des comptes")
def list_users(_actor: UserManager, db: DbSession) -> list[UserOut]:
    return [UserOut.model_validate(u) for u in user_service.list_users(db)]


@router.post("", response_model=UserOut, status_code=status.HTTP_201_CREATED, summary="Créer un compte")
def create_user(payload: UserCreateIn, actor: UserManager, db: DbSession) -> UserOut:
    return UserOut.model_validate(user_service.create_user(db, actor, payload))


@router.patch("/{user_id}", response_model=UserOut,
              summary="Modifier un compte (rôle, activation, réinitialisation du mot de passe)")
def update_user(user_id: str, payload: UserUpdateIn, actor: UserManager, db: DbSession) -> UserOut:
    return UserOut.model_validate(user_service.update_user(db, actor, user_id, payload))
