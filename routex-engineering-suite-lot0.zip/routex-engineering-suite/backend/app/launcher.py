"""Point d'entrée de l'application empaquetée (RouteX.exe) — D-001.

    RouteX.exe                         démarre l'application et ouvre le navigateur
    RouteX.exe --no-browser            démarre sans ouvrir le navigateur
    RouteX.exe reset-password <id>     réinitialise un mot de passe (accès au poste requis)
    RouteX.exe backup                  sauvegarde la base sans démarrer l'interface
    RouteX.exe info                    affiche les emplacements des données
"""

from __future__ import annotations

import argparse
import getpass
import json
import socket
import sys
import threading
import time
import urllib.error
import urllib.request
import webbrowser

from app import APP_ID, APP_NAME, __version__
from app.core.config import ConfigError, Settings
from app.core.errors import AppError, DatabaseStateError
from app.core.resources import is_frozen
from app.core.security import MIN_PASSWORD_LENGTH


def _print(message: str = "") -> None:
    print(message, flush=True)


def _pause_if_console_will_close() -> None:
    """Sous Windows, la console d'un exécutable double-cliqué se ferme
    immédiatement : on laisse le temps de lire le message d'erreur."""
    if is_frozen() and sys.platform == "win32" and sys.stdin and sys.stdin.isatty():
        try:
            input("\nAppuyez sur Entrée pour fermer cette fenêtre…")
        except EOFError:
            pass


def _probe(port: int) -> str:
    """« routex » si une instance RouteX répond, « occupe » si le port est pris
    par autre chose, « libre » sinon."""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/v1/system/health", timeout=1.5) as resp:
            return "routex" if json.load(resp).get("app") == APP_ID else "occupe"
    except (urllib.error.URLError, ValueError, TimeoutError, OSError):
        pass
    # Test par connexion plutôt que par bind : un port en TIME_WAIT après un
    # arrêt récent n'a plus d'écoute et doit être considéré comme libre.
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=1):
            return "occupe"
    except OSError:
        return "libre"


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def _open_when_ready(url: str, port: int) -> None:
    def worker() -> None:
        for _ in range(60):
            if _probe(port) == "routex":
                webbrowser.open(url)
                return
            time.sleep(0.5)

    threading.Thread(target=worker, daemon=True).start()


def cmd_run(settings: Settings, open_browser: bool) -> int:
    import uvicorn

    from app.main import create_app

    state = _probe(settings.port)
    if state == "routex":
        url = f"http://127.0.0.1:{settings.port}/"
        _print(f"RouteX est déjà ouvert sur ce poste : {url}")
        if open_browser:
            webbrowser.open(url)
        return 0
    if state == "occupe":
        port = _free_port()
        _print(f"Le port {settings.port} est utilisé par un autre programme ; RouteX utilisera le port {port}.")
        settings = settings.with_overrides(port=port)

    app = create_app(settings)
    url = f"http://127.0.0.1:{settings.port}/"
    _print("=" * 72)
    _print(f" {APP_NAME} {__version__} — version de développement")
    _print(f" Adresse    : {url}")
    _print(f" Données    : {settings.data_dir}")
    _print(" Ne fermez pas cette fenêtre pendant l'utilisation (Ctrl+C pour quitter).")
    _print("=" * 72)
    if open_browser:
        _open_when_ready(url, settings.port)
    uvicorn.run(
        app, host=settings.host, port=settings.port,
        loop="asyncio", http="h11", ws="none", lifespan="on",
        access_log=False, log_level="warning",
    )
    return 0


def _ask_new_password() -> str:
    while True:
        first = getpass.getpass(f"Nouveau mot de passe ({MIN_PASSWORD_LENGTH} caractères minimum) : ")
        if len(first) < MIN_PASSWORD_LENGTH:
            _print(f"Trop court : {MIN_PASSWORD_LENGTH} caractères minimum.")
            continue
        if getpass.getpass("Confirmez le mot de passe : ") != first:
            _print("Les deux saisies diffèrent, recommencez.")
            continue
        return first


def _open_database(settings: Settings):  # type: ignore[no-untyped-def]
    from app.db.migrate import prepare_database
    from app.db.session import make_engine, make_sessionmaker

    settings.ensure_dirs()
    engine = make_engine(settings.db_path)
    prepare_database(engine, settings.db_path, settings.backups_dir)
    return engine, make_sessionmaker(engine)


def cmd_reset_password(settings: Settings, username: str) -> int:
    from app.services.auth_service import reset_password_offline

    engine, session_factory = _open_database(settings)
    password = _ask_new_password()
    with session_factory() as db:
        user = reset_password_offline(db, username=username, new_password=password)
    engine.dispose()
    _print(f"Mot de passe de « {user.username} » réinitialisé ; le compte est actif. Ses sessions ouvertes ont été fermées.")
    return 0


def cmd_backup(settings: Settings) -> int:
    from app.services.backup_service import create_backup

    engine, _ = _open_database(settings)
    engine.dispose()
    info = create_backup(settings.db_path, settings.backups_dir, label="console")
    _print(f"Sauvegarde créée : {info.path}")
    _print(f"Taille : {info.size_bytes} octets — intégrité : {info.integrity} — SHA-256 : {info.sha256}")
    return 0


def cmd_info(settings: Settings) -> int:
    _print(f"{APP_NAME} {__version__}")
    _print(f"Données     : {settings.data_dir}")
    _print(f"Base        : {settings.db_path}")
    _print(f"Sauvegardes : {settings.backups_dir}")
    _print(f"Journaux    : {settings.logs_dir}")
    _print(f"Interface   : {settings.frontend_dist}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="RouteX", description=f"{APP_NAME} {__version__}")
    parser.add_argument("--no-browser", action="store_true", help="ne pas ouvrir le navigateur")
    parser.add_argument("--port", type=int, help="port local (défaut 8765 ou ROUTEX_PORT)")
    sub = parser.add_subparsers(dest="command")
    reset = sub.add_parser("reset-password", help="réinitialiser le mot de passe d'un compte")
    reset.add_argument("username")
    sub.add_parser("backup", help="sauvegarder la base")
    sub.add_parser("info", help="afficher les emplacements des données")
    args = parser.parse_args(argv)

    try:
        settings = Settings.from_env()
        if args.port:
            settings = settings.with_overrides(port=args.port)
        if args.command == "reset-password":
            return cmd_reset_password(settings, args.username)
        if args.command == "backup":
            return cmd_backup(settings)
        if args.command == "info":
            return cmd_info(settings)
        return cmd_run(settings, open_browser=not args.no_browser)
    except KeyboardInterrupt:
        _print("\nArrêt demandé.")
        return 0
    except (ConfigError, DatabaseStateError, AppError) as exc:
        _print(f"\nRouteX ne peut pas démarrer : {exc}")
        _pause_if_console_will_close()
        return 2


if __name__ == "__main__":
    sys.exit(main())
