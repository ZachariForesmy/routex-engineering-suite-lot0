from __future__ import annotations

from datetime import date, datetime
from typing import Annotated, Literal

from pydantic import BeforeValidator, StringConstraints, model_validator

from app.schemas.common import OutModel, StrictModel, text


def _upper(value: object) -> object:
    return value.strip().upper() if isinstance(value, str) else value


ProjectCode = Annotated[
    str,
    StringConstraints(
        strip_whitespace=True, min_length=1, max_length=40, pattern=r"^[A-Za-z0-9][A-Za-z0-9._/-]*$"
    ),
]
Currency = Annotated[str, BeforeValidator(_upper), StringConstraints(pattern=r"^[A-Z]{3}$")]
UnitSystem = Literal["SI"]
ProjectName = text(200, min_length=1)
Text100 = text(100)
Text200 = text(200)
Text5000 = text(5000)


def _check_dates(start: date | None, end: date | None) -> None:
    if start and end and end < start:
        raise ValueError("la date de fin doit être postérieure ou égale à la date de début")


class ProjectCreateIn(StrictModel):
    code: ProjectCode
    name: ProjectName
    client: Text200 = ""
    location: Text200 = ""
    country: Text100 = ""
    currency: Currency
    unit_system: UnitSystem = "SI"
    description: Text5000 = ""
    start_date: date | None = None
    end_date: date | None = None

    @model_validator(mode="after")
    def _dates(self) -> "ProjectCreateIn":
        _check_dates(self.start_date, self.end_date)
        return self


_NOT_NULLABLE = ("code", "name", "client", "location", "country", "currency", "unit_system", "description")


class ProjectUpdateIn(StrictModel):
    """Modification partielle. ``revision`` est la révision lue par le client
    (contrôle de concurrence optimiste, D-013)."""

    revision: int
    code: ProjectCode | None = None
    name: ProjectName | None = None
    client: Text200 | None = None
    location: Text200 | None = None
    country: Text100 | None = None
    currency: Currency | None = None
    unit_system: UnitSystem | None = None
    description: Text5000 | None = None
    start_date: date | None = None
    end_date: date | None = None

    @model_validator(mode="after")
    def _no_null_for_required(self) -> "ProjectUpdateIn":
        for field in _NOT_NULLABLE:
            if field in self.model_fields_set and getattr(self, field) is None:
                raise ValueError(f"le champ « {field} » ne peut pas être nul")
        return self


class ArchiveIn(StrictModel):
    revision: int


class ProjectOut(OutModel):
    id: str
    code: str
    name: str
    client: str
    location: str
    country: str
    currency: str
    unit_system: str
    description: str
    start_date: date | None
    end_date: date | None
    status: Literal["actif", "archive"]
    archived_at: datetime | None
    revision: int
    created_at: datetime
    updated_at: datetime
    created_by_name: str = ""
    updated_by_name: str = ""


class ProjectListOut(OutModel):
    items: list[ProjectOut]
    total: int
